plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}
val cfClientId: String = System.getenv("CF_CLIENT_ID")?.takeIf { it.isNotBlank() } ?: (project.findProperty("CF_CLIENT_ID") as String? ?: "").trim()
android {
    namespace = "app.cloudforge"
    compileSdk = 34
    defaultConfig {
        applicationId = "app.cloudforge"
        minSdk = 29
        targetSdk = 34
        versionCode = 12
        versionName = "1.2"
        buildConfigField("String", "CLIENT_ID", "\"$cfClientId\"")
    }
    val ksPath: String? = System.getenv("KS_PATH")
    signingConfigs {
        if (!ksPath.isNullOrBlank()) create("cf") {
            storeFile = file(ksPath); storeType = "pkcs12"
            storePassword = System.getenv("KS_PASS"); keyAlias = System.getenv("KS_ALIAS"); keyPassword = System.getenv("KS_PASS")
        }
    }
    buildFeatures { compose = true; buildConfig = true }
    buildTypes { release { isMinifyEnabled = false; signingConfig = signingConfigs.findByName("cf") ?: signingConfigs.getByName("debug") } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    packaging {
        resources {
            excludes += setOf("META-INF/versions/**", "META-INF/DEPENDENCIES", "META-INF/LICENSE*", "META-INF/NOTICE*", "META-INF/INDEX.LIST", "META-INF/AL2.0", "META-INF/LGPL2.1")
        }
    }
    sourceSets["main"].java.srcDir("src/main/kotlin")
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.00"))
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.6")
    implementation("androidx.security:security-crypto:1.1.0-alpha06")
    implementation("androidx.core:core-splashscreen:1.0.1")
    implementation("androidx.browser:browser:1.8.0")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("org.bouncycastle:bcprov-jdk18on:1.78.1")
    implementation("org.bouncycastle:bcpkix-jdk18on:1.78.1")
    implementation("com.goterl:lazysodium-android:5.1.0@aar")
    implementation("net.java.dev.jna:jna:5.14.0@aar")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
}

// The Client ID is baked in so end users never type anything. Fail loudly instead of shipping a build that cannot sign in.
tasks.matching { it.name == "assembleRelease" }.configureEach {
    doFirst { if (cfClientId.isBlank()) throw GradleException("CF_CLIENT_ID is empty. Put your GitHub OAuth App Client ID in gradle.properties (CF_CLIENT_ID=Ov23...) and enable Device Flow on that OAuth App.") }
}
