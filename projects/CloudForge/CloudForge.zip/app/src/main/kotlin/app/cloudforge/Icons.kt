package app.cloudforge

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.unit.dp

/** Soft rounded line icons (Lucide-style, 24px grid, 1.8 stroke). Tinted by Icon(tint=…). */
private fun line(name: String, vararg d: String): ImageVector = ImageVector.Builder(name, 24.dp, 24.dp, 24f, 24f).apply {
    d.forEach { addPath(PathParser().parsePathString(it).toNodes(), stroke = SolidColor(Color.Black), strokeLineWidth = 1.8f,
        strokeLineCap = StrokeCap.Round, strokeLineJoin = StrokeJoin.Round) }
}.build()

object Ic {
    val Cloud: ImageVector by lazy { line("Cloud", "M17.5 19H9a7 7 0 1 1 6.71-9h1.79a4.5 4.5 0 1 1 0 9Z") }
    val CloudUpload: ImageVector by lazy { line("CloudUpload", "M12 13v8", "M4 14.9A7 7 0 1 1 15.7 8h1.8a4.5 4.5 0 0 1 2.5 8.24", "M8 17l4-4 4 4") }
    val Wrench: ImageVector by lazy { line("Wrench", "M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z") }
    val Archive: ImageVector by lazy { line("Archive", "M3,3 H21 A1,1 0 0 1 22,4 V7 A1,1 0 0 1 21,8 H3 A1,1 0 0 1 2,7 V4 A1,1 0 0 1 3,3 Z", "M4 8v11a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8", "M10 12h4") }
    val GitBranch: ImageVector by lazy { line("GitBranch", "M6 3v12", "M15,6 a3,3 0 1,0 6,0 a3,3 0 1,0 -6,0", "M3,18 a3,3 0 1,0 6,0 a3,3 0 1,0 -6,0", "M18 9a9 9 0 0 1-9 9") }
    val Github: ImageVector by lazy { line("Github", "M15 22v-4a4.8 4.8 0 0 0-1-3.5c3 0 6-2 6-5.5.08-1.25-.27-2.48-1-3.5.28-1.15.28-2.35 0-3.5 0 0-1 0-3 1.5-2.64-.5-5.36-.5-8 0C6 2 5 2 5 2c-.3 1.15-.3 2.35 0 3.5A5.4 5.4 0 0 0 4 9c0 3.5 3 5.5 6 5.5-.39.49-.68 1.05-.85 1.65-.17.6-.22 1.23-.15 1.85v4", "M9 18c-4.51 2-5-2-7-2") }
    val Download: ImageVector by lazy { line("Download", "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4", "M7 10l5 5 5-5", "M12 15V3") }
    val Trash: ImageVector by lazy { line("Trash", "M3 6h18", "M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6", "M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2", "M10 11v6", "M14 11v6") }
    val Plus: ImageVector by lazy { line("Plus", "M5 12h14", "M12 5v14") }
    val Check: ImageVector by lazy { line("Check", "M20 6L9 17l-5-5") }
    val Close: ImageVector by lazy { line("Close", "M18 6L6 18", "M6 6l12 12") }
    val Search: ImageVector by lazy { line("Search", "M3,11 a8,8 0 1,0 16,0 a8,8 0 1,0 -16,0", "M21 21l-4.3-4.3") }
    val Lock: ImageVector by lazy { line("Lock", "M5,11 H19 A2,2 0 0 1 21,13 V20 A2,2 0 0 1 19,22 H5 A2,2 0 0 1 3,20 V13 A2,2 0 0 1 5,11 Z", "M7 11V7a5 5 0 0 1 10 0v4") }
    val Globe: ImageVector by lazy { line("Globe", "M2,12 a10,10 0 1,0 20,0 a10,10 0 1,0 -20,0", "M2 12h20", "M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z") }
    val Key: ImageVector by lazy { line("Key", "M3.0,15.5 a4.5,4.5 0 1,0 9.0,0 a4.5,4.5 0 1,0 -9.0,0", "M10.7 12.3L20 3", "M16 7l3 3", "M14 9l2 2") }
    val Folder: ImageVector by lazy { line("Folder", "M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z") }
    val File: ImageVector by lazy { line("File", "M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z", "M14 2v6h6") }
    val Alert: ImageVector by lazy { line("Alert", "M21.73 18l-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3", "M12 9v4", "M12 17h.01") }
    val Clock: ImageVector by lazy { line("Clock", "M2,12 a10,10 0 1,0 20,0 a10,10 0 1,0 -20,0", "M12 6v6l4 2") }
    val LogOut: ImageVector by lazy { line("LogOut", "M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4", "M16 17l5-5-5-5", "M21 12H9") }
    val Copy: ImageVector by lazy { line("Copy", "M10,8 H20 A2,2 0 0 1 22,10 V20 A2,2 0 0 1 20,22 H10 A2,2 0 0 1 8,20 V10 A2,2 0 0 1 10,8 Z", "M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2") }
    val CheckCircle: ImageVector by lazy { line("CheckCircle", "M2,12 a10,10 0 1,0 20,0 a10,10 0 1,0 -20,0", "M9 12l2 2 4-4") }
    val XCircle: ImageVector by lazy { line("XCircle", "M2,12 a10,10 0 1,0 20,0 a10,10 0 1,0 -20,0", "M15 9l-6 6", "M9 9l6 6") }
    val Ban: ImageVector by lazy { line("Ban", "M2,12 a10,10 0 1,0 20,0 a10,10 0 1,0 -20,0", "M4.9 4.9l14.2 14.2") }
    val Spinner: ImageVector by lazy { line("Spinner", "M21 12a9 9 0 1 1-6.22-8.56") }
    val Menu: ImageVector by lazy { line("Menu", "M4 6h16", "M4 12h16", "M4 18h16") }
    val Refresh: ImageVector by lazy { line("Refresh", "M21 12a9 9 0 0 0-9-9 9.75 9.75 0 0 0-6.74 2.74L3 8", "M3 3v5h5", "M3 12a9 9 0 0 0 9 9 9.75 9.75 0 0 0 6.74-2.74L21 16", "M16 16h5v5") }
    val Info: ImageVector by lazy { line("Info", "M2,12 a10,10 0 1,0 20,0 a10,10 0 1,0 -20,0", "M12 16v-4", "M12 8h.01") }
    val Edit: ImageVector by lazy { line("Edit", "M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z", "M15 5l4 4") }
    val Package: ImageVector by lazy { line("Package", "M16.5 9.4L7.5 4.21", "M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z", "M3.3 7l8.7 5 8.7-5", "M12 22V12") }
    val ArrowRight: ImageVector by lazy { line("ArrowRight", "M5 12h14", "M12 5l7 7-7 7") }
    val FolderPlus: ImageVector by lazy { line("FolderPlus", "M12 10v6", "M9 13h6", "M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z") }
    val FilePlus: ImageVector by lazy { line("FilePlus", "M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z", "M14 2v6h6", "M12 18v-6", "M9 15h6") }
    val FileZip: ImageVector by lazy { line("FileZip", "M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z", "M14 2v6h6", "M10 12h4", "M10 16h4") }
    val Upload: ImageVector by lazy { line("Upload", "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4", "M17 8l-5-5-5 5", "M12 3v12") }
    val Scissors: ImageVector by lazy { line("Scissors", "M3,6 a3,3 0 1,0 6,0 a3,3 0 1,0 -6,0", "M3,18 a3,3 0 1,0 6,0 a3,3 0 1,0 -6,0", "M20 4L8.12 15.88", "M14.47 14.48L20 20", "M8.12 8.12L12 12") }
    val Paste: ImageVector by lazy { line("Paste", "M15 2H9a1 1 0 0 0-1 1v2a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V3a1 1 0 0 0-1-1Z", "M8 4H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2h-2") }
    val More: ImageVector by lazy { line("More", "M11,12 a1,1 0 1,0 2,0 a1,1 0 1,0 -2,0", "M11,5 a1,1 0 1,0 2,0 a1,1 0 1,0 -2,0", "M11,19 a1,1 0 1,0 2,0 a1,1 0 1,0 -2,0") }
    val Save: ImageVector by lazy { line("Save", "M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z", "M17 21v-8H7v8", "M7 3v5h8") }
    val History: ImageVector by lazy { line("History", "M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8", "M3 3v5h5", "M12 7v5l4 2") }
    val ChevronLeft: ImageVector by lazy { line("ChevronLeft", "M15 18l-6-6 6-6") }
    val Home: ImageVector by lazy { line("Home", "M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z", "M9 22V12h6v10") }
    val SelectAll: ImageVector by lazy { line("SelectAll", "M9 11l3 3L22 4", "M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11") }
    val FolderMove: ImageVector by lazy { line("FolderMove", "M2 9V5a2 2 0 0 1 2-2h3.9a2 2 0 0 1 1.69.9l.81 1.2a2 2 0 0 0 1.67.9H20a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2v-1", "M2 13h10", "M9 16l3-3-3-3") }
    val Image: ImageVector by lazy { line("Image", "M5,3 H19 A2,2 0 0 1 21,5 V19 A2,2 0 0 1 19,21 H5 A2,2 0 0 1 3,19 V5 A2,2 0 0 1 5,3 Z", "M8.5,8.5 a1.5,1.5 0 1,0 3,0 a1.5,1.5 0 1,0 -3,0", "M21 15l-5-5L5 21") }
    val ArrowUp: ImageVector by lazy { line("ArrowUp", "M12 19V5", "M5 12l7-7 7 7") }
}
