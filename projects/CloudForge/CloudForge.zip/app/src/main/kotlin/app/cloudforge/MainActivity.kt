package app.cloudforge

import android.app.Application
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.util.Base64
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.browser.customtabs.CustomTabsIntent
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animate
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.material3.pulltorefresh.PullToRefreshDefaults
import androidx.compose.material3.pulltorefresh.rememberPullToRefreshState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.animation.core.spring
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.activity.viewModels
import android.content.ContentUris
import android.os.Environment
import android.app.Activity
import android.os.Build
import android.provider.Settings
import android.content.ContextWrapper
import android.content.pm.PackageManager
import java.io.File
import androidx.compose.foundation.draganddrop.dragAndDropTarget
import androidx.compose.ui.draganddrop.DragAndDropEvent
import androidx.compose.ui.draganddrop.DragAndDropTarget
import androidx.compose.ui.draganddrop.toAndroidDragEvent
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.draw.clip
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.coroutines.*
import org.json.JSONObject
import java.time.Duration
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import java.util.zip.ZipInputStream

/* ───────────── helpers ───────────── */
fun clean(s: String) = s.replace(Regex("[^A-Za-z0-9._-]+"), "-").trim('-', '.').ifBlank { "app" }.take(60)
fun sz(b: Long) = if (b > 1048576) "%.1f MB".format(b / 1048576.0) else "${maxOf(1, b / 1024)} KB"
fun fmt(a: String?) = if (a.isNullOrEmpty()) "—" else
    DateTimeFormatter.ofLocalizedDateTime(FormatStyle.MEDIUM).withZone(ZoneId.systemDefault()).format(Instant.parse(a))
fun dur(a: String?, b: String?): String {
    if (a.isNullOrEmpty()) return "—"
    val s = Duration.between(Instant.parse(a), if (b.isNullOrEmpty()) Instant.now() else Instant.parse(b)).seconds.coerceAtLeast(0)
    return if (s >= 60) "${s / 60}د ${s % 60}ث" else "${s}ث"
}
fun rootOk(c: Context, u: Uri): Boolean = try {
    val ok = Regex("^(pubspec\\.yaml|package\\.json|build\\.gradle(\\.kts)?|settings\\.gradle(\\.kts)?|gradlew)$")
    ZipInputStream(c.contentResolver.openInputStream(u)).use { z ->
        var e = z.nextEntry; var f = false; var n = 0
        while (e != null && n < 5000) { if (ok.matches(e.name)) f = true; z.closeEntry(); e = z.nextEntry; n++ }
        f
    }
} catch (e: Exception) { false }

/** Build time of a release as local yyyyMMddHHmm. It only decorates the local file name (name_202611181309.apk) so builds can be compared; the repo file never has it. */
private val STAMP_FMT = DateTimeFormatter.ofPattern("yyyyMMddHHmm").withZone(ZoneId.systemDefault())
fun assetOf(rel: JSONObject): JSONObject? = rel.optJSONArray("assets")?.optJSONObject(0)
fun stampOf(rel: JSONObject): String {
    val t = assetOf(rel)?.s("created_at").orEmpty().ifEmpty { rel.s("created_at") }
    return try { STAMP_FMT.format(Instant.parse(t)) } catch (e: Exception) { "000000000000" }
}
fun apkBase(rel: JSONObject): String = (assetOf(rel)?.s("name")?.ifEmpty { null } ?: rel.s("name")).removeSuffix(".apk")
/** An APK that already sits in Download/CloudForge/<folder>/<base>_<stamp>.apk. */
data class LocalApk(val folder: String, val base: String, val stamp: String, val uri: Uri)
private val LOCAL_RE = Regex("^(.+)_(\\d{12})\\.apk$")

/** Every project gets its own sub-folder here: Download/CloudForge/<project>/<name>_<build time>.apk */
const val APK_ROOT = "CloudForge"
const val OTHER = "أخرى"
fun projOf(t: String?): String? = Regex("projects/([^/]+)/").find(t ?: "")?.groupValues?.get(1)
/** Which project a workflow run belongs to (run-name carries the zip path; old push runs fall back to the commit message). */
fun runKey(r: JSONObject): String = projOf(r.s("display_title"))
    ?: (if (r.s("event") == "push") projOf(r.optJSONObject("head_commit")?.s("message")) else null) ?: OTHER
fun relKey(r: JSONObject): String = projOf(r.s("body")) ?: OTHER
/** Downloads sub-folder of a release: its project, or (old releases without one) its own name. */
fun folderOf(r: JSONObject): String = clean(projOf(r.s("body")) ?: r.s("name").ifBlank { "CloudForge" })
fun failed(r: JSONObject) = r.s("status") == "completed" && r.s("conclusion") in listOf("failure", "cancelled", "timed_out")

/* ───────────── state ───────────── */
class VM(private val app: Application) : AndroidViewModel(app) {
    private val prefs = EncryptedSharedPreferences.create(app, "cf",
        MasterKey.Builder(app).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)
    var token by mutableStateOf(prefs.getString("t", null))
    var connecting by mutableStateOf(false)
    var useWebView by mutableStateOf(prefs.getBoolean("wv", false))   // login inside the app (WebView) instead of the external browser
    var tokenDialog by mutableStateOf(false)
    var user by mutableStateOf(prefs.getString("u", "") ?: "")
    var repo by mutableStateOf(prefs.getString("r", null))
    private var branch = prefs.getString("b", "main") ?: "main"
    var screen by mutableStateOf("home")          // home | repos | upload | builds | archive
    var uploadTarget by mutableStateOf<String?>(null) // project folder preselected for "update"
    var releases by mutableStateOf(listOf<JSONObject>())
    var sel by mutableStateOf<String?>(null)           // project selected in Builds / Archive
    var showRepo by mutableStateOf(false)
    var repoInfo by mutableStateOf<JSONObject?>(null)
    var busy by mutableStateOf(false)
    private var errorState by mutableStateOf<String?>(null)
    private var taskErr: String? = null          // message already notified by its own task notification
    var error: String?
        get() = errorState
        set(v) { errorState = v; if (v != null && v != taskErr && !Notif.fg) Notif.error(Notif.ID_APP_ERR, "حدث خطأ في CloudForge", v) }
    /** Failure of a long task: own notification (with its title), and the message also goes to the in-app error bar. */
    private fun taskFail(nid: Int, title: String, msg: String) { taskErr = msg; Notif.error(nid, title, msg) }
    var toast by mutableStateOf<String?>(null)
    var code by mutableStateOf<Pair<String, String>?>(null)
    var repos by mutableStateOf(listOf<JSONObject>())
    var projects by mutableStateOf<Gh.Projects?>(null)
    var runs by mutableStateOf(listOf<JSONObject>())
    var jobs by mutableStateOf(mapOf<Long, List<JSONObject>>())
    var logs by mutableStateOf(mapOf<Long, String>())
    var open by mutableStateOf<Long?>(null)
    var archive by mutableStateOf(listOf<Pair<JSONObject, List<JSONObject>>>())
    var signed by mutableStateOf(false)
    var keyInfo by mutableStateOf<String?>(null)
    var local by mutableStateOf(listOf<LocalApk>())               // APKs already saved in Downloads/<project>/
    var dl by mutableStateOf(mapOf<Long, Pair<Long, Long>>())     // asset id -> (bytes done, bytes total) while downloading
    private val dlJobs = mutableMapOf<Long, Job>()
    class UpState(val stage: String, val done: Long, val total: Long)
    var up by mutableStateOf<UpState?>(null)                      // upload progress (null = not uploading)
    private var upJob: Job? = null
    private var loginJob: Job? = null
    private val gh get() = Gh(token!!)
    init { Notif.handler = { kind, key -> when (kind) { "dl" -> cancelDownload(key); "up" -> cancelUpload(); "run" -> cancelRun(key) } } }
    override fun onCleared() { Notif.handler = null; Notif.clearAll(); super.onCleared() }

    private fun go(b: suspend () -> Unit) = viewModelScope.launch {
        busy = true
        try { b() } catch (e: CancellationException) { throw e } catch (e: Exception) {
            error = e.message ?: e.toString()
            if (e is ApiError && e.code == 401) {
                // never log out on a single 401 (it can be transient): only if GitHub also rejects the token on /user
                val dead = try { Gh(token ?: "").user(); false } catch (x: CancellationException) { throw x } catch (x: ApiError) { x.code == 401 } catch (x: Exception) { false }
                if (dead) logout() else error = "رفض GitHub الطلب مؤقتاً (401) مع أن جلستك سليمة. لم يتم تسجيل الخروج، أعد المحاولة."
            }
        } finally { busy = false }
    }

    /** One tap: ask GitHub for a device code, show GitHub's own authorize page inside the app, poll until approved. */
    fun login() {
        val id = BuildConfig.CLIENT_ID
        if (id.isBlank()) { error = "التطبيق غير مهيأ: لم يُضمَّن GitHub Client ID وقت البناء (CF_CLIENT_ID)"; return }
        if (connecting || code != null) return
        loginJob = viewModelScope.launch {
            connecting = true
            try {
                val d = Auth.start(id)
                code = d.getString("user_code") to d.getString("verification_uri")
                connecting = false
                val t = Auth.poll(id, d.getString("device_code"), d.optInt("interval", 5), d.optInt("expires_in", 900))
                prefs.edit().putString("t", t).apply()               // keep the token first: a failed /user call must not lose it
                var u = ""
                for (a in 0 until 3) { try { u = Gh(t).user().getString("login"); break } catch (e: CancellationException) { throw e } catch (e: Exception) { delay(1500) } }
                prefs.edit().putString("u", u).apply()
                user = u; token = t; code = null; screen = if (repo == null) "repos" else "home"
                try { app.startActivity(Intent(app, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP)) } catch (e: Exception) { }
            } catch (e: CancellationException) { throw e } catch (e: Exception) { error = e.message; code = null }
            finally { connecting = false }
        }
    }
    fun setWebView(v: Boolean) { useWebView = v; prefs.edit().putBoolean("wv", v).apply() }
    /** Login with a Personal Access Token pasted by hand (no browser, no device code). */
    fun loginWithToken(raw: String) {
        val t = raw.trim()
        if (t.isEmpty() || connecting) return
        viewModelScope.launch {
            connecting = true
            try {
                val u = Gh(t).user().getString("login")
                prefs.edit().putString("t", t).putString("u", u).apply()
                user = u; token = t; tokenDialog = false; screen = if (repo == null) "repos" else "home"
            } catch (e: CancellationException) { throw e } catch (e: Exception) {
                error = if (e is ApiError && e.code == 401) "التوكين غير صالح أو منتهي الصلاحية" else (e.message ?: e.toString())
            } finally { connecting = false }
        }
    }
    fun cancelLogin() { loginJob?.cancel(); code = null; connecting = false }
    fun logout() { prefs.edit().remove("t").remove("r").remove("b").apply(); repo = null; token = null; runs = emptyList(); releases = emptyList(); archive = emptyList(); projects = null; screen = "home" }

    fun loadRepos() = go { repos = gh.repos() }
    private suspend fun doPick(full: String) {
        val i = gh.repoInfo(full)
        if (i.optJSONObject("permissions")?.optBoolean("push") != true) throw ApiError("لا تملك صلاحية الكتابة على هذا المستودع")
        val b = i.getString("default_branch")
        gh.ensureWorkflow(full, b, app.assets.open("build.yml").readBytes())
        repo = full; branch = b; signed = false; projects = null; runs = emptyList(); releases = emptyList(); open = null; uploadTarget = null; screen = "upload"
        prefs.edit().putString("r", full).putString("b", b).apply()
        toast = "تم اعتماد $full وتثبيت سكربت البناء"
    }
    fun pick(full: String) = go { doPick(full) }
    fun create(name: String, priv: Boolean) = go {
        val r = gh.createRepo(clean(name), priv); delay(1500); doPick(r.getString("full_name"))
    }

    fun checkSigning() = go { ensureSigning(repo!!) }
    /** Persistent signing key lives in repo Secrets: created once, reused for every build. Never overwritten if already set. */
    private suspend fun ensureSigning(full: String) {
        val names = listOf("ANDROID_KEYSTORE_BASE64", "ANDROID_KEYSTORE_PASSWORD", "ANDROID_KEY_ALIAS")
        if (names.all { gh.hasSecret(full, it) }) { signed = true; return }
        var b64 = prefs.getString("ks", null); var pw = prefs.getString("kp", null)
        if (b64 == null || pw == null) {   // first time on this device: generate once, reuse for all repos
            pw = Signing.password()
            val bytes = withContext(Dispatchers.Default) { Signing.generate(pw) }
            b64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
            prefs.edit().putString("ks", b64).putString("kp", pw).apply()
            saveBackup(bytes)
            keyInfo = "كلمة المرور: $pw\nالاسم المستعار: ${Signing.ALIAS}\nنسخة احتياطية في التنزيلات: CloudForge-signing-key.p12"
        }
        gh.setSecret(full, names[0], b64!!); gh.setSecret(full, names[1], pw!!); gh.setSecret(full, names[2], Signing.ALIAS)
        signed = true; toast = "تم حفظ مفتاح التوقيع الثابت في GitHub Secrets"
    }
    private fun saveBackup(bytes: ByteArray) {
        try {
            val cv = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, "CloudForge-signing-key.p12")
                put(MediaStore.Downloads.MIME_TYPE, "application/x-pkcs12")
            }
            val u = app.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)
            if (u != null) app.contentResolver.openOutputStream(u)?.use { it.write(bytes) }
        } catch (e: Exception) { }
    }

    fun rebuild(zip: String) = go {
        ensureSigning(repo!!)
        gh.ensureWorkflow(repo!!, branch, app.assets.open("build.yml").readBytes()); delay(2500)
        gh.dispatch(repo!!, branch, zip)
        toast = "بدأت إعادة البناء"; ensureWatch(); delay(1500); screen = "builds"
    }
    fun loadProjects() = go { projects = gh.projects(repo!!, branch) }
    /** Each part loads on its own: one failing call (e.g. no workflow runs yet) no longer blanks the whole screen. */
    private suspend fun refreshHome() {
        val r = repo ?: return
        try { projects = gh.projects(r, branch) } catch (e: CancellationException) { throw e } catch (e: ApiError) {
            if (e.code == 404) { repoGone(); return }; throw e }
        var first: Exception? = null
        try { runs = gh.runs(r, 50) } catch (e: CancellationException) { throw e } catch (e: Exception) { if (!(e is ApiError && e.code == 404)) first = e }
        try { releases = gh.releases(r) } catch (e: CancellationException) { throw e } catch (e: Exception) { if (first == null) first = e }
        if (runs.any { it.s("status") != "completed" }) ensureWatch()
        first?.let { throw it }
    }
    private fun repoGone() {
        prefs.edit().remove("r").remove("b").apply(); repo = null; projects = null; runs = emptyList(); releases = emptyList(); screen = "repos"
        error = "المستودع المحفوظ لم يعد متاحاً (حُذف أو أُعيدت تسميته). اختر مستودعاً من جديد."
    }
    fun loadHome() = go { refreshHome(); local = withContext(Dispatchers.IO) { scanLocal() } }
    /** Silent refresh used while a build is running. */
    suspend fun pollHome() {
        try { runs = gh.runs(repo!!, 50); releases = gh.releases(repo!!) } catch (e: CancellationException) { throw e } catch (e: Exception) { }
        if (runs.any { it.s("status") != "completed" }) ensureWatch()
        fetchActiveJobs()
    }
    /** Steps of every run that is still going: the projects screen turns them into a progress percentage. */
    private var watchJob: Job? = null
    private val tracked = mutableMapOf<Long, String>()   // running build id -> notification title
    /** Follows running cloud builds in the background: one ongoing notification per build (progress from its steps, cancel button), then a result notification. */
    fun ensureWatch() {
        val r = repo ?: return
        if (token == null || watchJob?.isActive == true) return
        watchJob = viewModelScope.launch {
            Notif.begin("watch")
            try {
                var idle = 0
                while (idle < 8 && repo == r) {
                    val rs = try { gh.runs(r, 50) } catch (e: CancellationException) { throw e } catch (e: Exception) { idle++; delay(6000); continue }
                    runs = rs
                    val active = rs.filter { it.s("status") != "completed" }
                    for (run in active) {
                        val id = run.getLong("id")
                        val js = try { gh.jobs(r, id) } catch (e: CancellationException) { throw e } catch (e: Exception) { jobs[id].orEmpty() }
                        jobs = jobs + (id to js)
                        val queued = run.s("status") == "queued" || js.none { it.s("name") != "Detect new zips" }
                        val pct = (runProgress(js) * 100).toInt().coerceIn(0, 99)
                        val step = js.filter { it.s("name") != "Detect new zips" }.flatMap { it.optJSONArray("steps")?.list().orEmpty() }.firstOrNull { it.s("status") == "in_progress" }?.s("name")
                        val title = "بناء #${run.getInt("run_number")} · ${runKey(run)}"
                        tracked[id] = title
                        Notif.progress(Notif.idRun(id), title, if (queued) "بالانتظار…" else "$pct%" + (step?.let { " · $it" } ?: ""), if (queued) null else pct, "run", id)
                    }
                    val finished = tracked.keys.filter { id -> active.none { it.getLong("id") == id } }
                    if (finished.isNotEmpty()) releases = try { gh.releases(r) } catch (e: CancellationException) { throw e } catch (e: Exception) { releases }
                    for (id in finished) {
                        val title = tracked.remove(id) ?: continue
                        val run = rs.firstOrNull { it.getLong("id") == id }; val nid = Notif.idRun(id)
                        when {
                            run == null || run.s("conclusion") == "cancelled" -> Notif.cancel(nid)
                            run.s("conclusion") == "success" -> Notif.done(nid, "اكتمل البناء", title)
                            else -> Notif.error(nid, "فشل البناء", title)
                        }
                    }
                    idle = if (active.isEmpty() && tracked.isEmpty()) idle + 1 else 0
                    delay(5000)
                }
            } finally {
                Notif.end("watch")
                tracked.keys.forEach { Notif.cancel(Notif.idRun(it)) }; tracked.clear()
            }
        }
    }
    suspend fun fetchActiveJobs() {
        val r = repo ?: return
        for (run in runs.filter { it.s("status") != "completed" }) {
            try { val id = run.getLong("id"); jobs = jobs + (id to gh.jobs(r, id)) }
            catch (e: CancellationException) { throw e } catch (e: Exception) { }
        }
    }
    /** Uploads projects/<folder>/<name>.zip (new project, or replaces the existing zip of that project). */
    fun upload(uri: Uri, name: String, folder: String) {
        upJob = go {
            val nid = Notif.ID_UPLOAD; val title = "رفع المشروع $folder"
            Notif.begin("up"); Notif.progress(nid, title, "جارٍ التحضير…", null, "up")
            try {
                up = UpState("prep", 0, 0)
                ensureSigning(repo!!)
                gh.ensureWorkflow(repo!!, branch, app.assets.open("build.yml").readBytes())
                val bytes = withContext(Dispatchers.IO) { app.contentResolver.openInputStream(uri)!!.use { it.readBytes() } }
                var lastPct = -1; var lastT = 0L
                val p = gh.upload(repo!!, branch, folder, name, bytes,
                    onStage = { s -> up = UpState(s, 0, bytes.size.toLong())
                        Notif.progress(nid, title, if (s == "commit") "إنهاء الرفع…" else "جارٍ الرفع…", null, "up") },
                    onProgress = { d, t -> val pct = if (t > 0) (d * 100 / t).toInt() else 0
                        if (pct != lastPct) {
                            lastPct = pct; up = UpState("upload", d, t)
                            val now = System.nanoTime()
                            if (now - lastT > 400_000_000L || pct == 100) { lastT = now; Notif.progress(nid, title, "$pct% · ${sz(d)} / ${sz(t)}", pct, "up") }
                        } })
                up = UpState("done", bytes.size.toLong(), bytes.size.toLong())
                toast = "تم الرفع: $p"
                Notif.done(nid, "تم رفع $folder", "بدأ البناء السحابي تلقائياً")
                projects = gh.projects(repo!!, branch); uploadTarget = null; screen = "builds"
                ensureWatch()
            } catch (e: CancellationException) { Notif.cancel(nid); throw e
            } catch (e: Exception) { taskFail(nid, "فشل رفع $folder", e.message ?: e.toString()); throw e
            } finally { up = null; Notif.end("up") }
        }
    }
    fun cancelUpload() { upJob?.cancel(); up = null; Notif.cancel(Notif.ID_UPLOAD); toast = "أُلغي الرفع" }

    suspend fun refreshRuns() {
        try {
            runs = gh.runs(repo!!, 50)
            val o = open
            if (o != null) jobs = jobs + (o to gh.jobs(repo!!, o))
        } catch (e: CancellationException) { throw e } catch (e: Exception) { }
    }
    fun toggle(id: Long) {
        open = if (open == id) null else id
        if (open != null) viewModelScope.launch {
            try { jobs = jobs + (id to gh.jobs(repo!!, id)) } catch (e: CancellationException) { throw e } catch (e: Exception) { }
        }
    }
    fun showLog(job: Long) = go { logs = logs + (job to gh.log(repo!!, job)) }
    fun cancelRun(id: Long) = go { gh.cancel(repo!!, id); refreshRuns() }

    private suspend fun fetchArchive() {
        val rs = gh.runs(repo!!, 60); val rel = gh.releases(repo!!)
        archive = rs.map { r -> r to rel.filter { it.getString("tag_name").startsWith("cf-${r.getLong("id")}-") } }
            .filter { it.second.isNotEmpty() || failed(it.first) }
    }
    fun loadArchive() = go { fetchArchive() }

    /* ── pull-to-refresh: silent, errors go to the snackbar, never a crash ── */
    private suspend fun quiet(b: suspend () -> Unit) { try { b() } catch (e: CancellationException) { throw e } catch (e: Exception) { error = e.message ?: e.toString() } }
    suspend fun pullHome() { quiet { refreshHome() }; quiet { local = withContext(Dispatchers.IO) { scanLocal() } }; fetchActiveJobs() }
    suspend fun pullRepos() { quiet { repos = gh.repos() } }
    suspend fun pullProjects() { quiet { projects = gh.projects(repo!!, branch) } }
    suspend fun pullBuilds() { quiet { projects = gh.projects(repo!!, branch) }; refreshRuns() }
    suspend fun pullArchive() { quiet { projects = gh.projects(repo!!, branch); fetchArchive() }; quiet { local = withContext(Dispatchers.IO) { scanLocal() } } }

    /** Archive clean-up for one project: deletes every build run + APK package except [keepRunId], and every downloaded APK except the one of that kept build. */
    fun cleanProject(folder: String, keepRunId: Long?) = go {
        val r = repo!!
        val rels = gh.releases(r)
        val keepTag = keepRunId?.let { "cf-$it-" }
        val keepRel = keepTag?.let { t -> rels.firstOrNull { it.getString("tag_name").startsWith(t) } }
        gh.runs(r, 100).filter { runKey(it) == folder && it.getLong("id") != keepRunId && it.s("status") == "completed" }.forEach { removeRun(it, rels) }
        if (keepTag != null)   // packages that no longer belong to any run
            gh.releases(r).filter { relKey(it) == folder && !it.getString("tag_name").startsWith(keepTag) }.forEach { gh.deleteRelease(r, it.getLong("id"), it.getString("tag_name")) }
        val res = app.contentResolver
        val files = withContext(Dispatchers.IO) { scanLocal() }
        val keepLocal = keepRel?.let { rel -> files.firstOrNull { it.folder == folderOf(rel) && it.stamp == stampOf(rel) && it.base == apkBase(rel) } }
        var removed = 0
        withContext(Dispatchers.IO) { files.filter { it.folder == folder && it != keepLocal }.forEach { f -> try { if (res.delete(f.uri, null, null) > 0) removed++ } catch (e: Exception) { } } }
        refreshAll(); local = withContext(Dispatchers.IO) { scanLocal() }
        toast = "تم التنظيف: بقي آخر بناء فقط" + if (removed > 0) " وحُذف $removed ملف محمّل" else ""
    }

    fun projectKeys(): List<String> {
        val k = (projects?.folders.orEmpty() + runs.map { runKey(it) } + archive.map { runKey(it.first) } + releases.map { relKey(it) }).distinct()
        return k.filter { it != OTHER } + (if (k.contains(OTHER)) listOf(OTHER) else emptyList())
    }
    private suspend fun removeRun(run: JSONObject, rels: List<JSONObject>) {
        val id = run.getLong("id")
        rels.filter { it.getString("tag_name").startsWith("cf-$id-") }.forEach { gh.deleteRelease(repo!!, it.getLong("id"), it.getString("tag_name")) }
        gh.deleteRun(repo!!, id)
    }
    private suspend fun refreshAll() { runs = gh.runs(repo!!, 50); releases = gh.releases(repo!!); fetchArchive(); open = null }
    /** Deletes whole build runs: their log AND the APK release they produced. */
    fun deleteRuns(list: List<JSONObject>) = go {
        val rels = gh.releases(repo!!)
        list.forEach { removeRun(it, rels) }
        refreshAll(); toast = "تم حذف عمليات البناء"
    }
    /** Deletes projects/<folder>/ (zip + apk) from the repo, and optionally every build run / release of that project. */
    fun deleteProject(folder: String, withBuilds: Boolean) = go {
        gh.projects(repo!!, branch).items.filter { it.first.startsWith("projects/$folder/") }.forEach { gh.deleteFile(repo!!, branch, it.first) }
        if (withBuilds) {
            val rels = gh.releases(repo!!)
            gh.runs(repo!!, 50).filter { runKey(it) == folder && it.s("status") == "completed" }.forEach { removeRun(it, rels) }
            gh.releases(repo!!).filter { relKey(it) == folder }.forEach { gh.deleteRelease(repo!!, it.getLong("id"), it.getString("tag_name")) }
        }
        projects = gh.projects(repo!!, branch); runs = gh.runs(repo!!, 50); releases = gh.releases(repo!!)
        toast = "تم حذف المشروع $folder"
    }

    fun openRepoInfo() { showRepo = true; repoInfo = null; go { repoInfo = gh.repoInfo(repo!!) } }
    fun renameRepo(n: String) = go {
        val j = gh.renameRepo(repo!!, clean(n)); val full = j.getString("full_name")
        repo = full; prefs.edit().putString("r", full).apply(); repoInfo = j; toast = "تمت إعادة التسمية: $full"
    }
    fun deleteRepo() = go {
        try { gh.deleteRepo(repo!!) } catch (e: ApiError) {
            if (e.message?.contains("GitHub 403") == true || e.message?.contains("GitHub 404") == true)
                throw ApiError("صلاحية حذف المستودع غير ممنوحة لهذا الحساب. سجّل الخروج ثم ادخل من جديد وسيطلبها GitHub.")
            throw e
        }
        prefs.edit().remove("r").apply()
        showRepo = false; repoInfo = null; repo = null; projects = null; runs = emptyList(); releases = emptyList(); archive = emptyList(); signed = false
        screen = "repos"; toast = "تم حذف المستودع"
    }
    fun delete(rel: JSONObject) = go { gh.deleteRelease(repo!!, rel.getLong("id"), rel.getString("tag_name")); fetchArchive() }
    /* ── local APKs: Downloads/<project>/<name>_<build time>.apk ── */
    private fun scanLocal(): List<LocalApk> {
        val res = app.contentResolver; val out = mutableListOf<LocalApk>()
        val root = "${Environment.DIRECTORY_DOWNLOADS}/$APK_ROOT/"
        res.query(MediaStore.Downloads.EXTERNAL_CONTENT_URI,
            arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.RELATIVE_PATH),
            "${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ?", arrayOf("$root%"), null)?.use { c ->
            while (c.moveToNext()) {
                val m = LOCAL_RE.matchEntire(c.getString(1) ?: continue) ?: continue
                val folder = (c.getString(2) ?: continue).removePrefix(root).trim('/')
                if (folder.isEmpty()) continue
                val u = ContentUris.withAppendedId(MediaStore.Downloads.EXTERNAL_CONTENT_URI, c.getLong(0))
                try { res.openFileDescriptor(u, "r")?.close() ?: continue } catch (e: Exception) { continue }   // deleted by the user: ignore
                out += LocalApk(folder, m.groupValues[1], m.groupValues[2], u)
            }
        }
        return out
    }
    fun refreshLocal() { viewModelScope.launch { local = try { withContext(Dispatchers.IO) { scanLocal() } } catch (e: CancellationException) { throw e } catch (e: Exception) { local } } }
    /** The saved file of exactly this build (same project, same build time), if any. */
    fun localFor(rel: JSONObject) = local.firstOrNull { it.folder == folderOf(rel) && it.stamp == stampOf(rel) && it.base == apkBase(rel) }
    /** Newest saved APK of a project, used when no online build is known. */
    fun latestLocal(folder: String) = local.filter { it.folder == folder }.maxByOrNull { it.stamp }

    fun install(uri: Uri) {
        try {
            app.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive")
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION))
        } catch (e: Exception) { error = "تعذر فتح المثبّت: ${e.message}" }
    }
    /** Already saved -> install it; otherwise download it (with progress) into Downloads/<project>/ and then install. */
    fun getOrInstall(rel: JSONObject) {
        localFor(rel)?.let { install(it.uri); return }
        download(rel)
    }
    /** Cancels right away: the card and the notification disappear immediately, and the socket is aborted. */
    fun cancelDownload(assetId: Long) { dlJobs.remove(assetId)?.cancel(); dl = dl - assetId; Notif.cancel(Notif.idDownload(assetId)) }

    private fun download(rel: JSONObject) {
        val a = assetOf(rel) ?: return; val aid = a.getLong("id")
        if (dlJobs[aid]?.isActive == true) return
        val folder = folderOf(rel); val name = "${apkBase(rel)}_${stampOf(rel)}.apk"; val size = a.optLong("size")
        val nid = Notif.idDownload(aid); val nkey = "dl$aid"; val title = "تحميل $name"
        dlJobs[aid] = viewModelScope.launch {
            val me = coroutineContext[Job]
            val res = app.contentResolver
            var uri: Uri? = null; var done = false
            Notif.begin(nkey); Notif.progress(nid, title, "جارٍ البدء…", null, "dl", aid)
            try {
                dl = dl + (aid to (0L to size))
                val cv = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.MIME_TYPE, "application/vnd.android.package-archive")
                    put(MediaStore.Downloads.RELATIVE_PATH, "${Environment.DIRECTORY_DOWNLOADS}/$APK_ROOT/$folder")
                    put(MediaStore.Downloads.IS_PENDING, 1)      // hidden until complete: a half-downloaded file is never mistaken for an installable one
                }
                uri = res.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv) ?: throw ApiError("تعذر إنشاء الملف في التنزيلات")
                var attempt = 0
                while (true) {      // a dropped connection restarts the download (up to 3 tries) instead of failing at the first glitch
                    var lastPct = -1; var lastT = 0L; var lastN = 0L
                    try {
                        res.openOutputStream(uri, "wt")!!.use { out ->
                            gh.download(repo!!, aid, size, out) { d, t ->
                                val pct = if (t > 0) (d * 100 / t).toInt() else 0
                                val now = System.nanoTime()
                                if (pct != lastPct && (now - lastT > 100_000_000L || pct == 100)) {   // at most ~10 UI updates per second
                                    lastPct = pct; lastT = now
                                    viewModelScope.launch { if (dlJobs[aid] === me) dl = dl + (aid to (d to t)) }
                                }
                                if (now - lastN > 500_000_000L && dlJobs[aid] === me) {
                                    lastN = now; Notif.progress(nid, title, "$pct% · ${sz(d)} / ${sz(t)}", pct, "dl", aid)
                                }
                            }
                        }
                        break
                    } catch (e: CancellationException) { throw e
                    } catch (e: Exception) {
                        attempt++
                        val transient = e is java.io.IOException || (e is ApiError && e.message?.startsWith("GitHub 5") == true)
                        if (attempt >= 3 || !transient) throw e
                        dl = dl + (aid to (0L to size))
                        Notif.progress(nid, title, "انقطع الاتصال، إعادة المحاولة ($attempt/2)…", null, "dl", aid)
                        delay(1500L * attempt)
                    }
                }
                res.update(uri, ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }, null, null)
                done = true
                local = withContext(Dispatchers.IO) { scanLocal() }
                toast = "تم الحفظ في التنزيلات/$APK_ROOT/$folder: $name"
                Notif.done(nid, "اكتمل التحميل", "$name · ${sz(size)}")
                install(uri)
            } catch (e: CancellationException) {
                Notif.cancel(nid); throw e
            } catch (e: Exception) {
                val m = e.message ?: e.toString()
                taskFail(nid, "فشل تحميل $name", m); error = m
            } finally {
                if (!done && uri != null) try { res.delete(uri, null, null) } catch (e: Exception) { }   // only our own unfinished partial file
                if (dlJobs[aid] === me) { dl = dl - aid; dlJobs.remove(aid) }
                Notif.end(nkey)
            }
        }
    }
}

/* ───────────── theme ───────────── */
object Cl {
    val bg = Color(0xFF0B0E14); val surface = Color(0xFF131720); val raised = Color(0xFF1A2030)
    val line = Color(0xFF262D3F); val text = Color(0xFFE8EBF4); val muted = Color(0xFF8E96AB)
    val accent = Color(0xFF8B92FF); val ok = Color(0xFF3DD68C); val warn = Color(0xFFF5B544); val bad = Color(0xFFF26D6D)
}
private val Scheme = darkColorScheme(
    primary = Cl.accent, onPrimary = Cl.bg, primaryContainer = Color(0xFF232A52), onPrimaryContainer = Cl.text,
    secondaryContainer = Color(0xFF232A52), onSecondaryContainer = Cl.text,
    background = Cl.bg, onBackground = Cl.text, surface = Cl.surface, onSurface = Cl.text,
    surfaceVariant = Cl.raised, onSurfaceVariant = Cl.muted, outline = Cl.line, outlineVariant = Cl.line,
    error = Cl.bad, surfaceContainer = Cl.surface, surfaceContainerHigh = Cl.raised, surfaceContainerHighest = Cl.raised,
)

/* ───────────── UI ───────────── */
class MainActivity : ComponentActivity() {
    private val vm: VM by viewModels()
    private val askNotif = registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.RequestPermission()) { }
    override fun onStart() { super.onStart(); Notif.fg = true }
    override fun onStop() { Notif.fg = false; super.onStop() }
    override fun onResume() { super.onResume(); vm.refreshLocal() }   // the user may have deleted / moved files meanwhile
    override fun onCreate(s: Bundle?) {
        installSplashScreen()
        super.onCreate(s)
        if (android.os.Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED)
            askNotif.launch(android.Manifest.permission.POST_NOTIFICATIONS)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT))
        setContent {
            MaterialTheme(colorScheme = Scheme) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) { App() }
            }
        }
    }
}

@Composable fun Ico(v: ImageVector, tint: Color = LocalContentColor.current, size: Dp = 20.dp) =
    Icon(v, null, Modifier.size(size), tint)

@Composable fun Card2(content: @Composable ColumnScope.() -> Unit) =
    Card(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp), shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Cl.surface), border = BorderStroke(1.dp, Cl.line)) {
        Column(Modifier.padding(16.dp), content = content)
    }

@Composable fun Head(icon: ImageVector, text: String) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 10.dp)) {
        Box(Modifier.size(32.dp).clip(RoundedCornerShape(10.dp)).background(Cl.accent.copy(alpha = .14f)), contentAlignment = Alignment.Center) { Ico(icon, Cl.accent, 18.dp) }
        Spacer(Modifier.width(10.dp))
        Text(text, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
    }
}

@Composable fun Muted(t: String, size: Int = 12, mono: Boolean = false, color: Color = Cl.muted) =
    Text(t, color = color, fontSize = size.sp, fontFamily = if (mono) FontFamily.Monospace else FontFamily.Default)

@Composable fun Empty(icon: ImageVector, text: String) =
    Column(Modifier.fillMaxWidth().padding(vertical = 28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Ico(icon, Cl.muted, 34.dp); Spacer(Modifier.height(10.dp)); Muted(text, 13)
    }

@Composable fun StatusChip(st: String, c: String) {
    val (t, col, ic) = when {
        st != "completed" -> Triple(if (st == "queued") "بالانتظار" else "جارٍ", Cl.warn, Ic.Clock)
        c == "success" -> Triple("نجح", Cl.ok, Ic.CheckCircle)
        c == "cancelled" -> Triple("أُلغي", Cl.muted, Ic.Ban)
        c == "skipped" -> Triple("تخطي", Cl.muted, Ic.Ban)
        else -> Triple("فشل", Cl.bad, Ic.XCircle)
    }
    Row(Modifier.clip(RoundedCornerShape(50)).background(col.copy(alpha = .14f)).padding(horizontal = 10.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Ico(ic, col, 14.dp); Spacer(Modifier.width(5.dp)); Text(t, color = col, fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}

/** Build progress of a run = finished steps / all steps of its build jobs (the "Detect new zips" job is not counted). */
fun runProgress(jobs: List<JSONObject>?): Float {
    val steps = jobs.orEmpty().filter { it.s("name") != "Detect new zips" }.flatMap { it.optJSONArray("steps")?.list().orEmpty() }
    if (steps.isEmpty()) return 0f
    return steps.count { it.s("status") == "completed" }.toFloat() / steps.size
}

/** Small circle for the project cards: yellow arc + percentage while building; turns green "نجح" or fills red "فشل". */
@Composable fun RunRing(st: String, c: String, frac: Float, size: Dp = 40.dp) {
    val done = st == "completed"
    val ok = done && c == "success"
    val neutral = done && (c == "cancelled" || c == "skipped")
    val bad = done && !ok && !neutral
    val target = when { done -> 1f; else -> frac.coerceIn(0f, 1f) }
    val shown by animateFloatAsState(target, tween(600), label = "ringProgress")
    val col by animateColorAsState(when { ok -> Cl.ok; bad -> Cl.bad; neutral -> Cl.muted; else -> Cl.warn }, tween(500), label = "ringColor")
    val fill by animateFloatAsState(if (bad) 1f else 0f, tween(500), label = "ringFill")
    val label = when {
        ok -> "نجح"; bad -> "فشل"; neutral -> if (c == "cancelled") "أُلغي" else "تخطي"
        else -> "${(shown * 100).toInt().coerceIn(0, 99)}%"
    }
    Box(Modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val w = 3.5.dp.toPx()
            val inset = w / 2
            val arcSize = androidx.compose.ui.geometry.Size(this.size.width - w, this.size.height - w)
            val tl = androidx.compose.ui.geometry.Offset(inset, inset)
            if (fill > 0f) drawCircle(col.copy(alpha = fill))
            drawCircle(col.copy(alpha = .2f), radius = (this.size.minDimension - w) / 2, style = Stroke(w))
            if (shown > 0f) drawArc(col, -90f, 360f * shown, false, tl, arcSize, style = Stroke(w, cap = if (shown >= 1f) StrokeCap.Butt else StrokeCap.Round))
        }
        Text(label, color = if (bad) Color.White else col, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
    }
}

/** Pull down to refresh, like a browser. [onRefresh] runs while the indicator spins. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable fun Pull(onRefresh: suspend () -> Unit, modifier: Modifier = Modifier.fillMaxSize(), content: @Composable () -> Unit) {
    var refreshing by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val st = rememberPullToRefreshState()
    PullToRefreshBox(isRefreshing = refreshing, state = st, modifier = modifier.fillMaxWidth(),
        onRefresh = { if (!refreshing) scope.launch { refreshing = true; try { onRefresh() } finally { refreshing = false } } },
        indicator = { PullToRefreshDefaults.Indicator(state = st, isRefreshing = refreshing, modifier = Modifier.align(Alignment.TopCenter), containerColor = Cl.raised, color = Cl.accent) }) { content() }
}

@Composable fun PLazy(onRefresh: suspend () -> Unit, modifier: Modifier = Modifier.fillMaxSize(), contentPadding: PaddingValues = PaddingValues(0.dp), content: LazyListScope.() -> Unit) =
    Pull(onRefresh, modifier) { LazyColumn(Modifier.fillMaxSize(), contentPadding = contentPadding, content = content) }

/** Full button with a container + border (instead of bare text) for actions inside cards and lists. */
@Composable fun CardBtn(icon: ImageVector, text: String, tint: Color, enabled: Boolean = true, modifier: Modifier = Modifier.fillMaxWidth().padding(top = 8.dp), onClick: () -> Unit) =
    OutlinedButton(onClick = onClick, enabled = enabled, shape = RoundedCornerShape(12.dp), border = BorderStroke(1.dp, tint.copy(alpha = if (enabled) .5f else .25f)), modifier = modifier) { BtnLabel(icon, text, tint) }

/** Replacement for TextButton everywhere (dialogs etc.): same API, but drawn as a real button. */
@Composable fun FrameButton(onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true, content: @Composable RowScope.() -> Unit) =
    OutlinedButton(onClick = onClick, modifier = modifier, enabled = enabled, shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, Cl.muted.copy(alpha = if (enabled) .4f else .2f)), content = content)

/** Side-menu row with its own press effect (scale + highlight) that does not depend on the ripple colour. */
@Composable fun DrawerItem(icon: ImageVector, label: String, selected: Boolean, onClick: () -> Unit) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) .95f else 1f, tween(110), label = "drawerItemScale")
    val bg by animateColorAsState(when { pressed -> Cl.accent.copy(alpha = .30f); selected -> Cl.accent.copy(alpha = .16f); else -> Color.Transparent }, tween(110), label = "drawerItemBg")
    Row(Modifier.padding(horizontal = 12.dp, vertical = 2.dp).fillMaxWidth().height(52.dp)
        .graphicsLayer { scaleX = scale; scaleY = scale }
        .clip(RoundedCornerShape(28.dp)).background(bg)
        .clickable(interactionSource = src, indication = null, onClick = onClick).padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Ico(icon, if (selected) Cl.accent else Cl.muted, 22.dp); Spacer(Modifier.width(12.dp))
        Text(label, color = if (selected) Cl.accent else Cl.text, fontSize = 14.sp, fontWeight = FontWeight.Medium)
    }
}

/** Bottom message bar: long messages are fully readable and the action (copy) sits on its own line. */
@Composable fun CfSnackHost(s: SnackbarHostState) = SnackbarHost(s) { d ->
    Snackbar(d, actionOnNewLine = true, shape = RoundedCornerShape(14.dp), containerColor = Cl.raised, contentColor = Cl.text,
        actionColor = Cl.accent, dismissActionContentColor = Cl.muted)
}

@Composable fun BtnLabel(icon: ImageVector, text: String, tint: Color = LocalContentColor.current) {
    Ico(icon, tint, 18.dp); Spacer(Modifier.width(8.dp)); Text(text, color = tint)
}

/** Progress of a running download: bar, percentage, size, cancel. Nothing when this release is not downloading. */
@Composable fun DlProgress(vm: VM, rel: JSONObject?) {
    val aid = rel?.let { assetOf(it)?.getLong("id") } ?: return
    val (d, t) = vm.dl[aid] ?: return
    val pct = if (t > 0) (d * 100 / t).toInt().coerceIn(0, 100) else 0
    Column(Modifier.fillMaxWidth().padding(bottom = 10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("$pct%", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Cl.accent)
            Spacer(Modifier.width(8.dp)); Muted("${sz(d)} / ${sz(t)}", 12)
            Spacer(Modifier.weight(1f))
            IconButton(onClick = { vm.cancelDownload(aid) }, modifier = Modifier.size(28.dp)) { Ico(Ic.Close, Cl.muted, 18.dp) }
        }
        Spacer(Modifier.height(4.dp))
        LinearProgressIndicator(progress = { if (t > 0) (d.toFloat() / t).coerceIn(0f, 1f) else 0f }, modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
            color = Cl.accent, trackColor = Cl.line)
    }
}

/** "Install" when this exact build is already in Downloads/<project>/, otherwise "Download". [rel] null = no online build known. */
@Composable fun ApkButton(vm: VM, rel: JSONObject?, folder: String, modifier: Modifier, downloadLabel: String = "تحميل") {
    val aid = rel?.let { assetOf(it)?.getLong("id") }
    val busy = aid != null && vm.dl.containsKey(aid)
    val saved = if (rel != null) vm.localFor(rel) else vm.latestLocal(folder)
    when {
        busy -> Button(onClick = {}, enabled = false, shape = RoundedCornerShape(12.dp), contentPadding = PaddingValues(horizontal = 6.dp), modifier = modifier) { BtnLabel(Ic.Download, "جارٍ التحميل") }
        saved != null -> Button(onClick = { vm.install(saved.uri) }, shape = RoundedCornerShape(12.dp), contentPadding = PaddingValues(horizontal = 6.dp), modifier = modifier) { BtnLabel(Ic.Package, "تثبيت") }
        else -> Button(onClick = { vm.getOrInstall(rel!!) }, enabled = rel != null && assetOf(rel) != null, shape = RoundedCornerShape(12.dp), contentPadding = PaddingValues(horizontal = 6.dp), modifier = modifier) { BtnLabel(Ic.Download, downloadLabel) }
    }
}

@Composable fun TopBar(vm: VM, onMenu: () -> Unit) {
    Column(Modifier.fillMaxWidth().background(Cl.bg).statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().height(56.dp).padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onMenu) { Ico(Ic.Menu, Cl.text, 24.dp) }
            Spacer(Modifier.width(2.dp))
            Text("CloudForge", fontWeight = FontWeight.Bold, fontSize = 19.sp)
            Spacer(Modifier.weight(1f))
            vm.repo?.let { r ->
                Row(Modifier.clip(RoundedCornerShape(10.dp)).background(Cl.raised).clickable { vm.openRepoInfo() }.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Muted(r.substringAfter('/'), 12, true); Spacer(Modifier.width(6.dp)); Ico(Ic.Info, Cl.muted, 14.dp)
                }
            }
            Spacer(Modifier.width(12.dp))
        }
        HorizontalDivider(color = Cl.line)
    }
}

/** Side menu that is a pure function of the finger: [frac] 0 = closed .. 1 = open. While dragging it follows the finger 1:1; on release it settles by velocity/position. */
class DrawerCtl(private val scope: CoroutineScope) {
    var frac by mutableFloatStateOf(0f); private set
    val opened by derivedStateOf { frac > 0f }
    private var job: Job? = null
    fun drag(d: Float) { job?.cancel(); frac = (frac + d).coerceIn(0f, 1f) }
    private fun settle(to: Float, v: Float = 0f) {
        job?.cancel()
        job = scope.launch { animate(frac, to, v, spring(dampingRatio = 1f, stiffness = Spring.StiffnessMediumLow)) { x, _ -> frac = x.coerceIn(0f, 1f) } }
    }
    fun open() = settle(1f)
    fun close() = settle(0f)
    /** [v] = fraction per second, positive = opening. */
    fun release(v: Float) = settle(if (v > 1.2f) 1f else if (v < -1.2f) 0f else if (frac > .5f) 1f else 0f, v)
}

@Composable fun App(vm: VM = viewModel()) {
    val snack = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope(); val drawer = remember { DrawerCtl(scope) }
    val clipM = LocalClipboardManager.current
    LaunchedEffect(vm.error) { vm.error?.let { msg ->
        val r = snack.showSnackbar(msg, actionLabel = "نسخ", withDismissAction = true, duration = SnackbarDuration.Long)
        if (r == SnackbarResult.ActionPerformed) { clipM.setText(AnnotatedString(msg)); vm.toast = "تم نسخ رسالة الخطأ" }
        vm.error = null
    } }
    LaunchedEffect(vm.token, vm.repo) { if (vm.token != null && vm.repo != null) vm.checkSigning() }
    LaunchedEffect(vm.toast) { vm.toast?.let { snack.showSnackbar(it); vm.toast = null } }
    vm.keyInfo?.let { k -> AlertDialog(onDismissRequest = {}, icon = { Ico(Ic.Key, Cl.accent, 28.dp) }, title = { Text("احفظ مفتاح التوقيع") },
        text = { Text("$k\n\nالمفتاح محفوظ في GitHub Secrets ولا يمكن قراءته منها لاحقاً. إن فقدته لن تُحدَّث تطبيقاتك المثبتة، فاحتفظ بالنسخة الاحتياطية.") },
        confirmButton = { FrameButton(onClick = { vm.keyInfo = null }) { Text("فهمت") } }) }
    if (vm.token == null) { if (vm.code != null) AuthScreen(vm) else Scaffold(containerColor = Cl.bg, snackbarHost = { CfSnackHost(snack) }) { Box(Modifier.padding(it)) { Login(vm) } }; return }
    val scr = if (vm.repo == null) "repos" else vm.screen
    fun nav(x: String) { vm.screen = x; drawer.close() }
    BackHandler(enabled = scr != "home" && vm.repo != null) { vm.screen = "home" }
    BackHandler(enabled = drawer.opened) { drawer.close() }
    val widthPx = with(LocalDensity.current) { 250.dp.toPx() }
    // one drag state for the edge strip, the scrim and the sheet: finger left = more open (the menu lives on the right in RTL)
    val dragState = rememberDraggableState { dx -> drawer.drag(-dx / widthPx) }
    val dragMod = Modifier.draggable(dragState, Orientation.Horizontal, onDragStopped = { vx -> drawer.release(-vx / widthPx) })

    Box(Modifier.fillMaxSize()) {
        Scaffold(containerColor = Cl.bg, snackbarHost = { CfSnackHost(snack) }, topBar = { TopBar(vm) { drawer.open() } }) { pad ->
            Column(Modifier.padding(pad).fillMaxSize()) {
                if (vm.busy) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Cl.accent, trackColor = Cl.line)
                when (scr) {
                    "repos" -> RepoScreen(vm)
                    "upload" -> UploadScreen(vm)
                    "builds" -> BuildScreen(vm)
                    "archive" -> ArchiveScreen(vm)
                    else -> HomeScreen(vm)
                }
            }
        }

        // edge strip: always composed so a gesture that starts here keeps tracking after the menu appears
        // starts BELOW the top bar so it never covers the menu button
        val stripTop = WindowInsets.statusBars.asPaddingValues().calculateTopPadding() + 58.dp
        Box(Modifier.align(Alignment.TopStart).padding(top = stripTop).fillMaxHeight().width(24.dp).then(dragMod))

        if (drawer.opened) Box(Modifier.fillMaxSize()
            .drawBehind { drawRect(Color.Black.copy(alpha = .55f * drawer.frac)) }
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { drawer.close() }
            .then(dragMod)) {
            Column(Modifier.align(Alignment.CenterStart).fillMaxHeight().width(250.dp)
                .graphicsLayer { translationX = (1f - drawer.frac) * widthPx }   // absolute px: +x = off-screen to the right
                .background(Cl.surface, RoundedCornerShape(topEnd = 24.dp, bottomEnd = 24.dp))
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { }
                .statusBarsPadding().navigationBarsPadding()) {
            Column(Modifier.padding(20.dp)) {
                Box(Modifier.size(52.dp).clip(RoundedCornerShape(16.dp)).background(Brush.linearGradient(listOf(Color(0xFF6D74FF), Color(0xFF9B6BFF)))), contentAlignment = Alignment.Center) { Ico(Ic.Cloud, Color.White, 28.dp) }
                Spacer(Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.Bottom) {
                    Text("CloudForge", color = Cl.text, fontWeight = FontWeight.Bold, fontSize = 20.sp, modifier = Modifier.alignByBaseline()); Spacer(Modifier.width(8.dp))
                    Text("v${BuildConfig.VERSION_NAME}", color = Cl.muted, fontSize = 13.sp, fontWeight = FontWeight.Medium, modifier = Modifier.alignByBaseline())
                }
                Muted(if (vm.user.isNotEmpty()) "@${vm.user}" else "", 13)
                vm.repo?.let { Muted(it, 11, true) }
            }
            HorizontalDivider(color = Cl.line, modifier = Modifier.padding(bottom = 8.dp))
            @Composable fun item(id: String, icon: ImageVector, label: String, sel: Boolean = scr == id, go: () -> Unit = { nav(id) }) =
                DrawerItem(icon, label, sel, go)
            item("home", Ic.Folder, "المشاريع")
            item("repos", Ic.Plus, "إنشاء مشروع جديد")
            if (vm.repo != null) item("upload", Ic.CloudUpload, "رفع / تحديث مشروع")
            item("builds", Ic.Wrench, "عمليات البناء")
            item("archive", Ic.Archive, "الأرشيف")
            Spacer(Modifier.weight(1f))
            HorizontalDivider(color = Cl.line)
            item("", Ic.LogOut, "تسجيل الخروج", false) { drawer.close(); vm.logout() }
            Spacer(Modifier.height(12.dp))
            }
        }
        RepoInfoDialog(vm)
    }
}

@Composable fun Login(vm: VM) {
    Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF171C3A), Cl.bg))).padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Box(Modifier.size(88.dp).clip(RoundedCornerShape(28.dp))
            .background(Brush.linearGradient(listOf(Color(0xFF6D74FF), Color(0xFF9B6BFF)))), contentAlignment = Alignment.Center) {
            Ico(Ic.Cloud, Color.White, 46.dp)
        }
        Spacer(Modifier.height(22.dp))
        Text("CloudForge", fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("ارفع مشروعك كملف ZIP، انتظر قليلاً، واستلم APK جاهزاً.\nيتم البناء على GitHub Actions في مستودعك.",
            textAlign = TextAlign.Center, color = Cl.muted, fontSize = 14.sp, lineHeight = 22.sp)
        Spacer(Modifier.height(36.dp))
        Button(onClick = { vm.login() }, enabled = !vm.connecting, shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth().height(54.dp)) {
            if (vm.connecting) CircularProgressIndicator(Modifier.size(20.dp), color = Cl.bg, strokeWidth = 2.dp)
            else BtnLabel(Ic.Github, "الربط مع GitHub")
        }
        Spacer(Modifier.height(10.dp))
        OutlinedButton(onClick = { vm.tokenDialog = true }, enabled = !vm.connecting, shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth().height(50.dp)) { BtnLabel(Ic.Key, "الدخول باستخدام توكين") }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).clickable { vm.setWebView(!vm.useWebView) }.padding(horizontal = 6.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("عدم فتح المتصفح (WebView داخل التطبيق)", fontSize = 13.sp)
                Muted(if (vm.useWebView) "مفعّل: ستظهر صفحة GitHub داخل التطبيق" else "معطّل: تُفتح صفحة GitHub في المتصفح", 11)
            }
            Switch(checked = vm.useWebView, onCheckedChange = { vm.setWebView(it) })
        }
        Spacer(Modifier.height(10.dp))
        Muted(if (vm.useWebView) "ستظهر صفحة GitHub داخل التطبيق، وافق وسيُكمل الربط تلقائياً." else "ستفتح صفحة GitHub في متصفحك فوق التطبيق بحسابك المحفوظ، وافق وارجع.", 12)
    }
    if (vm.tokenDialog) {
        var tk by remember { mutableStateOf("") }
        AlertDialog(onDismissRequest = { if (!vm.connecting) vm.tokenDialog = false },
            title = { Text("الدخول بتوكين") },
            text = { Column {
                OutlinedTextField(value = tk, onValueChange = { tk = it }, singleLine = true, label = { Text("Personal Access Token") },
                    visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                Muted("ألصق توكين (classic) بصلاحيات repo و workflow، ويفضّل delete_repo لتمكين حذف المستودعات. يُحفظ مشفّراً على جهازك فقط.", 11)
            } },
            confirmButton = { FrameButton(onClick = { vm.loginWithToken(tk) }, enabled = tk.isNotBlank() && !vm.connecting) {
                if (vm.connecting) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp) else Text("دخول") } },
            dismissButton = { FrameButton(onClick = { vm.tokenDialog = false }, enabled = !vm.connecting) { Text("إلغاء", color = Cl.muted) } })
    }
}

/** Opens GitHub in a Chrome Custom Tab (the user's real browser, with their saved GitHub session) above the app. */
@Composable fun AuthScreen(vm: VM) {
    val c = vm.code ?: return
    val code = c.first; val url = "${c.second}?user_code=$code"
    val ctx = LocalContext.current; val clip = LocalClipboardManager.current
    fun openTab() {
        try {
            CustomTabsIntent.Builder().setColorScheme(CustomTabsIntent.COLOR_SCHEME_DARK).setShowTitle(true).build().launchUrl(ctx, Uri.parse(url))
        } catch (e: Exception) { vm.error = "تعذر فتح المتصفح" }
    }
    BackHandler { vm.cancelLogin() }
    LaunchedEffect(code) { clip.setText(AnnotatedString(code)); if (!vm.useWebView) openTab() }
    if (vm.useWebView) {
        Column(Modifier.fillMaxSize().background(Cl.bg).statusBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 6.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("وافق على الطلب هنا ثم سيُكمل الربط تلقائياً", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Muted("الرمز: $code (منسوخ تلقائياً)", 11)
                }
                FrameButton(onClick = { vm.cancelLogin() }) { Text("إلغاء", color = Cl.muted) }
            }
            LinearProgressIndicator(Modifier.fillMaxWidth(), color = Cl.accent, trackColor = Cl.line)
            AndroidView(modifier = Modifier.weight(1f).fillMaxWidth(), factory = { c ->
                WebView(c).apply {
                    settings.javaScriptEnabled = true; settings.domStorageEnabled = true
                    webViewClient = WebViewClient(); loadUrl(url)
                }
            }, onRelease = { it.destroy() })
        }
        return
    }
    Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF171C3A), Cl.bg))).statusBarsPadding().padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        CircularProgressIndicator(color = Cl.accent, trackColor = Cl.line)
        Spacer(Modifier.height(24.dp))
        Text("بانتظار موافقتك في GitHub", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("وافق على الطلب في صفحة GitHub ثم ارجع، وسيُكمل التطبيق الربط تلقائياً.", color = Cl.muted, fontSize = 14.sp, textAlign = TextAlign.Center, lineHeight = 22.sp)
        Spacer(Modifier.height(22.dp))
        Row(Modifier.clip(RoundedCornerShape(14.dp)).background(Cl.raised).clickable { clip.setText(AnnotatedString(code)) }.padding(horizontal = 18.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Text(code, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 26.sp, letterSpacing = 4.sp)
            Spacer(Modifier.width(12.dp)); Ico(Ic.Copy, Cl.muted, 18.dp)
        }
        Spacer(Modifier.height(6.dp)); Muted("نُسخ الرمز تلقائياً، يلزمك فقط إن طلبته GitHub", 11)
        Spacer(Modifier.height(24.dp))
        Button(onClick = { openTab() }, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth().height(52.dp)) { BtnLabel(Ic.Github, "فتح GitHub") }
        FrameButton(onClick = { vm.cancelLogin() }) { Text("إلغاء", color = Cl.muted) }
    }
}

@Composable fun RepoScreen(vm: VM) {
    var q by remember { mutableStateOf("") }; var nn by remember { mutableStateOf("") }; var priv by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { vm.loadRepos() }
    PLazy({ vm.pullRepos() }, contentPadding = PaddingValues(bottom = 16.dp)) {
        item { Card2 {
            Head(Ic.Plus, "إنشاء مستودع جديد")
            OutlinedTextField(nn, { nn = it }, placeholder = { Text("cloudforge-builds") }, singleLine = true, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth())
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clickable { priv = !priv }) {
                Checkbox(priv, { priv = it }); Text("مستودع خاص", fontSize = 14.sp); Spacer(Modifier.width(6.dp)); Muted("(موصى به، لكن له حدود في دقائق البناء)", 11)
            }
            Spacer(Modifier.height(6.dp))
            Button(onClick = { vm.create(nn, priv) }, enabled = nn.isNotBlank() && !vm.busy, shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth().height(48.dp)) { BtnLabel(Ic.Plus, "إنشاء واعتماد") }
        } }
        item { Row(Modifier.padding(horizontal = 18.dp, vertical = 10.dp)) { Muted("أو اختر أحد مستودعاتك", 13) } }
        item { OutlinedTextField(q, { q = it }, placeholder = { Text("بحث في مستودعاتك…") }, leadingIcon = { Ico(Ic.Search, Cl.muted) },
            singleLine = true, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 4.dp)) }
        items(vm.repos.filter { it.getString("full_name").contains(q, true) }.take(40)) { r ->
            val f = r.getString("full_name")
            Card2 { Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                Ico(if (r.optBoolean("private")) Ic.Lock else Ic.Globe, Cl.muted, 18.dp); Spacer(Modifier.width(10.dp))
                Text(f, modifier = Modifier.weight(1f), fontSize = 14.sp)
                if (f == vm.repo) { Muted("الحالي", 12, color = Cl.ok); Spacer(Modifier.width(8.dp)) }
                FilledTonalButton(onClick = { if (f == vm.repo) { vm.uploadTarget = null; vm.screen = "upload" } else vm.pick(f) }, enabled = !vm.busy, shape = RoundedCornerShape(12.dp)) {
                    Text(if (f == vm.repo) "متابعة" else "اختيار") }
            } }
        }
    }
}

/** Main screen: only the projects that exist in the chosen repository. */
@Composable fun HomeScreen(vm: VM) {
    var del by remember { mutableStateOf<String?>(null) }; var alsoBuilds by remember { mutableStateOf(true) }
    LaunchedEffect(vm.repo) { vm.loadHome() }
    LaunchedEffect(vm.runs.filter { it.s("status") != "completed" }.map { it.optLong("id") }) { vm.fetchActiveJobs() }
    LaunchedEffect(vm.repo) { while (true) { delay(8000); if (vm.runs.any { it.s("status") != "completed" }) vm.pollHome() } }
    val folders = vm.projects?.folders.orEmpty()
    PLazy({ vm.pullHome() }, contentPadding = PaddingValues(top = 6.dp, bottom = 16.dp)) {
        if (vm.projects != null && folders.isEmpty()) item { Card2 {
            Empty(Ic.Folder, "لا توجد مشاريع في هذا المستودع بعد")
            Button(onClick = { vm.uploadTarget = null; vm.screen = "upload" }, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth().height(48.dp)) { BtnLabel(Ic.Plus, "رفع أول مشروع") }
        } }
        items(folders) { f ->
            val zips = vm.projects?.items.orEmpty().filter { it.first.startsWith("projects/$f/") && it.first.endsWith(".zip") }
            val run = vm.runs.firstOrNull { runKey(it) == f }
            val rel = vm.releases.firstOrNull { relKey(it) == f && (it.optJSONArray("assets")?.length() ?: 0) > 0 }
            // a failed run that is older than a successful APK of the same project is history, not the current state
            val stale = run != null && failed(run) && rel != null && rel.s("created_at") > run.s("created_at")
            val st = if (stale) "completed" else run?.s("status")
            val cc = if (stale) "success" else run?.s("conclusion")
            val last = vm.projects?.history.orEmpty().firstOrNull { it.first.contains("projects/$f/") }?.second
            val asset = rel?.getJSONArray("assets")?.optJSONObject(0)
            Card2 {
                Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        Box(Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(Cl.accent.copy(alpha = .14f)), contentAlignment = Alignment.Center) { Ico(Ic.Folder, Cl.accent, 22.dp) }
                        Spacer(Modifier.width(12.dp))
                        Column { Text(f, fontWeight = FontWeight.Bold, fontSize = 16.sp); Muted(zips.firstOrNull()?.let { sz(it.second) } ?: "", 12) }
                    }
                    if (st != null) RunRing(st, cc ?: "", runProgress(vm.jobs[run?.optLong("id") ?: -1L]))
                }
                Spacer(Modifier.height(8.dp))
                Muted("آخر رفع: ${fmt(last)}")
                if (asset != null) Muted("آخر APK: ${asset.s("name")} · ${sz(asset.getLong("size"))}", 12, true)
                Spacer(Modifier.height(12.dp))
                DlProgress(vm, rel)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ApkButton(vm, rel, f, Modifier.weight(1f))
                    OutlinedButton(onClick = { vm.uploadTarget = f; vm.screen = "upload" }, shape = RoundedCornerShape(12.dp),
                        contentPadding = PaddingValues(horizontal = 6.dp), modifier = Modifier.weight(1f)) { BtnLabel(Ic.CloudUpload, "تحديث", Cl.accent) }
                    OutlinedButton(onClick = { del = f }, enabled = !vm.busy, shape = RoundedCornerShape(12.dp), border = BorderStroke(1.dp, Cl.bad.copy(alpha = .5f)),
                        contentPadding = PaddingValues(horizontal = 6.dp), modifier = Modifier.weight(1f)) { BtnLabel(Ic.Trash, "حذف", Cl.bad) }
                }
                if (zips.isNotEmpty()) CardBtn(Ic.Refresh, "إعادة بناء النسخة الحالية", Cl.muted, !vm.busy) { vm.rebuild(zips.first().first) }
            }
        }
    }
    del?.let { f -> AlertDialog(onDismissRequest = { del = null }, icon = { Ico(Ic.Trash, Cl.bad, 28.dp) }, title = { Text("حذف المشروع «$f»؟") },
        text = { Column {
            Text("سيُحذف ملف الـZIP وملف الـAPK الخاصان به من المستودع نهائياً.")
            Row(Modifier.clickable { alsoBuilds = !alsoBuilds }.padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Checkbox(alsoBuilds, { alsoBuilds = it }); Text("حذف عمليات البناء والإصدارات الخاصة به أيضاً", fontSize = 13.sp)
            }
        } },
        confirmButton = { FrameButton(onClick = { vm.deleteProject(f, alsoBuilds); del = null }) { Text("حذف", color = Cl.bad) } },
        dismissButton = { FrameButton(onClick = { del = null }) { Text("إلغاء") } }) }
}

/** Upload card (new project / update existing) and, below it, what is inside projects/ in the repository. */
@OptIn(ExperimentalFoundationApi::class)
@Composable fun UploadScreen(vm: VM) {
    val ctx = LocalContext.current
    val folders = vm.projects?.folders.orEmpty()
    var update by remember { mutableStateOf(vm.uploadTarget != null) }
    var sel by remember { mutableStateOf(vm.uploadTarget ?: "") }
    var pname by remember { mutableStateOf("") }
    var uri by remember { mutableStateOf<Uri?>(null) }; var fname by remember { mutableStateOf("") }; var size by remember { mutableStateOf(0L) }
    var warn by remember { mutableStateOf(false) }
    LaunchedEffect(vm.repo) { vm.loadProjects() }
    LaunchedEffect(Unit) { vm.uploadTarget = null }
    var showBrowser by remember { mutableStateOf(false) }; var hover by remember { mutableStateOf(false) }
    val perm = remember { mutableStateOf<Any?>(null) }   // keeps the drag-and-drop read permission alive until the upload is done
    /** One entry point for every way a file can arrive: system picker, in-app browser, drag & drop. */
    fun accept(u: Uri, strictZip: Boolean = false) {
        var n = ""; var sz0 = 0L
        if (u.scheme == "file") { val f = File(u.path ?: ""); n = f.name; sz0 = f.length() }
        else ctx.contentResolver.query(u, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (ni >= 0) n = c.getString(ni) ?: ""
                val si = c.getColumnIndex(OpenableColumns.SIZE); if (si >= 0) sz0 = c.getLong(si)
            }
        }
        if (strictZip && !n.endsWith(".zip", true)) { vm.error = "الملف المُفلَت ليس بصيغة ZIP"; return }
        if (sz0 > 50_000_000) { vm.error = "الحد الأقصى 50MB"; return }
        fname = n; size = sz0; uri = u; warn = !rootOk(ctx, u)
        if (!update && pname.isBlank()) pname = clean(n.removeSuffix(".zip"))
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) accept(u) }
    val dropHandler = rememberUpdatedState<(DragAndDropEvent) -> Boolean> { ev ->
        val de = ev.toAndroidDragEvent()
        val u = de.clipData?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.uri
        if (u == null) { vm.error = "لم أجد ملفاً في العنصر المُفلَت"; false } else {
            var c: Context = ctx
            while (c is ContextWrapper && c !is Activity) c = c.baseContext
            (c as? Activity)?.let { perm.value = it.requestDragAndDropPermissions(de) }   // needed to read a file dropped from another app
            accept(u, true); true
        }
    }
    val dropTarget = remember { object : DragAndDropTarget {
        override fun onEntered(event: DragAndDropEvent) { hover = true }
        override fun onExited(event: DragAndDropEvent) { hover = false }
        override fun onEnded(event: DragAndDropEvent) { hover = false }
        override fun onDrop(event: DragAndDropEvent): Boolean { hover = false; return dropHandler.value(event) }
    } }
    // the project's name = its folder = its zip = its APK
    val newName = clean(pname)
    val exists = folders.any { it.equals(newName, true) }
    val updZip = vm.projects?.items.orEmpty().firstOrNull { it.first.startsWith("projects/$sel/") && it.first.endsWith(".zip") }?.first?.substringAfterLast('/')?.removeSuffix(".zip") ?: sel
    val folder = if (update) sel else newName
    val base = if (update) updZip else newName
    val ready = uri != null && !vm.busy && (if (update) sel.isNotBlank() else pname.isNotBlank() && !exists)
    // the whole screen accepts a dropped file (split screen / pop-up window of any file manager)
    PLazy({ vm.pullProjects() }, Modifier.fillMaxSize().dragAndDropTarget(shouldStartDragAndDrop = { true }, target = dropTarget), contentPadding = PaddingValues(top = 6.dp, bottom = 16.dp)) {
        item { Card2 {
            Head(Ic.CloudUpload, "رفع إلى ${vm.repo?.substringAfter('/') ?: ""}")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = !update, onClick = { update = false }, label = { Text("مشروع جديد") }, leadingIcon = { Ico(Ic.Plus, size = 16.dp) }, shape = RoundedCornerShape(12.dp))
                FilterChip(selected = update, onClick = { update = true }, enabled = folders.isNotEmpty(), label = { Text("تحديث مشروع موجود") }, leadingIcon = { Ico(Ic.Refresh, size = 16.dp) }, shape = RoundedCornerShape(12.dp))
            }
            Spacer(Modifier.height(10.dp))
            if (update) {
                Muted("اختر المشروع")
                Spacer(Modifier.height(6.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    folders.forEach { f -> FilterChip(selected = sel == f, onClick = { sel = f }, label = { Text(f) }, leadingIcon = { Ico(Ic.Folder, size = 16.dp) }, shape = RoundedCornerShape(12.dp)) }
                }
            } else {
                OutlinedTextField(pname, { pname = it }, label = { Text("اسم المشروع (هو اسم ملف الـAPK)") }, singleLine = true, isError = exists,
                    supportingText = { if (exists) Text("يوجد مشروع بهذا الاسم، اختر «تحديث مشروع موجود»") }, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth())
            }
            Spacer(Modifier.height(12.dp))
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Cl.accent.copy(alpha = if (hover) .2f else .07f))
                .border(if (hover) 2.5.dp else 1.5.dp, Cl.accent.copy(alpha = if (hover) 1f else .45f), RoundedCornerShape(16.dp))
                .clickable { showBrowser = true }.padding(26.dp),
                horizontalAlignment = Alignment.CenterHorizontally) {
                Ico(Ic.CloudUpload, Cl.accent, 36.dp); Spacer(Modifier.height(8.dp))
                Text(if (hover) "أفلت الملف هنا" else "اضغط لاختيار ملف ZIP أو أفلته هنا", fontWeight = FontWeight.Medium)
                Muted("ملفات المشروع في جذر الـZIP مباشرة", 12)
            }
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.Top) {
                Ico(Ic.Alert, Cl.accent, 16.dp); Spacer(Modifier.width(6.dp))
                Muted("إن احتاج مشروعك إلى مكتبات أو إعداد خاص لبيئة البناء (مثل Go أو سكريبتات تحميل)، اكتب أوامر الإعداد في ملف باسم azro (بدون امتداد) داخل جذر الـZIP بجانب ملفات المشروع. يُشغَّل تلقائياً قبل البناء، وإن لم يوجد يُبنى المشروع بشكل عادي.", 12)
            }
            if (uri != null) {
                Spacer(Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) { Ico(Ic.File, Cl.accent, 18.dp); Spacer(Modifier.width(8.dp)); Text("$fname · ${sz(size)}", fontWeight = FontWeight.SemiBold) }
                Spacer(Modifier.height(4.dp))
                Muted("المسار: projects/${folder.ifBlank { "?" }}/$base.zip", 12, true)
                Muted("الناتج: projects/${folder.ifBlank { "?" }}/$base.apk", 12, true)
                if (update) Muted("سيُستبدل الملف القديم وتُبنى هذه النسخة فقط.", 12)
                if (warn) { Spacer(Modifier.height(6.dp)); Row(verticalAlignment = Alignment.CenterVertically) {
                    Ico(Ic.Alert, Cl.warn, 16.dp); Spacer(Modifier.width(6.dp)); Muted("لم أجد ملفات المشروع في جذر الـZIP. تأكد أنها ليست داخل مجلد فرعي.", 12, color = Cl.warn) } }
            }
            vm.up?.let { u ->
                Spacer(Modifier.height(12.dp))
                val pct = if (u.total > 0) (u.done * 100 / u.total).toInt() else 0
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(when (u.stage) { "prep" -> "تجهيز الملف…"; "upload" -> "جارٍ الرفع إلى GitHub"; "commit" -> "إنشاء الـCommit وبدء البناء…"; else -> "اكتمل الرفع" },
                        fontWeight = FontWeight.SemiBold, fontSize = 14.sp, modifier = Modifier.weight(1f))
                    if (u.stage == "upload") Text("$pct%", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Cl.accent)
                    IconButton(onClick = { vm.cancelUpload() }, modifier = Modifier.size(28.dp)) { Ico(Ic.Close, Cl.muted, 18.dp) }
                }
                Spacer(Modifier.height(6.dp))
                if (u.stage == "upload") {
                    LinearProgressIndicator(progress = { (u.done.toFloat() / u.total.coerceAtLeast(1)).coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)), color = Cl.accent, trackColor = Cl.line)
                    Spacer(Modifier.height(4.dp)); Muted("${sz(u.done)} / ${sz(u.total)}", 12)
                } else LinearProgressIndicator(Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)), color = Cl.accent, trackColor = Cl.line)
            }
            Spacer(Modifier.height(12.dp))
            Button(onClick = { vm.upload(uri!!, base, folder) }, enabled = ready,
                shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth().height(50.dp)) { BtnLabel(Ic.Wrench, if (update) "رفع التحديث وبدء البناء" else "رفع وبدء البناء") }
        } }
        item { Card2 {
            Head(Ic.Folder, "محتويات projects/")
            val all = vm.projects?.items.orEmpty()
            if (all.isEmpty()) Muted("لا توجد ملفات بعد", 13)
            folders.forEach { f ->
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 8.dp)) { Ico(Ic.Folder, Cl.accent, 16.dp); Spacer(Modifier.width(8.dp)); Text(f, fontWeight = FontWeight.SemiBold, fontSize = 14.sp) }
                all.filter { it.first.startsWith("projects/$f/") }.sortedBy { it.first }.forEach { (p, s) ->
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(start = 24.dp, top = 3.dp)) {
                        Ico(Ic.File, if (p.endsWith(".apk")) Cl.ok else Cl.muted, 14.dp); Spacer(Modifier.width(8.dp))
                        Text(p.substringAfterLast('/'), fontFamily = FontFamily.Monospace, fontSize = 12.sp, modifier = Modifier.weight(1f)); Muted(sz(s), 11)
                    }
                }
            }
        } }
        item { Card2 { Head(Ic.Clock, "سجل الرفع")
            val h = vm.projects?.history.orEmpty()
            if (h.isEmpty()) Muted("لا توجد رفعات بعد", 13)
            h.take(15).forEach { (p, d) -> Text(p, fontFamily = FontFamily.Monospace, fontSize = 12.sp); Muted(fmt(d), 11); Spacer(Modifier.height(8.dp)) }
        } }
    }
    if (showBrowser) FileBrowserSheet(onDismiss = { showBrowser = false },
        onPick = { f -> showBrowser = false; accept(Uri.fromFile(f)) },
        onSystem = { showBrowser = false; picker.launch(arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream")) })
}

private data class Vol(val label: String, val root: File)
private fun volumes(ctx: Context): List<Vol> {
    val out = mutableListOf<Vol>()
    ctx.getExternalFilesDirs(null).filterNotNull().forEachIndexed { i, d ->
        val root = File(d.absolutePath.substringBefore("/Android/data"))
        if (out.none { it.root == root } && root.canRead()) out += Vol(if (i == 0) "التخزين الداخلي" else "بطاقة SD / ذاكرة خارجية", root)
    }
    if (out.isEmpty()) out += Vol("التخزين الداخلي", Environment.getExternalStorageDirectory())
    return out
}
private fun canReadAll(ctx: Context) = if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
    else ctx.checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
private class Listing(val dir: File?, val files: List<File>?)

/** Bottom sheet file browser: pick a storage (internal / SD card), walk folders, tap a ZIP. Folders and .zip files only. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable fun FileBrowserSheet(onDismiss: () -> Unit, onPick: (File) -> Unit, onSystem: () -> Unit) {
    val ctx = LocalContext.current
    var granted by remember { mutableStateOf(canReadAll(ctx)) }
    val legacy = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = canReadAll(ctx) }
    val settings = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { granted = canReadAll(ctx) }
    fun askPermission() {
        if (Build.VERSION.SDK_INT >= 30) {
            try { settings.launch(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:${ctx.packageName}"))) }
            catch (e: Exception) { settings.launch(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)) }
        } else legacy.launch(android.Manifest.permission.READ_EXTERNAL_STORAGE)
    }
    val vols = remember(granted) { volumes(ctx) }
    var vol by remember { mutableStateOf<Vol?>(null) }
    var dir by remember { mutableStateOf<File?>(null) }          // null = the list of storages
    val listingState = produceState<Listing?>(null, dir, granted) {
        value = null
        val d = dir
        value = if (d == null || !granted) Listing(d, emptyList()) else withContext(Dispatchers.IO) {
            val files = try {
                d.listFiles()?.filter { !it.name.startsWith(".") && (it.isDirectory || it.name.endsWith(".zip", true)) }
                    ?.sortedWith(compareBy({ !it.isDirectory }, { it.name.lowercase() }))
            } catch (e: Exception) { null }   // SecurityException etc. -> "can't open this folder", never a crash
            Listing(d, files)
        }
    }
    // One stable snapshot per composition, and only if it belongs to the folder currently shown.
    // (Reading `listing!!` inside the LazyColumn lambda raced with produceState resetting it to null -> NPE crash.)
    val listing: Listing? = listingState.value?.takeIf { it.dir == dir }
    fun up() { val d = dir ?: return; dir = if (d == vol?.root) null else d.parentFile }
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true), containerColor = Cl.surface) {
        Column(Modifier.fillMaxWidth().height(520.dp).navigationBarsPadding()) {
            Row(Modifier.padding(horizontal = 12.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                if (dir != null) IconButton(onClick = { up() }) { Ico(Ic.ArrowRight, Cl.text, 22.dp) }
                Column(Modifier.weight(1f).padding(horizontal = 6.dp)) {
                    Text(if (dir == null) "اختر ملف ZIP" else (vol?.label ?: ""), fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                    dir?.let { d -> CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                        Text("/" + d.absolutePath.removePrefix(vol?.root?.absolutePath ?: "").trim('/'), color = Cl.muted, fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace, maxLines = 1, overflow = TextOverflow.Ellipsis) } }
                }
                IconButton(onClick = onDismiss) { Ico(Ic.Close, Cl.muted, 20.dp) }
            }
            HorizontalDivider(color = Cl.line)
            when {
                !granted -> Column(Modifier.fillMaxSize().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    Ico(Ic.Lock, Cl.accent, 36.dp); Spacer(Modifier.height(12.dp))
                    Text("يحتاج التطبيق إذن الوصول إلى الملفات ليعرض ملفات جهازك", textAlign = TextAlign.Center, lineHeight = 22.sp)
                    Spacer(Modifier.height(18.dp))
                    Button(onClick = { askPermission() }, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth().height(48.dp)) { Text("منح الإذن") }
                    FrameButton(onClick = onSystem) { Text("استخدام مستكشف النظام بدلاً من ذلك", color = Cl.muted) }
                }
                dir == null -> LazyColumn(contentPadding = PaddingValues(vertical = 8.dp)) {
                    items(vols) { v -> Row(Modifier.fillMaxWidth().clickable { vol = v; dir = v.root }.padding(horizontal = 20.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(Cl.accent.copy(alpha = .14f)), contentAlignment = Alignment.Center) { Ico(Ic.Archive, Cl.accent, 22.dp) }
                        Spacer(Modifier.width(14.dp))
                        Column { Text(v.label, fontWeight = FontWeight.Medium); Muted("متاح ${sz(v.root.usableSpace)}", 12) }
                    } }
                }
                listing == null -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator(color = Cl.accent) }
                listing.files == null -> Box(Modifier.fillMaxSize(), Alignment.Center) { Muted("لا يمكن فتح هذا المجلد", 13) }
                listing.files.isEmpty() -> Box(Modifier.fillMaxSize(), Alignment.Center) { Muted("لا توجد مجلدات أو ملفات ZIP هنا", 13) }
                else -> LazyColumn(contentPadding = PaddingValues(vertical = 4.dp)) {
                    items(listing.files, key = { it.absolutePath }) { f ->
                        Row(Modifier.fillMaxWidth().clickable { if (f.isDirectory) dir = f else onPick(f) }.padding(horizontal = 20.dp, vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) {
                            Ico(if (f.isDirectory) Ic.Folder else Ic.File, if (f.isDirectory) Cl.accent else Cl.ok, 22.dp)
                            Spacer(Modifier.width(14.dp))
                            Column(Modifier.weight(1f)) {
                                Text(f.name, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                if (!f.isDirectory) Muted("${sz(f.length())} · ${fmt(Instant.ofEpochMilli(f.lastModified()).toString())}", 11)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable fun StepRow(st: JSONObject) {
    val (ic, col) = when (st.s("conclusion")) {
        "success" -> Ic.CheckCircle to Cl.ok
        "failure" -> Ic.XCircle to Cl.bad
        "skipped", "cancelled" -> Ic.Ban to Cl.muted
        else -> Ic.Spinner to Cl.warn
    }
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 3.dp)) {
        Ico(ic, col, 15.dp); Spacer(Modifier.width(8.dp))
        Text(st.s("name"), fontSize = 12.sp, modifier = Modifier.weight(1f))
        Muted(dur(st.s("started_at"), st.s("completed_at")), 11)
    }
}

/** Build log: left-to-right, selectable, with a one-tap copy button. */
@Composable fun LogBox(text: String, onCopied: () -> Unit) {
    val clip = LocalClipboardManager.current
    CardBtn(Ic.Copy, "نسخ السجل", Cl.accent) { clip.setText(AnnotatedString(text)); onCopied() }
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        SelectionContainer {
            Text(text, fontSize = 11.sp, lineHeight = 16.sp, fontFamily = FontFamily.Monospace, color = Cl.muted, textAlign = TextAlign.Left,
                modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Cl.bg).padding(10.dp)
                    .heightIn(max = 320.dp).verticalScroll(rememberScrollState()))
        }
    }
}

@Composable fun ProjectChips(vm: VM, keys: List<String>, cur: String?) {
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 14.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        keys.forEach { k -> FilterChip(selected = k == cur, onClick = { vm.sel = k }, label = { Text(k) },
            leadingIcon = { Ico(Ic.Folder, size = 16.dp) }, shape = RoundedCornerShape(12.dp)) }
    }
}

@Composable fun BuildScreen(vm: VM) {
    var del by remember { mutableStateOf<JSONObject?>(null) }; var delFailed by remember { mutableStateOf(false) }
    LaunchedEffect(vm.repo) { vm.loadProjects() }
    LaunchedEffect(vm.repo) { while (true) { vm.refreshRuns(); delay(6000) } }
    val keys = vm.projectKeys(); val cur = vm.sel?.takeIf { it in keys } ?: keys.firstOrNull()
    val list = vm.runs.filter { runKey(it) == cur }
    val bad = list.filter { failed(it) }
    Column(Modifier.fillMaxSize()) {
        if (keys.isNotEmpty()) ProjectChips(vm, keys, cur)
        PLazy({ vm.pullBuilds() }, Modifier.weight(1f), contentPadding = PaddingValues(bottom = 16.dp)) {
            if (list.isEmpty()) item { Card2 { Empty(Ic.Wrench, if (keys.isEmpty()) "لا توجد عمليات بناء بعد. ارفع مشروعاً أولاً." else "لا توجد عمليات بناء لهذا المشروع") } }
            if (bad.isNotEmpty()) item { CardBtn(Ic.Trash, "حذف العمليات الفاشلة (${bad.size})", Cl.bad, modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp)) { delFailed = true } }
            items(list, key = { it.getLong("id") }) { r ->
                val id = r.getLong("id"); val done = r.s("status") == "completed"
                Card2 {
                    Row(Modifier.fillMaxWidth().clickable { vm.toggle(id) }, Arrangement.SpaceBetween, Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("#${r.getInt("run_number")}", fontWeight = FontWeight.Bold)
                            Muted(r.s("display_title").removePrefix("CloudForge: ").lines().first(), 12, true)
                        }
                        StatusChip(r.s("status"), r.s("conclusion"))
                    }
                    Spacer(Modifier.height(4.dp))
                    Muted("بدأ: ${fmt(r.s("run_started_at"))} · المدة: ${dur(r.s("run_started_at"), if (done) r.s("updated_at") else null)}")
                    if (vm.open == id) vm.jobs[id].orEmpty().filter { it.s("name") != "Detect new zips" }.forEach { j ->
                        val jid = j.getLong("id")
                        HorizontalDivider(Modifier.padding(vertical = 8.dp), color = Cl.line)
                        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                            Text(j.s("name"), fontSize = 13.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                            StatusChip(j.s("status"), j.s("conclusion"))
                        }
                        Muted("المدة: ${dur(j.s("started_at"), j.s("completed_at"))}", 11)
                        Spacer(Modifier.height(4.dp))
                        j.getJSONArray("steps").list().forEach { StepRow(it) }
                        if (j.s("conclusion") == "failure") {
                            CardBtn(Ic.Alert, "عرض الأخطاء", Cl.bad) { vm.showLog(jid) }
                            vm.logs[jid]?.let { LogBox(it) { vm.toast = "تم نسخ السجل" } }
                        }
                    }
                    if (!done) CardBtn(Ic.Close, "إلغاء البناء", Cl.bad) { vm.cancelRun(id) }
                    else CardBtn(Ic.Trash, "حذف العملية", Cl.bad) { del = r }
                }
            }
        }
    }
    del?.let { d -> AlertDialog(onDismissRequest = { del = null }, icon = { Ico(Ic.Trash, Cl.bad, 28.dp) }, title = { Text("حذف عملية البناء #${d.getInt("run_number")}؟") },
        text = { Text("ستُحذف العملية وسجلها وملف الـAPK الناتج عنها (إن وُجد) نهائياً.") },
        confirmButton = { FrameButton(onClick = { vm.deleteRuns(listOf(d)); del = null }) { Text("حذف", color = Cl.bad) } },
        dismissButton = { FrameButton(onClick = { del = null }) { Text("إلغاء") } }) }
    if (delFailed) AlertDialog(onDismissRequest = { delFailed = false }, icon = { Ico(Ic.Trash, Cl.bad, 28.dp) }, title = { Text("حذف ${bad.size} عملية فاشلة؟") },
        text = { Text("ستُحذف كل العمليات الفاشلة والملغاة لمشروع «$cur» مع سجلاتها.") },
        confirmButton = { FrameButton(onClick = { vm.deleteRuns(bad); delFailed = false }) { Text("حذف الكل", color = Cl.bad) } },
        dismissButton = { FrameButton(onClick = { delFailed = false }) { Text("إلغاء") } })
}

@Composable fun ArchiveScreen(vm: VM) {
    var delRel by remember { mutableStateOf<Pair<JSONObject, JSONObject>?>(null) }   // run to release
    var delRun by remember { mutableStateOf<JSONObject?>(null) }
    LaunchedEffect(vm.repo) { vm.loadProjects(); vm.loadArchive() }
    val keys = vm.projectKeys(); val cur = vm.sel?.takeIf { it in keys } ?: keys.firstOrNull()
    val list = vm.archive.filter { runKey(it.first) == cur }
    // clean-up: keep only the newest build of this project (and its downloaded APK, if downloaded)
    var confirmClean by remember { mutableStateOf(false) }
    val newest = list.map { it.first }.maxByOrNull { it.getInt("run_number") }
    val oldRuns = list.map { it.first }.filter { it.getLong("id") != newest?.getLong("id") }
    val keepRel = newest?.let { n -> list.firstOrNull { it.first.getLong("id") == n.getLong("id") }?.second?.firstOrNull() }
    val keepLocal = keepRel?.let { vm.localFor(it) }
    val oldPkgs = list.filter { it.first.getLong("id") != newest?.getLong("id") }.sumOf { it.second.size }
    val oldLocal = vm.local.filter { it.folder == cur && it != keepLocal }
    Column(Modifier.fillMaxSize()) {
        if (keys.isNotEmpty()) Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.weight(1f)) { ProjectChips(vm, keys, cur) }
            if (cur != null) OutlinedButton(onClick = { confirmClean = true }, enabled = !vm.busy && (oldRuns.isNotEmpty() || oldLocal.isNotEmpty()), shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, Cl.bad.copy(alpha = if (!vm.busy && (oldRuns.isNotEmpty() || oldLocal.isNotEmpty())) .5f else .25f)),
                contentPadding = PaddingValues(horizontal = 12.dp), modifier = Modifier.padding(end = 14.dp)) { BtnLabel(Ic.Trash, "تنظيف", Cl.bad) }
        }
        PLazy({ vm.pullArchive() }, Modifier.weight(1f), contentPadding = PaddingValues(bottom = 16.dp)) {
            if (list.isEmpty()) item { Card2 { Empty(Ic.Archive, if (keys.isEmpty()) "الأرشيف فارغ" else "لا توجد إصدارات لهذا المشروع") } }
            list.forEach { (run, rels) ->
                if (rels.isEmpty()) item { Card2 {
                    Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) { Text("#${run.getInt("run_number")} · بدون APK", fontWeight = FontWeight.Bold); StatusChip(run.s("status"), run.s("conclusion")) }
                    Muted(fmt(run.s("run_started_at")))
                    CardBtn(Ic.Trash, "حذف العملية", Cl.bad) { delRun = run }
                } }
                rels.forEach { rel -> item { Card2 {
                    val size = rel.getJSONArray("assets").optJSONObject(0)?.getLong("size")
                    Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) { Text("#${run.getInt("run_number")} · ${rel.s("name")}", fontWeight = FontWeight.Bold)
                            Muted("${fmt(run.s("run_started_at"))} · ${size?.let { sz(it) } ?: "—"}") }
                        StatusChip(run.s("status"), run.s("conclusion"))
                    }
                    Spacer(Modifier.height(12.dp))
                    DlProgress(vm, rel)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ApkButton(vm, rel, folderOf(rel), Modifier.weight(1f), "تحميل وتثبيت")
                        OutlinedButton(onClick = { delRel = run to rel }, shape = RoundedCornerShape(12.dp), border = BorderStroke(1.dp, Cl.bad.copy(alpha = .5f)), modifier = Modifier.weight(1f)) { BtnLabel(Ic.Trash, "حذف", Cl.bad) }
                    }
                } } }
            }
        }
    }
    if (confirmClean && cur != null) AlertDialog(onDismissRequest = { confirmClean = false }, icon = { Ico(Ic.Trash, Cl.bad, 28.dp) }, title = { Text("تنظيف أرشيف «$cur»؟") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("سيبقى آخر بناء فقط${newest?.let { " (#${it.getInt("run_number")})" } ?: ""}، وسيُحذف الباقي نهائياً:")
            Muted("• ${oldRuns.size} عملية بناء مع سجلاتها", 13)
            Muted("• $oldPkgs حزمة APK من المستودع", 13)
            Muted("• ${oldLocal.size} ملف APK محمّل في التنزيلات" + if (keepLocal != null) " (عدا الخاص بآخر بناء)" else "", 13)
        } },
        confirmButton = { FrameButton(onClick = { vm.cleanProject(cur, newest?.getLong("id")); confirmClean = false }) { Text("حذف", color = Cl.bad) } },
        dismissButton = { FrameButton(onClick = { confirmClean = false }) { Text("إلغاء") } })
    delRel?.let { (run, rel) -> AlertDialog(onDismissRequest = { delRel = null }, icon = { Ico(Ic.Trash, Cl.bad, 28.dp) }, title = { Text("ماذا تريد أن تحذف؟") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { vm.delete(rel); delRel = null }, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) { Text("ملف الـAPK فقط") }
            OutlinedButton(onClick = { vm.deleteRuns(listOf(run)); delRel = null }, shape = RoundedCornerShape(12.dp), border = BorderStroke(1.dp, Cl.bad.copy(alpha = .5f)), modifier = Modifier.fillMaxWidth()) { Text("عملية البناء بالكامل", color = Cl.bad) }
            Muted("العملية الكاملة تشمل سجلها والـAPK معاً.", 12)
        } },
        confirmButton = { FrameButton(onClick = { delRel = null }) { Text("إلغاء") } }) }
    delRun?.let { d -> AlertDialog(onDismissRequest = { delRun = null }, icon = { Ico(Ic.Trash, Cl.bad, 28.dp) }, title = { Text("حذف عملية البناء #${d.getInt("run_number")}؟") },
        text = { Text("ستُحذف العملية وسجلها نهائياً.") },
        confirmButton = { FrameButton(onClick = { vm.deleteRuns(listOf(d)); delRun = null }) { Text("حذف", color = Cl.bad) } },
        dismissButton = { FrameButton(onClick = { delRun = null }) { Text("إلغاء") } }) }
}

@Composable fun InfoRow(icon: ImageVector, label: String, value: String) =
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
        Ico(icon, Cl.muted, 16.dp); Spacer(Modifier.width(10.dp)); Muted(label, 13); Spacer(Modifier.weight(1f)); Text(value, fontSize = 13.sp)
    }

/** Tap the repository name in the top bar: details + rename / delete. */
@Composable fun RepoInfoDialog(vm: VM) {
    if (!vm.showRepo) return
    var rename by remember { mutableStateOf(false) }; var del by remember { mutableStateOf(false) }; var nn by remember { mutableStateOf("") }
    val i = vm.repoInfo
    AlertDialog(onDismissRequest = { vm.showRepo = false }, icon = { Ico(Ic.GitBranch, Cl.accent, 28.dp) }, title = { Text(vm.repo ?: "", fontSize = 16.sp) },
        text = { Column {
            if (i == null) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Cl.accent, trackColor = Cl.line) else {
                InfoRow(if (i.optBoolean("private")) Ic.Lock else Ic.Globe, "الظهور", if (i.optBoolean("private")) "خاص" else "عام")
                InfoRow(Ic.Clock, "تاريخ الإنشاء", fmt(i.s("created_at")))
                InfoRow(Ic.Refresh, "آخر نشاط", fmt(i.s("pushed_at")))
                InfoRow(Ic.GitBranch, "الفرع الافتراضي", i.s("default_branch"))
                InfoRow(Ic.Archive, "الحجم", sz(i.optLong("size") * 1024))
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { nn = vm.repo?.substringAfter('/') ?: ""; rename = true }, shape = RoundedCornerShape(12.dp),
                        contentPadding = PaddingValues(horizontal = 6.dp), modifier = Modifier.weight(1f)) { BtnLabel(Ic.Edit, "إعادة التسمية") }
                    OutlinedButton(onClick = { del = true }, shape = RoundedCornerShape(12.dp), border = BorderStroke(1.dp, Cl.bad.copy(alpha = .5f)),
                        contentPadding = PaddingValues(horizontal = 6.dp), modifier = Modifier.weight(1f)) { BtnLabel(Ic.Trash, "حذف", Cl.bad) }
                }
            }
        } },
        confirmButton = { FrameButton(onClick = { vm.showRepo = false }) { Text("إغلاق") } })
    if (rename) AlertDialog(onDismissRequest = { rename = false }, icon = { Ico(Ic.Edit, Cl.accent, 28.dp) }, title = { Text("إعادة تسمية المستودع") },
        text = { Column {
            OutlinedTextField(nn, { nn = it }, singleLine = true, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp)); Muted("تبقى الأسرار والمشاريع كما هي، وتتحول روابط GitHub القديمة تلقائياً.", 12)
        } },
        confirmButton = { FrameButton(enabled = nn.isNotBlank() && clean(nn) != vm.repo?.substringAfter('/'), onClick = { vm.renameRepo(nn); rename = false; vm.showRepo = false }) { Text("حفظ") } },
        dismissButton = { FrameButton(onClick = { rename = false }) { Text("إلغاء") } })
    if (del) AlertDialog(onDismissRequest = { del = false }, icon = { Ico(Ic.Alert, Cl.bad, 28.dp) }, title = { Text("حذف المستودع نهائياً؟") },
        text = { Text("تحذير: سيُحذف المستودع «${vm.repo}» بكل ملفاته ومشاريعه وعمليات البناء وملفات الـAPK المنشورة فيه، ولا يمكن التراجع عن ذلك.") },
        confirmButton = { FrameButton(onClick = { vm.deleteRepo(); del = false }) { Text("حذف نهائياً", color = Cl.bad) } },
        dismissButton = { FrameButton(onClick = { del = false }) { Text("إلغاء") } })
}
