package app.cloudforge

import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/* ───────────── path + zip helpers (pure functions) ───────────── */
fun parentOf(p: String) = p.substringBeforeLast('/', "")
fun nameOf(p: String) = p.substringAfterLast('/')
fun joinP(d: String, n: String) = if (d.isEmpty()) n else "$d/$n"

/** A path typed by the user -> clean repository path ("" = root), or null when it is not allowed. */
fun normPath(raw: String): String? {
    val parts = raw.trim().replace('\\', '/').split('/').filter { it.isNotBlank() && it != "." }
    if (parts.any { it == ".." || it.equals(".git", true) || it.any { c -> c.code < 32 } }) return null
    return parts.joinToString("/")
}
/** Entry name inside a ZIP -> repository path. Null = ignored (macOS junk, .git, path traversal). */
fun cleanZipPath(name: String): String? {
    val parts = name.replace('\\', '/').split('/').filter { it.isNotEmpty() && it != "." }
    if (parts.isEmpty() || parts.any { it == ".." || it.equals(".git", true) } || parts[0] == "__MACOSX" || parts.last() == ".DS_Store") return null
    return parts.joinToString("/")
}
fun decodeText(b: ByteArray): String? {
    if (b.any { it.toInt() == 0 }) return null
    return try {
        Charsets.UTF_8.newDecoder().onMalformedInput(java.nio.charset.CodingErrorAction.REPORT)
            .onUnmappableCharacter(java.nio.charset.CodingErrorAction.REPORT).decode(java.nio.ByteBuffer.wrap(b)).toString()
    } catch (e: Exception) { null }
}

/** The build script installed by the app: a ZIP can never overwrite or delete it. */
const val PROTECTED_FILE = ".github/workflows/build.yml"
class ZEntry(val path: String, val bytes: ByteArray, val sha: String)
class ZipPack(val name: String, val files: List<ZEntry>, val root: String?)
class ZipPlan(val puts: List<Gh.Put.Data>, val deletes: List<String>, val added: Int, val changed: Int, val same: Int,
              val removed: Int, val skipped: Int, val blocked: Boolean)

/**
 * What applying [pack] to [target] would do. mode 0 = replace everything in the target with the ZIP (delete what the ZIP lacks),
 * 1 = merge (add + overwrite, keep the rest), 2 = only overwrite files that already exist (add nothing new).
 */
fun planZip(pack: ZipPack, snap: Gh.Snap?, target: String, mode: Int, strip: Boolean): ZipPlan {
    val exist = snap?.entries.orEmpty().filter { it.type != "tree" }.associateBy { it.path }
    val puts = mutableListOf<Gh.Put.Data>(); val zipPaths = HashSet<String>()
    var added = 0; var changed = 0; var same = 0; var skipped = 0
    for (f in pack.files) {
        val rel = if (strip && pack.root != null) f.path.removePrefix(pack.root + "/") else f.path
        val path = joinP(target, rel)
        if (path == PROTECTED_FILE) { skipped++; continue }
        val ex = exist[path]
        if (ex == null) {
            if (mode == 2) skipped++ else { added++; zipPaths += path; puts += Gh.Put.Data(path, f.bytes) }
        } else {
            zipPaths += path
            if (ex.type == "blob" && ex.sha == f.sha) same++ else { changed++; puts += Gh.Put.Data(path, f.bytes, if (ex.type == "blob") ex.mode else "100644") }
        }
    }
    val dels = LinkedHashSet<String>()
    if (mode == 0) for (e in exist.values) if ((target.isEmpty() || e.path.startsWith("$target/")) && e.path !in zipPaths && e.path != PROTECTED_FILE) dels += e.path
    // a file that becomes a folder (or the other way round) must disappear first
    val existDirs = HashSet<String>()
    for (p in exist.keys) { var i = p.indexOf('/'); while (i > 0) { existDirs += p.substring(0, i); i = p.indexOf('/', i + 1) } }
    for (put in puts) {
        if (put.path in existDirs) exist.keys.filter { it.startsWith(put.path + "/") }.forEach { dels += it }
        var i = put.path.indexOf('/')
        while (i > 0) { val a = put.path.substring(0, i); if (exist.containsKey(a)) dels += a; i = put.path.indexOf('/', i + 1) }
    }
    return ZipPlan(puts, dels.toList(), added, changed, same, dels.size, skipped, snap?.truncated == true && mode == 0)
}

/* ───────────── file list model ───────────── */
private class Item(val path: String, val name: String, val dir: Boolean, val size: Long, val count: Int, val type: String)

private fun listDir(snap: Gh.Snap, dir: String, q: String): List<Item> {
    if (q.isNotBlank()) return snap.entries.filter { it.type != "tree" && it.path.contains(q.trim(), true) }.take(200)
        .map { Item(it.path, it.path, false, it.size, 0, it.type) }
    val prefix = if (dir.isEmpty()) "" else "$dir/"
    val folders = LinkedHashMap<String, LongArray>(); val files = ArrayList<Item>()
    for (e in snap.entries) {
        if (e.type == "tree" || !e.path.startsWith(prefix)) continue
        val rest = e.path.substring(prefix.length); val i = rest.indexOf('/')
        if (i < 0) files += Item(e.path, rest, false, e.size, 0, e.type)
        else { val a = folders.getOrPut(rest.substring(0, i)) { LongArray(2) }; a[0]++; a[1] += e.size }
    }
    return folders.map { (n, a) -> Item(prefix + n, n, true, a[1], a[0].toInt(), "tree") }.sortedBy { it.name.lowercase() } + files.sortedBy { it.name.lowercase() }
}
private val IMG_EXT = setOf("png", "jpg", "jpeg", "gif", "webp", "bmp")
private val ZIP_EXT = setOf("zip", "apk", "jar", "aar", "gz", "tar", "7z", "rar")
private fun iconFor(i: Item): ImageVector {
    val e = i.name.substringAfterLast('.', "").lowercase()
    return when { i.dir -> Ic.Folder; e in IMG_EXT -> Ic.Image; e in ZIP_EXT -> Ic.FileZip; else -> Ic.File }
}

private sealed class Dlg {
    object NewFile : Dlg(); object NewFolder : Dlg(); object Branches : Dlg(); object NewBranch : Dlg()
    class Rename(val path: String) : Dlg()
    class MoveTo(val paths: List<String>) : Dlg()
    class Delete(val paths: List<String>) : Dlg()
    class DelBranch(val name: String) : Dlg()
    /** onChoice(0) = replace the existing ones, onChoice(1) = keep both (the new ones get a "(copy)" name). */
    class Clash(val names: List<String>, val onCancel: () -> Unit = {}, val onChoice: (Int) -> Unit) : Dlg()
}

/* ───────────── screen ───────────── */
@Composable fun RepoManagerScreen(vm: VM) {
    val doc = vm.mgrEdit; val img = vm.mgrImage
    when {
        doc != null -> EditorScreen(vm, doc)
        img != null -> ImageScreen(vm, img)
        else -> ManagerBody(vm)
    }
}

@Composable private fun MItem(icon: ImageVector, text: String, tint: Color = Cl.text, onClick: () -> Unit) =
    DropdownMenuItem(text = { Text(text, color = tint, fontSize = 14.sp) }, leadingIcon = { Ico(icon, tint, 18.dp) }, onClick = onClick)

@Composable private fun NameDialog(icon: ImageVector, title: String, label: String, initial: String, confirmText: String, hint: String? = null,
                                   allowBlank: Boolean = false, validate: (String) -> String?, onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var v by remember { mutableStateOf(initial) }
    val err = if (v.isBlank() && !allowBlank) null else validate(v)
    val okay = (allowBlank || v.isNotBlank()) && validate(v) == null
    CfAlert(onDismissRequest = onDismiss, icon = { Ico(icon, Cl.accent, 28.dp) }, title = { Text(title) },
        text = { Column {
            OutlinedTextField(v, { v = it }, label = { Text(label) }, singleLine = true, isError = err != null,
                supportingText = { if (err != null) Text(err) }, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth())
            if (hint != null) { Spacer(Modifier.height(8.dp)); Muted(hint, 12) }
        } },
        confirmButton = { FrameButton(onClick = { onConfirm(v) }, enabled = okay) { Text(confirmText, color = Cl.accent) } },
        dismissButton = { FrameButton(onClick = onDismiss) { Text("إلغاء") } })
}

@OptIn(ExperimentalFoundationApi::class)
@Composable private fun ItemRow(item: Item, selMode: Boolean, selected: Boolean, searching: Boolean,
                                onClick: () -> Unit, onLong: () -> Unit, onAction: (String) -> Unit) {
    var menu by remember { mutableStateOf(false) }
    Row(Modifier.fillMaxWidth().background(if (selected) Cl.accent.copy(alpha = .13f) else Color.Transparent)
        .combinedClickable(onClick = onClick, onLongClick = onLong).padding(start = 14.dp, end = 6.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically) {
        if (selMode) { Checkbox(selected, onCheckedChange = null); Spacer(Modifier.width(10.dp)) }
        Box(Modifier.size(38.dp).clip(RoundedCornerShape(11.dp)).background((if (item.dir) Cl.accent else Cl.muted).copy(alpha = .14f)), contentAlignment = Alignment.Center) {
            Ico(iconFor(item), if (item.dir) Cl.accent else Cl.muted, 20.dp)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(item.name, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = if (item.dir) FontWeight.SemiBold else FontWeight.Normal)
            val sub = when {
                item.dir -> "${item.count} ملف · ${sz(item.size)}"
                item.type == "commit" -> "وحدة فرعية (submodule)"
                searching -> sz(item.size) + " · " + parentOf(item.path).ifEmpty { "/" }
                else -> sz(item.size)
            }
            Muted(sub, 11)
        }
        if (!selMode) Box {
            IconButton(onClick = { menu = true }) { Ico(Ic.More, Cl.muted, 20.dp) }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                fun act(k: String) { menu = false; onAction(k) }
                if (!item.dir) MItem(Ic.Edit, "فتح / تعديل") { act("open") }
                MItem(Ic.Edit, "إعادة تسمية") { act("rename") }
                MItem(Ic.FolderMove, "نقل إلى…") { act("move") }
                MItem(Ic.Scissors, "قص") { act("cut") }
                MItem(Ic.Copy, "نسخ") { act("copy") }
                if (!item.dir) MItem(Ic.Download, "تنزيل إلى الجهاز") { act("download") }
                MItem(Ic.History, "سجل التغييرات") { act("history") }
                MItem(Ic.Copy, "نسخ المسار") { act("path") }
                MItem(Ic.Trash, "حذف", Cl.bad) { act("delete") }
            }
        }
    }
}

@Composable private fun ActBtn(icon: ImageVector, text: String, tint: Color = Cl.accent, enabled: Boolean = true, onClick: () -> Unit) =
    OutlinedButton(onClick = onClick, enabled = enabled, shape = RoundedCornerShape(12.dp), border = BorderStroke(1.dp, tint.copy(alpha = if (enabled) .5f else .25f)),
        contentPadding = PaddingValues(horizontal = 12.dp), modifier = Modifier.height(38.dp)) { Ico(icon, tint, 17.dp); Spacer(Modifier.width(7.dp)); Text(text, color = tint, fontSize = 13.sp) }

@Composable private fun WorkCard(vm: VM, w: VM.Work) = Card2 {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(w.label, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, modifier = Modifier.weight(1f))
        if (w.total > 0) Text("${(w.done * 100 / w.total).toInt()}%", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Cl.accent)
        IconButton(onClick = { vm.mgrCancel() }, modifier = Modifier.size(28.dp)) { Ico(Ic.Close, Cl.muted, 18.dp) }
    }
    Spacer(Modifier.height(6.dp))
    if (w.total > 0) {
        LinearProgressIndicator(progress = { (w.done.toFloat() / w.total).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)), color = Cl.accent, trackColor = Cl.line)
        Spacer(Modifier.height(4.dp)); Muted("${sz(w.done)} / ${sz(w.total)}", 12)
    } else {
        LinearProgressIndicator(Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)), color = Cl.accent, trackColor = Cl.line)
        if (w.done > 0) { Spacer(Modifier.height(4.dp)); Muted(sz(w.done), 12) }
    }
}

@Composable private fun ManagerBody(vm: VM) {
    val clipM = LocalClipboardManager.current
    LaunchedEffect(vm.repo) { vm.mgrStart() }
    var query by remember { mutableStateOf("") }
    var searching by remember { mutableStateOf(false) }
    var sel by remember { mutableStateOf(setOf<String>()) }
    var dlg by remember { mutableStateOf<Dlg?>(null) }
    var zipSheet by remember { mutableStateOf(false) }
    var topMenu by remember { mutableStateOf(false) }
    val snap = vm.mgrSnap; val dir = vm.mgrDir
    val q = if (searching) query else ""
    val rows = remember(snap, dir, q) { if (snap == null) emptyList() else listDir(snap, dir, q) }
    val selMode = sel.isNotEmpty()

    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { us -> if (us.isNotEmpty()) vm.mgrPickedFiles(us) }
    val zipPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) vm.mgrPickedZip(u) }

    // files picked from the system picker: upload at once, or ask first if names already exist here
    val pending = vm.mgrPending
    LaunchedEffect(pending) {
        if (pending != null) {
            val clashes = pending.map { joinP(vm.mgrDir, it.first) }.filter { vm.mgrExists(it) }
            if (clashes.isEmpty()) vm.mgrUploadFiles(vm.mgrDir, false)
            else dlg = Dlg.Clash(clashes, onCancel = { vm.mgrCancelPending() }) { c -> vm.mgrUploadFiles(vm.mgrDir, c == 1) }
        }
    }

    BackHandler(enabled = !vm.drawerOpen && !selMode && !searching && dir.isNotEmpty()) { vm.mgrDir = parentOf(dir) }
    BackHandler(enabled = !vm.drawerOpen && !selMode && searching) { searching = false; query = "" }
    BackHandler(enabled = !vm.drawerOpen && selMode) { sel = emptySet() }

    fun paste() {
        val c = vm.mgrClip ?: return
        val clashes = vm.mgrClashes(c.paths, vm.mgrDir)
        if (clashes.isEmpty()) vm.mgrTransfer(c.paths, vm.mgrDir, c.cut, false)
        else dlg = Dlg.Clash(clashes) { ch -> vm.mgrTransfer(c.paths, vm.mgrDir, c.cut, ch == 1) }
    }
    fun setClip(paths: List<String>, cut: Boolean) {
        vm.mgrClip = VM.MgrClip(paths, cut); sel = emptySet()
        vm.toast = (if (cut) "تم قص " else "تم نسخ ") + "${paths.size} عنصر. انتقل إلى المسار الوجهة واضغط «لصق»"
    }
    fun act(it: Item, k: String) {
        when (k) {
            "open" -> vm.mgrOpenFile(it.path)
            "rename" -> dlg = Dlg.Rename(it.path)
            "move" -> dlg = Dlg.MoveTo(listOf(it.path))
            "cut" -> setClip(listOf(it.path), true)
            "copy" -> setClip(listOf(it.path), false)
            "download" -> vm.mgrDownload(it.path)
            "history" -> vm.mgrShowHistory(it.path)
            "path" -> { clipM.setText(AnnotatedString(it.path)); vm.toast = "تم نسخ المسار" }
            "delete" -> dlg = Dlg.Delete(listOf(it.path))
        }
    }

    Column(Modifier.fillMaxSize()) {
        // ── top controls ──
        Column(Modifier.fillMaxWidth().background(Cl.bg)) {
            if (selMode) Row(Modifier.fillMaxWidth().padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { sel = emptySet() }) { Ico(Ic.Close, Cl.text, 22.dp) }
                Text("${sel.size} محدد", fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                IconButton(onClick = { sel = rows.map { it.path }.toSet() }) { Ico(Ic.SelectAll, Cl.muted, 22.dp) }
                IconButton(onClick = { setClip(sel.toList(), true) }) { Ico(Ic.Scissors, Cl.muted, 21.dp) }
                IconButton(onClick = { setClip(sel.toList(), false) }) { Ico(Ic.Copy, Cl.muted, 21.dp) }
                IconButton(onClick = { dlg = Dlg.MoveTo(sel.toList()) }) { Ico(Ic.FolderMove, Cl.muted, 22.dp) }
                IconButton(onClick = { dlg = Dlg.Delete(sel.toList()) }) { Ico(Ic.Trash, Cl.bad, 21.dp) }
            } else Row(Modifier.fillMaxWidth().padding(start = 12.dp, end = 4.dp, top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Row(Modifier.clip(RoundedCornerShape(10.dp)).background(Cl.raised).clickable { dlg = Dlg.Branches }.padding(horizontal = 10.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                    Ico(Ic.GitBranch, Cl.accent, 16.dp); Spacer(Modifier.width(6.dp))
                    Text(vm.curBranch, fontSize = 13.sp, fontFamily = FontFamily.Monospace, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 150.dp))
                }
                Spacer(Modifier.weight(1f))
                IconButton(onClick = { searching = !searching; if (!searching) query = "" }) { Ico(Ic.Search, if (searching) Cl.accent else Cl.muted, 21.dp) }
                IconButton(onClick = { vm.mgrStart() }) { Ico(Ic.Refresh, Cl.muted, 21.dp) }
                Box {
                    IconButton(onClick = { topMenu = true }) { Ico(Ic.More, Cl.muted, 21.dp) }
                    DropdownMenu(expanded = topMenu, onDismissRequest = { topMenu = false }) {
                        MItem(Ic.History, "سجل هذا المسار") { topMenu = false; vm.mgrShowHistory(dir) }
                        MItem(Ic.Download, "تنزيل نسخة ZIP من المستودع") { topMenu = false; vm.mgrBackup() }
                        MItem(Ic.Copy, "نسخ مسار المجلد") { topMenu = false; clipM.setText(AnnotatedString(dir.ifEmpty { "/" })); vm.toast = "تم نسخ المسار" }
                        MItem(Ic.SelectAll, "تحديد الكل") { topMenu = false; sel = rows.map { it.path }.toSet() }
                    }
                }
            }
            if (searching) OutlinedTextField(query, { query = it }, placeholder = { Text("بحث بالاسم أو المسار في كل المستودع…") }, leadingIcon = { Ico(Ic.Search, Cl.muted) },
                singleLine = true, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp))
            else {
                // breadcrumbs: tap a part to jump there
                val parts = if (dir.isEmpty()) emptyList() else dir.split('/')
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Row(Modifier.clip(RoundedCornerShape(8.dp)).clickable { vm.mgrDir = "" }.padding(horizontal = 6.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Ico(Ic.Home, if (parts.isEmpty()) Cl.text else Cl.accent, 16.dp); Spacer(Modifier.width(5.dp))
                        Text(vm.repo?.substringAfter('/') ?: "", fontSize = 13.sp, color = if (parts.isEmpty()) Cl.text else Cl.accent, fontFamily = FontFamily.Monospace)
                    }
                    parts.forEachIndexed { i, n ->
                        Ico(Ic.ChevronLeft, Cl.muted, 14.dp)
                        val last = i == parts.lastIndex
                        Text(n, fontSize = 13.sp, fontFamily = FontFamily.Monospace, color = if (last) Cl.text else Cl.accent,
                            modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable { vm.mgrDir = parts.take(i + 1).joinToString("/") }.padding(horizontal = 6.dp, vertical = 4.dp))
                    }
                }
            }
            // actions for the current folder
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                val free = vm.mgrWork == null
                ActBtn(Ic.Upload, "رفع ملفات", enabled = free) { filePicker.launch(arrayOf("*/*")) }
                ActBtn(Ic.FileZip, "رفع ZIP", enabled = free) { zipSheet = true }
                ActBtn(Ic.FilePlus, "ملف جديد", enabled = free) { dlg = Dlg.NewFile }
                ActBtn(Ic.FolderPlus, "مجلد جديد", enabled = free) { dlg = Dlg.NewFolder }
                vm.mgrClip?.let { c -> ActBtn(Ic.Paste, "لصق (${c.paths.size}${if (c.cut) " · قص" else ""})", Cl.ok, free) { paste() } }
                vm.mgrClip?.let { ActBtn(Ic.Close, "إفراغ الحافظة", Cl.muted) { vm.mgrClip = null } }
            }
            HorizontalDivider(color = Cl.line, modifier = Modifier.padding(top = 6.dp))
        }
        vm.mgrWork?.let { WorkCard(vm, it) }
        if (snap?.truncated == true) Card2 { Row(verticalAlignment = Alignment.CenterVertically) {
            Ico(Ic.Alert, Cl.warn, 18.dp); Spacer(Modifier.width(8.dp)); Muted("المستودع ضخم جداً: عرض GitHub جزءاً من الملفات فقط، فبعض العمليات الشاملة معطّلة.", 12, color = Cl.warn) } }

        PLazy({ vm.pullMgr() }, Modifier.weight(1f), contentPadding = PaddingValues(bottom = 24.dp)) {
            if (snap == null) item { Box(Modifier.fillMaxWidth().padding(40.dp), Alignment.Center) { CircularProgressIndicator(color = Cl.accent) } }
            else {
                if (dir.isNotEmpty() && !searching) item(key = "..") {
                    Row(Modifier.fillMaxWidth().clickable { vm.mgrDir = parentOf(dir) }.padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(38.dp), contentAlignment = Alignment.Center) { Ico(Ic.ArrowUp, Cl.muted, 20.dp) }
                        Spacer(Modifier.width(12.dp)); Text("..", color = Cl.muted, fontFamily = FontFamily.Monospace)
                    }
                }
                if (rows.isEmpty()) item { Empty(Ic.Folder, if (searching && query.isNotBlank()) "لا نتائج" else "هذا المجلد فارغ") }
                items(rows, key = { it.path }) { it0 ->
                    ItemRow(it0, selMode, it0.path in sel, searching && query.isNotBlank(),
                        onClick = {
                            if (selMode) sel = if (it0.path in sel) sel - it0.path else sel + it0.path
                            else if (it0.dir) { vm.mgrDir = it0.path; if (searching) { searching = false; query = "" } }
                            else vm.mgrOpenFile(it0.path)
                        },
                        onLong = { sel = sel + it0.path },
                        onAction = { k -> act(it0, k) })
                }
            }
        }
    }

    // ── dialogs ──
    when (val d = dlg) {
        null -> {}
        Dlg.NewFile -> NameDialog(Ic.FilePlus, "ملف جديد", "اسم الملف", "", "إنشاء", hint = "داخل: /${dir}. يمكنك كتابة مسار مثل src/app.js لإنشاء المجلدات تلقائياً.",
            validate = { v -> if (normPath(joinP(dir, v.trim())).isNullOrEmpty() || v.trim().endsWith("/")) "اسم غير صالح" else if (vm.mgrExists(normPath(joinP(dir, v.trim()))!!)) "موجود مسبقاً" else null },
            onDismiss = { dlg = null }) { v -> dlg = null; vm.mgrNewFile(normPath(joinP(dir, v.trim()))!!) }
        Dlg.NewFolder -> NameDialog(Ic.FolderPlus, "مجلد جديد", "اسم المجلد", "", "إنشاء", hint = "git لا يحفظ المجلدات الفارغة، لذلك يُضاف ملف .gitkeep داخله.",
            validate = { v -> val p = normPath(joinP(dir, v.trim())); if (p.isNullOrEmpty()) "اسم غير صالح" else if (vm.mgrExists(p)) "موجود مسبقاً" else null },
            onDismiss = { dlg = null }) { v -> dlg = null; vm.mgrNewFolder(normPath(joinP(dir, v.trim()))!!) }
        is Dlg.Rename -> NameDialog(Ic.Edit, "إعادة التسمية", "الاسم الجديد", nameOf(d.path), "حفظ",
            validate = { v -> val n = v.trim(); if (n.contains('/') || n == "." || n == ".." || n.equals(".git", true)) "اسم غير صالح" else if (n != nameOf(d.path) && vm.mgrExists(joinP(parentOf(d.path), n))) "موجود مسبقاً" else null },
            onDismiss = { dlg = null }) { v -> dlg = null; if (v.trim() != nameOf(d.path)) { vm.mgrRename(d.path, v.trim()); sel = emptySet() } }
        is Dlg.MoveTo -> NameDialog(Ic.FolderMove, "نقل إلى مسار", "المجلد الوجهة", parentOf(d.paths.first()), "نقل", allowBlank = true,
            hint = "اتركه فارغاً للنقل إلى جذر المستودع. تُنشأ المجلدات غير الموجودة تلقائياً.",
            validate = { v -> val p = normPath(v); if (p == null) "مسار غير صالح" else if (d.paths.all { parentOf(it) == p }) "هذا هو المسار الحالي" else if (d.paths.any { p == it || p.startsWith("$it/") }) "لا يمكن النقل إلى داخل العنصر نفسه" else null },
            onDismiss = { dlg = null }) { v ->
            val dest = normPath(v) ?: ""
            val clashes = vm.mgrClashes(d.paths, dest)
            sel = emptySet()
            if (clashes.isEmpty()) { dlg = null; vm.mgrTransfer(d.paths, dest, true, false) }
            else dlg = Dlg.Clash(clashes) { ch -> vm.mgrTransfer(d.paths, dest, true, ch == 1) }
        }
        is Dlg.Delete -> CfAlert(onDismissRequest = { dlg = null }, icon = { Ico(Ic.Trash, Cl.bad, 28.dp) }, title = { Text("حذف ${d.paths.size} عنصر؟") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Muted(d.paths.take(4).joinToString("\n") { it } + if (d.paths.size > 4) "\n… و${d.paths.size - 4} أخرى" else "", 12, true)
                Text("سيُنشأ Commit بالحذف على الفرع «${vm.curBranch}»، ويمكن استرجاع الملفات لاحقاً من سجل Git.", fontSize = 13.sp)
                if (d.paths.any { it == ".github" || it == ".github/workflows" || it == PROTECTED_FILE }) Muted("تنبيه: هذا يشمل سكربت البناء؛ يعاد تثبيته تلقائياً عند رفع مشروع جديد.", 12, color = Cl.warn)
            } },
            confirmButton = { FrameButton(onClick = { dlg = null; sel = emptySet(); vm.mgrDelete(d.paths) }) { Text("حذف", color = Cl.bad) } },
            dismissButton = { FrameButton(onClick = { dlg = null }) { Text("إلغاء") } })
        is Dlg.Clash -> CfAlert(onDismissRequest = { d.onCancel(); dlg = null }, icon = { Ico(Ic.Alert, Cl.warn, 28.dp) }, title = { Text("توجد عناصر بنفس الاسم") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Muted(d.names.take(4).joinToString("\n") { nameOf(it) } + if (d.names.size > 4) "\n… و${d.names.size - 4} أخرى" else "", 13, true)
                OutlinedButton(onClick = { dlg = null; d.onChoice(0) }, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) { Text("استبدال الموجود") }
                OutlinedButton(onClick = { dlg = null; d.onChoice(1) }, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) { Text("الاحتفاظ بالاثنين") }
                Muted("«الاحتفاظ بالاثنين» يعطي الجديد اسماً مثل: name (copy).", 12)
            } },
            confirmButton = { FrameButton(onClick = { d.onCancel(); dlg = null }) { Text("إلغاء") } })
        Dlg.Branches -> CfAlert(onDismissRequest = { dlg = null }, icon = { Ico(Ic.GitBranch, Cl.accent, 28.dp) }, title = { Text("الفروع") },
            text = { Column(Modifier.verticalScroll(rememberScrollState())) {
                vm.mgrBranches.ifEmpty { listOf(vm.curBranch) }.forEach { b ->
                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).clickable { dlg = null; if (b != vm.curBranch) { sel = emptySet(); vm.mgrSwitch(b) } }.padding(start = 8.dp, top = 2.dp, bottom = 2.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        if (b == vm.curBranch) Ico(Ic.Check, Cl.ok, 18.dp) else Spacer(Modifier.size(18.dp))
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) { Text(b, fontFamily = FontFamily.Monospace, fontSize = 14.sp); if (b == vm.defaultBranch) Muted("الافتراضي (يبني المشاريع)", 11) }
                        if (b != vm.defaultBranch) IconButton(onClick = { dlg = Dlg.DelBranch(b) }) { Ico(Ic.Trash, Cl.bad, 18.dp) }
                    }
                }
                CardBtn(Ic.Plus, "فرع جديد من ${vm.curBranch}", Cl.accent) { dlg = Dlg.NewBranch }
            } },
            confirmButton = { FrameButton(onClick = { dlg = null }) { Text("إغلاق") } })
        Dlg.NewBranch -> NameDialog(Ic.GitBranch, "فرع جديد", "اسم الفرع", "", "إنشاء", hint = "يُنشأ من آخر Commit في «${vm.curBranch}» ثم تنتقل إليه.",
            validate = { v -> if (!Regex("^[A-Za-z0-9._/-]+$").matches(v.trim())) "حروف إنجليزية وأرقام و - _ . / فقط" else if (v.trim() in vm.mgrBranches) "موجود مسبقاً" else null },
            onDismiss = { dlg = null }) { v -> dlg = null; sel = emptySet(); vm.mgrNewBranch(v) }
        is Dlg.DelBranch -> CfAlert(onDismissRequest = { dlg = null }, icon = { Ico(Ic.Trash, Cl.bad, 28.dp) }, title = { Text("حذف الفرع «${d.name}»؟") },
            text = { Text("يُحذف الفرع من المستودع. الـCommits غير المدموجة في فرع آخر قد تضيع.") },
            confirmButton = { FrameButton(onClick = { dlg = null; vm.mgrDeleteBranch(d.name) }) { Text("حذف", color = Cl.bad) } },
            dismissButton = { FrameButton(onClick = { dlg = null }) { Text("إلغاء") } })
    }

    vm.mgrHistory?.let { (path, list) ->
        CfAlert(onDismissRequest = { vm.mgrHistory = null }, icon = { Ico(Ic.History, Cl.accent, 28.dp) }, title = { Text("سجل: ${path.ifEmpty { "المستودع" }}", fontSize = 16.sp) },
            text = { Column(Modifier.heightIn(max = 380.dp).verticalScroll(rememberScrollState())) {
                if (list.isEmpty()) Muted("لا توجد Commits", 13)
                list.forEach { c ->
                    Text(c.message.lines().first(), fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Muted("${c.sha.take(7)} · ${c.author} · ${fmt(c.date)}", 11, true)
                    HorizontalDivider(Modifier.padding(vertical = 8.dp), color = Cl.line)
                }
            } },
            confirmButton = { FrameButton(onClick = { vm.mgrHistory = null }) { Text("إغلاق") } })
    }
    vm.mgrZip?.let { ZipDialog(vm, it) }
    if (zipSheet) FileBrowserSheet(onDismiss = { zipSheet = false }, onPick = { f -> zipSheet = false; vm.mgrPickedZip(Uri.fromFile(f)) },
        onSystem = { zipSheet = false; zipPicker.launch(arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream")) })
}

/** Choose how a ZIP is applied to a path: see the result (new / changed / deleted counts) before anything is committed. */
@Composable private fun ZipDialog(vm: VM, pack: ZipPack) {
    var target by remember(pack) { mutableStateOf(vm.mgrDir) }
    var mode by remember(pack) { mutableStateOf(1) }
    var strip by remember(pack) { mutableStateOf(pack.root != null) }
    val t = normPath(target)
    val plan = remember(pack, vm.mgrSnap, t, mode, strip) { if (t == null) null else planZip(pack, vm.mgrSnap, t, mode, strip) }
    val destructive = mode == 0 && (plan?.removed ?: 0) > 0
    @Composable fun opt(m: Int, title: String, desc: String) {
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { mode = m }.padding(vertical = 2.dp), verticalAlignment = Alignment.Top) {
            RadioButton(mode == m, { mode = m })
            Column(Modifier.padding(top = 12.dp)) { Text(title, fontSize = 14.sp, fontWeight = FontWeight.Medium); Muted(desc, 12) }
        }
    }
    CfAlert(onDismissRequest = { vm.mgrCancelZip() }, icon = { Ico(Ic.FileZip, Cl.accent, 28.dp) }, title = { Text("رفع ملف مضغوط") },
        text = { Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Muted("${pack.name} · ${pack.files.size} ملف · ${sz(pack.files.sumOf { it.bytes.size.toLong() })}", 12, true)
            OutlinedTextField(target, { target = it }, label = { Text("المسار الوجهة في المستودع") }, singleLine = true, isError = t == null,
                supportingText = { Text(if (t == null) "مسار غير صالح" else "فارغ = جذر المستودع") }, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth())
            if (pack.root != null) Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).clickable { strip = !strip }, verticalAlignment = Alignment.CenterVertically) {
                Checkbox(strip, { strip = it }); Text("تجاهل المجلد الجذري «${pack.root}» داخل الـZIP", fontSize = 13.sp)
            }
            opt(0, "استبدال كامل", "يُحذف كل ما في المسار ويُستبدل بمحتوى الـZIP (ملفات ومجلدات).")
            opt(1, "دمج: استبدال الملفات المتطابقة فقط", "تُضاف ملفات الـZIP وتُستبدل المتطابقة، وتبقى الملفات الأخرى في المسار.")
            opt(2, "تحديث الموجود فقط", "تُستبدل الملفات الموجودة أصلاً فقط، بلا إضافة ملفات جديدة ولا حذف.")
            HorizontalDivider(color = Cl.line)
            if (plan == null) Muted("أدخل مساراً صالحاً", 12, color = Cl.bad) else {
                Muted("جديد: ${plan.added}  ·  معدّل: ${plan.changed}  ·  دون تغيير: ${plan.same}", 13)
                if (plan.removed > 0) Muted("سيُحذف: ${plan.removed} ملف" + if (mode == 0) " (غير موجودة في الـZIP)" else " (تعارض ملف/مجلد)", 13, color = if (destructive) Cl.bad else Cl.warn)
                if (plan.skipped > 0) Muted("تُجاهل: ${plan.skipped} (ملف البناء المحمي أو ملفات جديدة في وضع التحديث فقط)", 12)
                if (plan.blocked) Muted("المستودع ضخم ولم يُعرض بالكامل: الاستبدال الكامل معطّل، استخدم الدمج.", 12, color = Cl.bad)
                else if (plan.puts.isEmpty() && plan.deletes.isEmpty()) Muted("لا توجد تغييرات لتطبيقها.", 12)
                else Muted("تُنفَّذ كلها في Commit واحد على الفرع «${vm.curBranch}»، ويمكن التراجع عنها من سجل Git. ملف البناء .github/workflows/build.yml محمي دائماً.", 11)
            }
        } },
        confirmButton = { FrameButton(onClick = { vm.mgrApplyZip(plan!!, pack.name, t!!) }, enabled = plan != null && !plan.blocked && (plan.puts.isNotEmpty() || plan.deletes.isNotEmpty())) {
            Text(if (destructive) "تطبيق وحذف" else "تطبيق", color = if (destructive) Cl.bad else Cl.accent) } },
        dismissButton = { FrameButton(onClick = { vm.mgrCancelZip() }) { Text("إلغاء") } })
}

/** Full-screen text editor for one file (new or existing). Saving makes one commit. */
@Composable private fun EditorScreen(vm: VM, doc: VM.EditDoc) {
    var text by remember(doc) { mutableStateOf(doc.text) }
    val dirty = doc.isNew || text != doc.text
    var exit by remember { mutableStateOf(false) }
    var save by remember { mutableStateOf(false) }
    val busy = vm.mgrWork != null
    BackHandler(enabled = !vm.drawerOpen) { if (dirty) exit = true else vm.mgrEdit = null }
    Column(Modifier.fillMaxSize().imePadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { if (dirty) exit = true else vm.mgrEdit = null }) { Ico(Ic.ArrowRight, Cl.text, 22.dp) }
            Column(Modifier.weight(1f)) {
                Text(nameOf(doc.path) + if (dirty) " •" else "", fontWeight = FontWeight.SemiBold, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Muted(doc.path + "  ·  " + vm.curBranch, 11, true)
            }
            Button(onClick = { save = true }, enabled = dirty && !busy, shape = RoundedCornerShape(12.dp), contentPadding = PaddingValues(horizontal = 14.dp)) {
                Ico(Ic.Save, Cl.bg, 18.dp); Spacer(Modifier.width(6.dp)); Text("حفظ")
            }
            Spacer(Modifier.width(6.dp))
        }
        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Cl.accent, trackColor = Cl.line) else HorizontalDivider(color = Cl.line)
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Box(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(14.dp)) {
                BasicTextField(text, { text = it }, modifier = Modifier.fillMaxWidth().heightIn(min = 320.dp),
                    textStyle = TextStyle(color = Cl.text, fontFamily = FontFamily.Monospace, fontSize = 13.sp, lineHeight = 19.sp, textDirection = TextDirection.Ltr),
                    cursorBrush = SolidColor(Cl.accent))
            }
        }
    }
    if (save) {
        var msg by remember { mutableStateOf("CloudForge: ${if (doc.isNew) "create" else "update"} ${doc.path}") }
        CfAlert(onDismissRequest = { save = false }, icon = { Ico(Ic.Save, Cl.accent, 28.dp) }, title = { Text("حفظ التعديل") },
            text = { Column {
                OutlinedTextField(msg, { msg = it }, label = { Text("رسالة الـCommit") }, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp)); Muted("الفرع: ${vm.curBranch}", 12, true)
            } },
            confirmButton = { FrameButton(onClick = { save = false; vm.mgrSave(doc.path, text, msg) }, enabled = msg.isNotBlank()) { Text("حفظ", color = Cl.accent) } },
            dismissButton = { FrameButton(onClick = { save = false }) { Text("إلغاء") } })
    }
    if (exit) CfAlert(onDismissRequest = { exit = false }, icon = { Ico(Ic.Alert, Cl.warn, 28.dp) }, title = { Text("تعديلات غير محفوظة") },
        text = { Text("إن خرجت الآن ستضيع تعديلاتك على «${nameOf(doc.path)}».") },
        confirmButton = { FrameButton(onClick = { exit = false; vm.mgrEdit = null }) { Text("تجاهل والخروج", color = Cl.bad) } },
        dismissButton = { FrameButton(onClick = { exit = false }) { Text("متابعة التعديل") } })
}

@Composable private fun ImageScreen(vm: VM, img: Pair<String, ByteArray>) {
    BackHandler(enabled = !vm.drawerOpen) { vm.mgrImage = null }
    val bmp = remember(img) { try { BitmapFactory.decodeByteArray(img.second, 0, img.second.size) } catch (e: Exception) { null } }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { vm.mgrImage = null }) { Ico(Ic.ArrowRight, Cl.text, 22.dp) }
            Column(Modifier.weight(1f)) { Text(nameOf(img.first), fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis); Muted("${img.first} · ${sz(img.second.size.toLong())}", 11, true) }
            IconButton(onClick = { vm.mgrDownload(img.first) }) { Ico(Ic.Download, Cl.muted, 21.dp) }
        }
        HorizontalDivider(color = Cl.line)
        Box(Modifier.weight(1f).fillMaxWidth().padding(12.dp), Alignment.Center) {
            if (bmp != null) Image(bmp.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit) else Muted("تعذر عرض الصورة", 13)
        }
    }
}
