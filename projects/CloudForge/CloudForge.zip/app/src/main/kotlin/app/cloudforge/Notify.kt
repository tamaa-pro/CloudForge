package app.cloudforge

import android.app.Application
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat

/**
 * All notifications of the app.
 *  - progress (ongoing, with bar + working "إلغاء" button): app download, project upload, cloud build
 *  - result (normal, dismissible): finished / failed
 *  - app errors (also when the app crashes)
 * While any task is active a small foreground service keeps the process alive so the work continues with the app in the background.
 */
object Notif {
    const val CH_PROG = "cf_progress"; const val CH_DONE = "cf_done"; const val CH_ERR = "cf_error"; const val CH_KEEP = "cf_keep"
    const val ACT_CANCEL = "app.cloudforge.CANCEL"
    const val ID_KEEP = 1; const val ID_UPLOAD = 2; const val ID_APP_ERR = 3; const val ID_CRASH = 4
    fun idDownload(asset: Long) = 100_000 + (asset % 400_000).toInt()
    fun idRun(run: Long) = 600_000 + (run % 1_000_000).toInt()

    /** True while the app is on screen (errors are then shown in the app itself). */
    @Volatile var fg = false
    /** (kind, key) of a tapped "إلغاء" button: kind = dl | up | run. */
    @Volatile var handler: ((String, Long) -> Unit)? = null

    private var ctx: Context? = null
    private val ongoing = mutableSetOf<Int>()
    private val active = linkedSetOf<String>()

    fun init(c: Context) {
        if (ctx != null) return
        ctx = c.applicationContext
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_PROG, "التقدم الجاري", NotificationManager.IMPORTANCE_LOW).apply { setShowBadge(false) })
        nm.createNotificationChannel(NotificationChannel(CH_DONE, "اكتمال العمليات", NotificationManager.IMPORTANCE_DEFAULT))
        nm.createNotificationChannel(NotificationChannel(CH_ERR, "الأخطاء والفشل", NotificationManager.IMPORTANCE_HIGH))
        nm.createNotificationChannel(NotificationChannel(CH_KEEP, "التشغيل في الخلفية", NotificationManager.IMPORTANCE_MIN).apply { setShowBadge(false) })
    }

    private fun nm() = ctx?.getSystemService(NotificationManager::class.java)
    private fun post(id: Int, n: Notification) { try { nm()?.notify(id, n) } catch (e: Exception) { } }
    private fun open(c: Context): PendingIntent = PendingIntent.getActivity(c, 0,
        Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    private fun cancelIntent(c: Context, kind: String, key: Long): PendingIntent = PendingIntent.getBroadcast(c, "$kind:$key".hashCode(),
        Intent(c, ActionReceiver::class.java).setAction(ACT_CANCEL).putExtra("kind", kind).putExtra("key", key),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

    /** Ongoing notification with a progress bar ([pct] null = indeterminate) and, when [kind] is given, a cancel button. */
    fun progress(id: Int, title: String, text: String, pct: Int?, kind: String?, key: Long = 0) {
        val c = ctx ?: return
        val b = NotificationCompat.Builder(c, CH_PROG).setSmallIcon(R.drawable.ic_stat).setContentTitle(title).setContentText(text)
            .setOngoing(true).setOnlyAlertOnce(true).setContentIntent(open(c)).setCategory(NotificationCompat.CATEGORY_PROGRESS)
            .setProgress(100, pct ?: 0, pct == null)
        if (kind != null) b.addAction(0, "إلغاء", cancelIntent(c, kind, key))
        synchronized(ongoing) { ongoing += id }
        post(id, b.build())
    }

    /** Normal, dismissible notification (replaces the ongoing one with the same id). */
    fun done(id: Int, title: String, text: String) = result(CH_DONE, id, title, text)
    fun error(id: Int, title: String, text: String) = result(CH_ERR, id, title, text)
    private fun result(ch: String, id: Int, title: String, text: String) {
        val c = ctx ?: return
        synchronized(ongoing) { ongoing -= id }
        post(id, NotificationCompat.Builder(c, ch).setSmallIcon(R.drawable.ic_stat).setContentTitle(title).setContentText(text.lineSequence().firstOrNull() ?: "")
            .setStyle(NotificationCompat.BigTextStyle().bigText(text)).setAutoCancel(true).setOngoing(false).setContentIntent(open(c)).build())
    }
    fun cancel(id: Int) { synchronized(ongoing) { ongoing -= id }; try { nm()?.cancel(id) } catch (e: Exception) { } }
    /** Removes every ongoing notification (app closed / crashed) and stops the service. */
    fun clearAll() {
        val ids = synchronized(ongoing) { ongoing.toList().also { ongoing.clear() } }
        ids.forEach { try { nm()?.cancel(it) } catch (e: Exception) { } }
        synchronized(active) { active.clear() }
        ctx?.let { try { it.stopService(Intent(it, TaskService::class.java)) } catch (e: Exception) { } }
    }

    /** A task is running: keep the process alive (foreground service) until the last one ends. */
    fun begin(key: String) {
        val c = ctx ?: return
        synchronized(active) {
            val first = active.isEmpty(); active += key
            if (first) try { ContextCompat.startForegroundService(c, Intent(c, TaskService::class.java)) } catch (e: Exception) { }
        }
    }
    fun end(key: String) {
        val c = ctx ?: return
        synchronized(active) { active -= key; if (active.isEmpty()) try { c.stopService(Intent(c, TaskService::class.java)) } catch (e: Exception) { } }
    }
    fun keepNotification(c: Context): Notification = NotificationCompat.Builder(c, CH_KEEP).setSmallIcon(R.drawable.ic_stat)
        .setContentTitle("CloudForge يعمل في الخلفية").setContentText("مهام جارية…").setOngoing(true).setContentIntent(open(c)).build()
}

class TaskService : Service() {
    override fun onBind(i: Intent?): IBinder? = null
    override fun onCreate() {
        super.onCreate(); Notif.init(this)
        startForeground(Notif.ID_KEEP, Notif.keepNotification(this), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
    }
    override fun onStartCommand(i: Intent?, f: Int, id: Int) = START_NOT_STICKY
}

class ActionReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action != Notif.ACT_CANCEL) return
        val kind = i.getStringExtra("kind") ?: return
        Notif.handler?.invoke(kind, i.getLongExtra("key", 0))
    }
}

class CfApp : Application() {
    override fun onCreate() {
        super.onCreate(); Notif.init(this)
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                Notif.clearAll()
                Notif.error(Notif.ID_CRASH, "تعطّل CloudForge", (e.message ?: e.toString()).take(300) + (e.stackTrace.firstOrNull()?.let { "\n$it" } ?: ""))
            } catch (x: Throwable) { }
            prev?.uncaughtException(t, e)
        }
    }
}
