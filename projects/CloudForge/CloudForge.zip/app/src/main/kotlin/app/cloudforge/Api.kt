package app.cloudforge

import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import okhttp3.FormBody
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import okio.BufferedSink
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.job
import kotlin.coroutines.coroutineContext
import java.io.IOException
import java.util.concurrent.TimeUnit
import org.json.JSONArray
import org.json.JSONObject
import java.io.OutputStream

class ApiError(msg: String, val code: Int = 0) : Exception(msg)

/** Turns a GitHub error response into a message that says what to do. 401 and 404 are also detected by the app by code. */
fun apiError(c: Int, body: String): ApiError {
    val m = try { JSONObject(body).optString("message") } catch (e: Exception) { "" }
    val msg = when {
        c == 401 -> "انتهت صلاحية جلسة GitHub (401). سجّل الدخول من جديد."
        c == 403 && m.contains("rate limit", true) -> "تجاوزت حد طلبات GitHub مؤقتاً (403). انتظر قليلاً وحاول مجدداً."
        c == 404 -> "GitHub 404: المورد غير موجود (قد يكون المستودع حُذف أو أُعيدت تسميته، أو لا تملك صلاحية عليه). $m".trim()
        else -> "GitHub $c: ${(m.ifEmpty { body }).take(160)}"
    }
    return ApiError(msg, c)
}

// OkHttp's default is 10 s connect/read/write, which is far too short for a multi-MB upload on a mobile connection.
val http: OkHttpClient = OkHttpClient.Builder()
    .connectTimeout(30, TimeUnit.SECONDS).readTimeout(60, TimeUnit.SECONDS).writeTimeout(60, TimeUnit.SECONDS)
    .retryOnConnectionFailure(true).build()
/** Uploads: the write timeout applies per socket write, so a slow link is fine as long as bytes keep moving. */
val uploadHttp: OkHttpClient = http.newBuilder()
    .writeTimeout(2, TimeUnit.MINUTES).readTimeout(3, TimeUnit.MINUTES).callTimeout(0, TimeUnit.MILLISECONDS).build()
private val JSON_MT = "application/json".toMediaType()

fun JSONArray.list(): List<JSONObject> = (0 until length()).map { getJSONObject(it) }
fun JSONObject.s(k: String): String = if (isNull(k)) "" else getString(k)

/** GitHub OAuth Device Flow: no client secret, no pasted tokens. */
object Auth {
    private suspend fun post(url: String, vararg f: Pair<String, String>): JSONObject = withContext(Dispatchers.IO) {
        val b = FormBody.Builder().apply { f.forEach { add(it.first, it.second) } }.build()
        val r = Request.Builder().url(url).header("Accept", "application/json").post(b).build()
        http.newCall(r).execute().use {
            val txt = it.body?.string() ?: ""
            // GitHub can answer 5xx with an HTML page: that is a transient failure, not a JSON document
            try { JSONObject(txt.ifBlank { "{}" }) } catch (e: org.json.JSONException) { throw IOException("GitHub ${it.code}: رد غير متوقع") }
        }
    }

    private fun friendly(j: JSONObject): String = when (j.s("error")) {
        "expired_token" -> "انتهت مهلة رمز التحقق (15 دقيقة). اضغط «الربط مع GitHub» من جديد."
        "access_denied" -> "تم رفض الطلب في GitHub."
        "device_flow_disabled" -> "تسجيل الدخول بالرمز (Device Flow) غير مفعّل في إعدادات تطبيق OAuth على GitHub. فعّله من Developer settings."
        "incorrect_client_credentials", "unauthorized_client" -> "GitHub Client ID غير صحيح في هذا الإصدار من التطبيق."
        else -> j.s("error_description").ifEmpty { j.s("error") }
    }

    suspend fun start(cid: String): JSONObject {
        val j = post("https://github.com/login/device/code", "client_id" to cid, "scope" to "repo workflow delete_repo")
        if (j.has("error")) throw ApiError(friendly(j))
        return j
    }

    /** Waits for the user's approval. Network hiccups (the app sits in the background while the browser is open) never abort the login. */
    suspend fun poll(cid: String, dc: String, interval: Int, expiresIn: Int = 900): String {
        var i = interval
        val deadline = System.currentTimeMillis() + expiresIn * 1000L
        while (System.currentTimeMillis() < deadline) {
            delay(i * 1000L)
            val j = try {
                post("https://github.com/login/oauth/access_token", "client_id" to cid, "device_code" to dc,
                    "grant_type" to "urn:ietf:params:oauth:grant-type:device_code")
            } catch (e: CancellationException) { throw e } catch (e: IOException) { continue }
            when {
                j.has("access_token") -> return j.getString("access_token")
                j.s("error") == "authorization_pending" -> {}
                j.s("error") == "slow_down" -> i += 5
                else -> throw ApiError(friendly(j))
            }
        }
        throw ApiError("انتهت مهلة رمز التحقق. اضغط «الربط مع GitHub» من جديد.")
    }
}

/** {"encoding":"base64","content":"..."} streamed in small chunks so the upload can report real progress and never holds a second 4/3-sized copy in memory. */
private class Base64JsonBody(private val bytes: ByteArray, private val onProgress: (Long, Long) -> Unit) : RequestBody() {
    private val head = "{\"encoding\":\"base64\",\"content\":\"".toByteArray()
    private val tail = "\"}".toByteArray()
    override fun contentType() = JSON_MT
    override fun contentLength() = head.size + (bytes.size + 2) / 3 * 4L + tail.size
    override fun writeTo(sink: BufferedSink) {
        sink.write(head)
        val total = bytes.size.toLong(); var off = 0
        onProgress(0, total)
        while (off < bytes.size) {
            val n = minOf(3 * 8192, bytes.size - off)          // multiple of 3 -> chunks concatenate into valid base64
            sink.write(Base64.encode(bytes, off, n, Base64.NO_WRAP))
            sink.flush(); off += n
            onProgress(off.toLong(), total)
        }
        sink.write(tail)
    }
}

class Gh(private val token: String) {
    data class Projects(val folders: List<String>, val items: List<Pair<String, Long>>, val history: List<Pair<String, String>>)

    private suspend fun call(path: String, method: String = "GET", body: String? = null): Pair<Int, String> = withContext(Dispatchers.IO) {
        val url = if (path.startsWith("http")) path else "https://api.github.com$path"
        val rb = body?.toRequestBody(JSON_MT) ?: if (method == "GET" || method == "DELETE") null else "".toRequestBody()
        val r = Request.Builder().url(url).header("Authorization", "Bearer $token")
            .header("Accept", "application/vnd.github+json").header("X-GitHub-Api-Version", "2022-11-28")
            .method(method, rb).build()
        http.newCall(r).execute().use { it.code to (it.body?.string() ?: "") }
    }

    private suspend fun ok(path: String, method: String = "GET", body: String? = null): String {
        val (c, b) = call(path, method, body)
        if (c !in 200..299) throw apiError(c, b)
        return b
    }

    suspend fun user() = JSONObject(ok("/user"))
    suspend fun repos() = JSONArray(ok("/user/repos?per_page=100&sort=updated&affiliation=owner,collaborator,organization_member"))
        .list().filter { it.optJSONObject("permissions")?.optBoolean("push") == true }
    suspend fun repoInfo(full: String) = JSONObject(ok("/repos/$full"))
    suspend fun createRepo(name: String, priv: Boolean) = JSONObject(ok("/user/repos", "POST",
        JSONObject().put("name", name).put("private", priv).put("auto_init", true)
            .put("description", "CloudForge build repository").toString()))

    suspend fun installWorkflow(full: String, branch: String, yml: ByteArray) {
        val p = "/repos/$full/contents/.github/workflows/build.yml"
        val (c, b) = call("$p?ref=$branch")
        val j = JSONObject().put("message", "CloudForge: install build workflow")
            .put("content", Base64.encodeToString(yml, Base64.NO_WRAP)).put("branch", branch)
        if (c == 200) j.put("sha", JSONObject(b).getString("sha"))
        ok(p, "PUT", j.toString())
    }

    /** Keeps the repo's build script in sync with the one bundled in the app (so script improvements reach existing repos). */
    suspend fun ensureWorkflow(full: String, branch: String, yml: ByteArray) {
        val (c, b) = call("/repos/$full/contents/.github/workflows/build.yml?ref=$branch")
        if (c == 200 && Base64.decode(JSONObject(b).getString("content"), Base64.DEFAULT).contentEquals(yml)) return
        installWorkflow(full, branch, yml)
    }

    suspend fun projects(full: String, branch: String): Projects {
        val (c, b) = call("/repos/$full/git/trees/$branch?recursive=1")
        val re = Regex("^projects/[^/]+/.+\\.(zip|apk)$")
        val items = if (c == 200) JSONObject(b).getJSONArray("tree").list()
            .filter { it.getString("type") == "blob" && re.matches(it.getString("path")) }
            .map { it.getString("path") to it.getLong("size") } else emptyList()
        val (c2, b2) = call("/repos/$full/commits?path=projects&per_page=40")
        val hist = if (c2 == 200) JSONArray(b2).list().map { it.getJSONObject("commit") }
            .filter { it.getString("message").startsWith("CloudForge: upload ") }
            .map { it.getString("message").substring(19).lines()[0] to it.getJSONObject("author").getString("date") } else emptyList()
        return Projects(items.map { it.first.split("/")[1] }.distinct(), items, hist)
    }

    private suspend fun <T> retrying(times: Int = 3, f: suspend () -> T): T {
        var last: Exception? = null
        for (i in 0 until times) {
            try { return f() }
            catch (e: CancellationException) { throw e }
            catch (e: ApiError) { if (e.code < 500 && e.code != 429 && e.code != 0 && e.code != 401) throw e; last = e }   // 401 is retried too: GitHub sometimes answers it transiently
            catch (e: IOException) { last = e }
            if (i < times - 1) delay(1500L * (i + 1))
        }
        val e = last
        throw if (e is ApiError) e else ApiError("تعذّر إكمال الرفع (انقطع الاتصال أو انتهت المهلة). تحقق من الشبكة وحاول مجدداً. ${e?.message ?: ""}".trim())
    }

    /** Creates the blob with a streamed body (progress) and a cancellable call. Idempotent, so it is safe to retry. */
    private suspend fun createBlob(full: String, bytes: ByteArray, onProgress: (Long, Long) -> Unit): String = withContext(Dispatchers.IO) {
        val r = Request.Builder().url("https://api.github.com/repos/$full/git/blobs")
            .header("Authorization", "Bearer $token").header("Accept", "application/vnd.github+json")
            .header("X-GitHub-Api-Version", "2022-11-28").post(Base64JsonBody(bytes, onProgress)).build()
        val call = uploadHttp.newCall(r)
        val reg = coroutineContext.job.invokeOnCompletion { call.cancel() }
        try {
            call.execute().use {
                val b = it.body?.string() ?: ""
                if (!it.isSuccessful) throw apiError(it.code, b)
                JSONObject(b).getString("sha")
            }
        } finally { reg.dispose() }
    }

    /**
     * projects/<folder>/<name>.zip. A new project creates it; an update REPLACES it (same path) so the APK keeps the same name.
     * Uses the Git Data API (blob -> tree -> commit -> ref) instead of one giant Contents PUT: the big upload is a single
     * retryable blob request that reports progress; the rest are tiny calls.
     */
    suspend fun upload(full: String, branch: String, folder: String, name: String, bytes: ByteArray,
                       onStage: (String) -> Unit = {}, onProgress: (Long, Long) -> Unit = { _, _ -> }): String {
        val fp = "projects/$folder/$name.zip"
        onStage("upload")
        val blob = retrying { createBlob(full, bytes, onProgress) }
        onStage("commit")
        retrying(2) {
            val head = JSONObject(ok("/repos/$full/git/ref/heads/$branch")).getJSONObject("object").getString("sha")
            val baseTree = JSONObject(ok("/repos/$full/git/commits/$head")).getJSONObject("tree").getString("sha")
            val tree = JSONObject(ok("/repos/$full/git/trees", "POST", JSONObject().put("base_tree", baseTree)
                .put("tree", JSONArray().put(JSONObject().put("path", fp).put("mode", "100644").put("type", "blob").put("sha", blob))).toString())).getString("sha")
            val commit = JSONObject(ok("/repos/$full/git/commits", "POST", JSONObject().put("message", "CloudForge: upload $fp")
                .put("tree", tree).put("parents", JSONArray().put(head)).toString())).getString("sha")
            ok("/repos/$full/git/refs/heads/$branch", "PATCH", JSONObject().put("sha", commit).toString())
        }
        return fp
    }

    /** Manually rebuild one zip (even if unchanged). */
    suspend fun dispatch(full: String, branch: String, zip: String) {
        ok("/repos/$full/actions/workflows/build.yml/dispatches", "POST",
            JSONObject().put("ref", branch).put("inputs", JSONObject().put("zip", zip)).toString())
    }
    suspend fun deleteRun(full: String, id: Long) { ok("/repos/$full/actions/runs/$id", "DELETE") }
    suspend fun deleteFile(full: String, branch: String, path: String) {
        val (c, b) = call("/repos/$full/contents/$path?ref=$branch")
        if (c == 404) return
        if (c != 200) throw ApiError("GitHub $c")
        ok("/repos/$full/contents/$path", "DELETE", JSONObject().put("message", "CloudForge: delete $path [skip ci]")
            .put("sha", JSONObject(b).getString("sha")).put("branch", branch).toString())
    }
    suspend fun renameRepo(full: String, name: String) = JSONObject(ok("/repos/$full", "PATCH", JSONObject().put("name", name).toString()))
    suspend fun deleteRepo(full: String) { ok("/repos/$full", "DELETE") }
    suspend fun runs(full: String, n: Int) = JSONObject(ok("/repos/$full/actions/workflows/build.yml/runs?per_page=$n"))
        .getJSONArray("workflow_runs").list()
    suspend fun jobs(full: String, run: Long) = JSONObject(ok("/repos/$full/actions/runs/$run/jobs?per_page=50")).getJSONArray("jobs").list()
    suspend fun cancel(full: String, run: Long) { ok("/repos/$full/actions/runs/$run/cancel", "POST") }
    suspend fun hasSecret(full: String, name: String): Boolean {
        val (c, b) = call("/repos/$full/actions/secrets/$name")
        if (c == 200) return true
        if (c == 404) return false
        throw apiError(c, b)
    }

    suspend fun setSecret(full: String, name: String, value: String) {
        val pk = JSONObject(ok("/repos/$full/actions/secrets/public-key"))
        ok("/repos/$full/actions/secrets/$name", "PUT", JSONObject()
            .put("encrypted_value", Signing.seal(value.toByteArray(), pk.getString("key")))
            .put("key_id", pk.getString("key_id")).toString())
    }

    suspend fun releases(full: String) = JSONArray(ok("/repos/$full/releases?per_page=100")).list()

    /** The part of the job log that explains the failure: the lines leading up to the last ##[error], without ANSI colours or timestamps. */
    suspend fun log(full: String, job: Long): String {
        val (c, b) = call("/repos/$full/actions/jobs/$job/logs")
        if (c != 200) throw ApiError("GitHub $c")
        val ansi = Regex("\u001B\\[[0-9;]*[A-Za-z]")
        val l = b.lines().map { it.replace(Regex("^\\S+Z "), "").replace(ansi, "").trimEnd() }
            .filterNot { it.startsWith("##[group]") || it.startsWith("##[endgroup]") }
        val last = l.indexOfLast { it.startsWith("##[error]") }
        val from = if (last >= 0) maxOf(0, last - 60) else maxOf(0, l.size - 80)
        return l.drop(from).filter { it.isNotBlank() }.joinToString("\n") { it.removePrefix("##[error]").let { x -> if (it.startsWith("##[error]")) "ERROR: $x" else x } }
    }

    suspend fun deleteRelease(full: String, id: Long, tag: String) {
        ok("/repos/$full/releases/$id", "DELETE")
        call("/repos/$full/git/refs/tags/$tag", "DELETE")
    }

    /** Streams the APK into [out], reporting (bytesDone, bytesTotal). Stops promptly when the calling coroutine is cancelled. */
    suspend fun download(full: String, asset: Long, size: Long, out: OutputStream, onProgress: (Long, Long) -> Unit) = withContext(Dispatchers.IO) {
        val r = Request.Builder().url("https://api.github.com/repos/$full/releases/assets/$asset")
            .header("Authorization", "Bearer $token").header("Accept", "application/octet-stream").build()
        http.newCall(r).execute().use { resp ->
            if (!resp.isSuccessful) throw ApiError("GitHub ${resp.code}")
            val body = resp.body!!
            val total = body.contentLength().takeIf { it > 0 } ?: size
            val buf = ByteArray(64 * 1024); var done = 0L
            body.byteStream().use { inp ->
                while (true) {
                    val n = inp.read(buf); if (n < 0) break
                    out.write(buf, 0, n); done += n
                    onProgress(done, total)
                    ensureActive()
                }
            }
        }
    }
}
