package app.cloudforge

import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.FormBody
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.OutputStream

class ApiError(msg: String) : Exception(msg)

val http = OkHttpClient()
private val JSON_MT = "application/json".toMediaType()

fun JSONArray.list(): List<JSONObject> = (0 until length()).map { getJSONObject(it) }
fun JSONObject.s(k: String): String = if (isNull(k)) "" else getString(k)

/** GitHub OAuth Device Flow: no client secret, no pasted tokens. */
object Auth {
    private suspend fun post(url: String, vararg f: Pair<String, String>): JSONObject = withContext(Dispatchers.IO) {
        val b = FormBody.Builder().apply { f.forEach { add(it.first, it.second) } }.build()
        val r = Request.Builder().url(url).header("Accept", "application/json").post(b).build()
        http.newCall(r).execute().use { JSONObject(it.body?.string() ?: "{}") }
    }

    suspend fun start(cid: String): JSONObject {
        val j = post("https://github.com/login/device/code", "client_id" to cid, "scope" to "repo workflow delete_repo")
        if (j.has("error")) throw ApiError(j.s("error_description").ifEmpty { j.s("error") })
        return j
    }

    suspend fun poll(cid: String, dc: String, interval: Int): String {
        var i = interval
        while (true) {
            delay(i * 1000L)
            val j = post("https://github.com/login/oauth/access_token", "client_id" to cid, "device_code" to dc,
                "grant_type" to "urn:ietf:params:oauth:grant-type:device_code")
            when {
                j.has("access_token") -> return j.getString("access_token")
                j.s("error") == "authorization_pending" -> {}
                j.s("error") == "slow_down" -> i += 5
                else -> throw ApiError(j.s("error_description").ifEmpty { j.s("error") })
            }
        }
    }
}

class Gh(private val token: String) {
    data class Projects(val folders: List<String>, val items: List<Pair<String, Long>>, val history: List<Pair<String, String>>)

    private suspend fun call(path: String, method: String = "GET", body: String? = null): Pair<Int, String> = withContext(Dispatchers.IO) {
        val url = if (path.startsWith("http")) path else "https://api.github.com$path"
        val rb = body?.toRequestBody(JSON_MT) ?: if (method == "GET" || method == "DELETE") null else "".toRequestBody()
        val r = Request.Builder().url(url).header("Authorization", "Bearer $token")
            .header("Accept", "application/vnd.github+json").header("X-GitHub-Api-Version", "2022-11-28")
            .method(method, rb).build()
        http.newCall(r).execute().use { it.code to (it.body?.string() ?: "") }
    }

    private suspend fun ok(path: String, method: String = "GET", body: String? = null): String {
        val (c, b) = call(path, method, body)
        if (c !in 200..299) throw ApiError("GitHub $c: ${b.take(160)}")
        return b
    }

    suspend fun user() = JSONObject(ok("/user"))
    suspend fun repos() = JSONArray(ok("/user/repos?per_page=100&sort=updated&affiliation=owner,collaborator,organization_member"))
        .list().filter { it.optJSONObject("permissions")?.optBoolean("push") == true }
    suspend fun repoInfo(full: String) = JSONObject(ok("/repos/$full"))
    suspend fun createRepo(name: String, priv: Boolean) = JSONObject(ok("/user/repos", "POST",
        JSONObject().put("name", name).put("private", priv).put("auto_init", true)
            .put("description", "CloudForge build repository").toString()))

    suspend fun installWorkflow(full: String, branch: String, yml: ByteArray) {
        val p = "/repos/$full/contents/.github/workflows/build.yml"
        val (c, b) = call("$p?ref=$branch")
        val j = JSONObject().put("message", "CloudForge: install build workflow")
            .put("content", Base64.encodeToString(yml, Base64.NO_WRAP)).put("branch", branch)
        if (c == 200) j.put("sha", JSONObject(b).getString("sha"))
        ok(p, "PUT", j.toString())
    }

    /** Keeps the repo's build script in sync with the one bundled in the app (so script improvements reach existing repos). */
    suspend fun ensureWorkflow(full: String, branch: String, yml: ByteArray) {
        val (c, b) = call("/repos/$full/contents/.github/workflows/build.yml?ref=$branch")
        if (c == 200 && Base64.decode(JSONObject(b).getString("content"), Base64.DEFAULT).contentEquals(yml)) return
        installWorkflow(full, branch, yml)
    }

    suspend fun projects(full: String, branch: String): Projects {
        val (c, b) = call("/repos/$full/git/trees/$branch?recursive=1")
        val re = Regex("^projects/[^/]+/.+\\.(zip|apk)$")
        val items = if (c == 200) JSONObject(b).getJSONArray("tree").list()
            .filter { it.getString("type") == "blob" && re.matches(it.getString("path")) }
            .map { it.getString("path") to it.getLong("size") } else emptyList()
        val (c2, b2) = call("/repos/$full/commits?path=projects&per_page=40")
        val hist = if (c2 == 200) JSONArray(b2).list().map { it.getJSONObject("commit") }
            .filter { it.getString("message").startsWith("CloudForge: upload ") }
            .map { it.getString("message").substring(19).lines()[0] to it.getJSONObject("author").getString("date") } else emptyList()
        return Projects(items.map { it.first.split("/")[1] }.distinct(), items, hist)
    }

    /** projects/<folder>/<name>.zip. A new project creates it; an update REPLACES it (same path) so the APK keeps the same name. */
    suspend fun upload(full: String, branch: String, folder: String, name: String, bytes: ByteArray): String {
        val fp = "projects/$folder/$name.zip"
        val (c, b) = call("/repos/$full/contents/$fp?ref=$branch")
        val j = JSONObject().put("message", "CloudForge: upload $fp")
            .put("content", Base64.encodeToString(bytes, Base64.NO_WRAP)).put("branch", branch)
        when (c) { 200 -> j.put("sha", JSONObject(b).getString("sha")); 404 -> {}; else -> throw ApiError("GitHub $c") }
        ok("/repos/$full/contents/$fp", "PUT", j.toString())
        return fp
    }

    /** Manually rebuild one zip (even if unchanged). */
    suspend fun dispatch(full: String, branch: String, zip: String) {
        ok("/repos/$full/actions/workflows/build.yml/dispatches", "POST",
            JSONObject().put("ref", branch).put("inputs", JSONObject().put("zip", zip)).toString())
    }
    suspend fun deleteRun(full: String, id: Long) { ok("/repos/$full/actions/runs/$id", "DELETE") }
    suspend fun deleteFile(full: String, branch: String, path: String) {
        val (c, b) = call("/repos/$full/contents/$path?ref=$branch")
        if (c == 404) return
        if (c != 200) throw ApiError("GitHub $c")
        ok("/repos/$full/contents/$path", "DELETE", JSONObject().put("message", "CloudForge: delete $path [skip ci]")
            .put("sha", JSONObject(b).getString("sha")).put("branch", branch).toString())
    }
    suspend fun renameRepo(full: String, name: String) = JSONObject(ok("/repos/$full", "PATCH", JSONObject().put("name", name).toString()))
    suspend fun deleteRepo(full: String) { ok("/repos/$full", "DELETE") }
    suspend fun runs(full: String, n: Int) = JSONObject(ok("/repos/$full/actions/workflows/build.yml/runs?per_page=$n"))
        .getJSONArray("workflow_runs").list()
    suspend fun jobs(full: String, run: Long) = JSONObject(ok("/repos/$full/actions/runs/$run/jobs?per_page=50")).getJSONArray("jobs").list()
    suspend fun cancel(full: String, run: Long) { ok("/repos/$full/actions/runs/$run/cancel", "POST") }
    suspend fun hasSecret(full: String, name: String): Boolean {
        val (c, b) = call("/repos/$full/actions/secrets/$name")
        if (c == 200) return true
        if (c == 404) return false
        throw ApiError("GitHub $c: ${b.take(160)}")
    }

    suspend fun setSecret(full: String, name: String, value: String) {
        val pk = JSONObject(ok("/repos/$full/actions/secrets/public-key"))
        ok("/repos/$full/actions/secrets/$name", "PUT", JSONObject()
            .put("encrypted_value", Signing.seal(value.toByteArray(), pk.getString("key")))
            .put("key_id", pk.getString("key_id")).toString())
    }

    suspend fun releases(full: String) = JSONArray(ok("/repos/$full/releases?per_page=100")).list()

    /** The part of the job log that explains the failure: the lines leading up to the last ##[error], without ANSI colours or timestamps. */
    suspend fun log(full: String, job: Long): String {
        val (c, b) = call("/repos/$full/actions/jobs/$job/logs")
        if (c != 200) throw ApiError("GitHub $c")
        val ansi = Regex("\u001B\\[[0-9;]*[A-Za-z]")
        val l = b.lines().map { it.replace(Regex("^\\S+Z "), "").replace(ansi, "").trimEnd() }
            .filterNot { it.startsWith("##[group]") || it.startsWith("##[endgroup]") }
        val last = l.indexOfLast { it.startsWith("##[error]") }
        val from = if (last >= 0) maxOf(0, last - 60) else maxOf(0, l.size - 80)
        return l.drop(from).filter { it.isNotBlank() }.joinToString("\n") { it.removePrefix("##[error]").let { x -> if (it.startsWith("##[error]")) "ERROR: $x" else x } }
    }

    suspend fun deleteRelease(full: String, id: Long, tag: String) {
        ok("/repos/$full/releases/$id", "DELETE")
        call("/repos/$full/git/refs/tags/$tag", "DELETE")
    }

    suspend fun download(full: String, asset: Long, out: OutputStream) = withContext(Dispatchers.IO) {
        val r = Request.Builder().url("https://api.github.com/repos/$full/releases/assets/$asset")
            .header("Authorization", "Bearer $token").header("Accept", "application/octet-stream").build()
        http.newCall(r).execute().use {
            if (!it.isSuccessful) throw ApiError("GitHub ${it.code}")
            it.body!!.byteStream().copyTo(out)
        }
    }
}
