package app.cloudforge

import android.util.Base64
import com.goterl.lazysodium.LazySodiumAndroid
import com.goterl.lazysodium.SodiumAndroid
import com.goterl.lazysodium.interfaces.Box
import org.bouncycastle.asn1.x500.X500Name
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder
import java.io.ByteArrayOutputStream
import java.math.BigInteger
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.SecureRandom
import java.util.Date

object Signing {
    const val ALIAS = "cloudforge"

    /** Creates a PKCS12 keystore (RSA 2048, ~27 years) protected by [pw]. */
    fun generate(pw: String): ByteArray {
        val kp = KeyPairGenerator.getInstance("RSA").apply { initialize(2048) }.generateKeyPair()
        val name = X500Name("CN=CloudForge, O=CloudForge")
        val now = Date()
        val holder = JcaX509v3CertificateBuilder(name, BigInteger(64, SecureRandom()), now, Date(now.time + 10000L * 86400000L), name, kp.public)
            .build(JcaContentSignerBuilder("SHA256withRSA").build(kp.private))
        val cert = JcaX509CertificateConverter().getCertificate(holder)
        val ks = KeyStore.getInstance("PKCS12").apply {
            load(null, null)
            setKeyEntry(ALIAS, kp.private, pw.toCharArray(), arrayOf(cert))
        }
        return ByteArrayOutputStream().also { ks.store(it, pw.toCharArray()) }.toByteArray()
    }

    fun password(): String {
        val chars = ('a'..'z') + ('A'..'Z') + ('0'..'9'); val r = SecureRandom()
        return (1..24).map { chars[r.nextInt(chars.size)] }.joinToString("")
    }

    /** GitHub requires secrets encrypted with libsodium crypto_box_seal using the repo public key. */
    fun seal(value: ByteArray, publicKeyB64: String): String {
        val ls = LazySodiumAndroid(SodiumAndroid())
        val pk = Base64.decode(publicKeyB64, Base64.DEFAULT)
        val out = ByteArray(Box.SEALBYTES + value.size)
        check(ls.cryptoBoxSeal(out, value, value.size.toLong(), pk)) { "تعذر تشفير السر" }
        return Base64.encodeToString(out, Base64.NO_WRAP)
    }
}
