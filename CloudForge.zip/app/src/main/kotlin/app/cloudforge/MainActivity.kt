package app.cloudforge

import android.app.Application
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.util.Base64
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.coroutines.*
import org.json.JSONObject
import java.time.Duration
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import java.util.zip.ZipInputStream

/* ───────────── helpers ───────────── */
fun clean(s: String) = s.replace(Regex("[^A-Za-z0-9._-]+"), "-").trim('-', '.').ifBlank { "app" }.take(60)
fun sz(b: Long) = if (b > 1048576) "%.1f MB".format(b / 1048576.0) else "${maxOf(1, b / 1024)} KB"
fun fmt(a: String?) = if (a.isNullOrEmpty()) "—" else
    DateTimeFormatter.ofLocalizedDateTime(FormatStyle.MEDIUM).withZone(ZoneId.systemDefault()).format(Instant.parse(a))
fun dur(a: String?, b: String?): String {
    if (a.isNullOrEmpty()) return "—"
    val s = Duration.between(Instant.parse(a), if (b.isNullOrEmpty()) Instant.now() else Instant.parse(b)).seconds.coerceAtLeast(0)
    return if (s >= 60) "${s / 60}د ${s % 60}ث" else "${s}ث"
}
fun rootOk(c: Context, u: Uri): Boolean = try {
    val ok = Regex("^(pubspec\\.yaml|package\\.json|build\\.gradle(\\.kts)?|settings\\.gradle(\\.kts)?|gradlew)$")
    ZipInputStream(c.contentResolver.openInputStream(u)).use { z ->
        var e = z.nextEntry; var f = false; var n = 0
        while (e != null && n < 5000) { if (ok.matches(e.name)) f = true; z.closeEntry(); e = z.nextEntry; n++ }
        f
    }
} catch (e: Exception) { false }

/* ───────────── state ───────────── */
class VM(private val app: Application) : AndroidViewModel(app) {
    private val prefs = EncryptedSharedPreferences.create(app, "cf",
        MasterKey.Builder(app).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)
    var token by mutableStateOf(prefs.getString("t", null))
    var cid by mutableStateOf(prefs.getString("cid", null) ?: BuildConfig.CLIENT_ID)
    var user by mutableStateOf(prefs.getString("u", "") ?: "")
    var repo by mutableStateOf(prefs.getString("r", null))
    private var branch = prefs.getString("b", "main") ?: "main"
    var tab by mutableStateOf(0)
    var busy by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)
    var toast by mutableStateOf<String?>(null)
    var code by mutableStateOf<Pair<String, String>?>(null)
    var repos by mutableStateOf(listOf<JSONObject>())
    var projects by mutableStateOf<Gh.Projects?>(null)
    var runs by mutableStateOf(listOf<JSONObject>())
    var jobs by mutableStateOf(mapOf<Long, List<JSONObject>>())
    var logs by mutableStateOf(mapOf<Long, String>())
    var open by mutableStateOf<Long?>(null)
    var archive by mutableStateOf(listOf<Pair<JSONObject, List<JSONObject>>>())
    var signed by mutableStateOf(false)
    var keyInfo by mutableStateOf<String?>(null)
    private var loginJob: Job? = null
    private val gh get() = Gh(token!!)

    private fun go(b: suspend () -> Unit) = viewModelScope.launch {
        busy = true
        try { b() } catch (e: CancellationException) { throw e } catch (e: Exception) { error = e.message ?: e.toString() } finally { busy = false }
    }

    fun login() {
        if (cid.isBlank()) { error = "أدخل GitHub Client ID"; return }
        prefs.edit().putString("cid", cid.trim()).apply()
        loginJob = viewModelScope.launch {
            try {
                val d = Auth.start(cid.trim())
                code = d.getString("user_code") to d.getString("verification_uri")
                val t = Auth.poll(cid.trim(), d.getString("device_code"), d.optInt("interval", 5))
                val u = Gh(t).user().getString("login")
                prefs.edit().putString("t", t).putString("u", u).apply()
                user = u; token = t; code = null; tab = 0
            } catch (e: CancellationException) { throw e } catch (e: Exception) { error = e.message; code = null }
        }
    }
    fun cancelLogin() { loginJob?.cancel(); code = null }
    fun logout() { prefs.edit().remove("t").apply(); token = null; runs = emptyList(); archive = emptyList(); projects = null }

    fun loadRepos() = go { repos = gh.repos() }
    private suspend fun doPick(full: String) {
        val i = gh.repoInfo(full)
        if (i.optJSONObject("permissions")?.optBoolean("push") != true) throw ApiError("لا تملك صلاحية الكتابة على هذا المستودع")
        val b = i.getString("default_branch")
        gh.installWorkflow(full, b, app.assets.open("build.yml").readBytes())
        repo = full; branch = b; signed = false; projects = null; runs = emptyList(); open = null; tab = 0
        prefs.edit().putString("r", full).putString("b", b).apply()
        toast = "تم اعتماد $full وتثبيت سكربت البناء"
    }
    fun pick(full: String) = go { doPick(full) }
    fun create(name: String, priv: Boolean) = go {
        val r = gh.createRepo(clean(name), priv); delay(1500); doPick(r.getString("full_name"))
    }

    fun checkSigning() = go { ensureSigning(repo!!) }
    /** Persistent signing key lives in repo Secrets: created once, reused for every build. Never overwritten if already set. */
    private suspend fun ensureSigning(full: String) {
        val names = listOf("ANDROID_KEYSTORE_BASE64", "ANDROID_KEYSTORE_PASSWORD", "ANDROID_KEY_ALIAS")
        if (names.all { gh.hasSecret(full, it) }) { signed = true; return }
        var b64 = prefs.getString("ks", null); var pw = prefs.getString("kp", null)
        if (b64 == null || pw == null) {   // first time on this device: generate once, reuse for all repos
            pw = Signing.password()
            val bytes = withContext(Dispatchers.Default) { Signing.generate(pw) }
            b64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
            prefs.edit().putString("ks", b64).putString("kp", pw).apply()
            saveBackup(bytes)
            keyInfo = "كلمة المرور: $pw\nالاسم المستعار: ${Signing.ALIAS}\nنسخة احتياطية في التنزيلات: CloudForge-signing-key.p12"
        }
        gh.setSecret(full, names[0], b64!!); gh.setSecret(full, names[1], pw!!); gh.setSecret(full, names[2], Signing.ALIAS)
        signed = true; toast = "تم حفظ مفتاح التوقيع الثابت في GitHub Secrets"
    }
    private fun saveBackup(bytes: ByteArray) {
        try {
            val cv = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, "CloudForge-signing-key.p12")
                put(MediaStore.Downloads.MIME_TYPE, "application/x-pkcs12")
            }
            val u = app.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)
            if (u != null) app.contentResolver.openOutputStream(u)?.use { it.write(bytes) }
        } catch (e: Exception) { }
    }

    fun loadProjects() = go { projects = gh.projects(repo!!, branch) }
    fun upload(uri: Uri, name: String, folder: String) = go {
        ensureSigning(repo!!)
        val bytes = withContext(Dispatchers.IO) { app.contentResolver.openInputStream(uri)!!.use { it.readBytes() } }
        val p = gh.upload(repo!!, branch, folder, name, bytes)
        toast = "تم الرفع: $p"
        projects = gh.projects(repo!!, branch); tab = 1
    }

    suspend fun refreshRuns() {
        try {
            runs = gh.runs(repo!!, 20)
            val o = open ?: runs.firstOrNull()?.getLong("id")
            if (o != null) { open = o; jobs = jobs + (o to gh.jobs(repo!!, o)) }
        } catch (e: CancellationException) { throw e } catch (e: Exception) { }
    }
    fun toggle(id: Long) {
        open = if (open == id) null else id
        if (open != null) viewModelScope.launch {
            try { jobs = jobs + (id to gh.jobs(repo!!, id)) } catch (e: CancellationException) { throw e } catch (e: Exception) { }
        }
    }
    fun showLog(job: Long) = go { logs = logs + (job to gh.log(repo!!, job)) }
    fun cancelRun(id: Long) = go { gh.cancel(repo!!, id); refreshRuns() }

    private suspend fun fetchArchive() {
        val rs = gh.runs(repo!!, 30); val rel = gh.releases(repo!!)
        archive = rs.map { r -> r to rel.filter { it.getString("tag_name").startsWith("cf-${r.getLong("id")}-") } }
            .filter { it.second.isNotEmpty() || it.first.s("conclusion") == "failure" }
    }
    fun loadArchive() = go { fetchArchive() }
    fun delete(rel: JSONObject) = go { gh.deleteRelease(repo!!, rel.getLong("id"), rel.getString("tag_name")); fetchArchive() }
    fun download(rel: JSONObject) = go {
        val a = rel.getJSONArray("assets").getJSONObject(0); val name = rel.getString("name") + ".apk"
        val cv = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, name)
            put(MediaStore.Downloads.MIME_TYPE, "application/vnd.android.package-archive")
        }
        val uri = app.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)!!
        app.contentResolver.openOutputStream(uri)!!.use { gh.download(repo!!, a.getLong("id"), it) }
        toast = "تم الحفظ في التنزيلات: $name"
        app.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION))
    }
}

/* ───────────── UI ───────────── */
class MainActivity : ComponentActivity() {
    override fun onCreate(s: Bundle?) {
        installSplashScreen()
        super.onCreate(s)
        setContent {
            MaterialTheme(colorScheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) { App() }
            }
        }
    }
}

@Composable fun Card2(content: @Composable ColumnScope.() -> Unit) =
    Card(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp)) { Column(Modifier.padding(14.dp), content = content) }

@Composable fun StatusChip(st: String, c: String) {
    val (t, col) = when {
        st != "completed" -> (if (st == "queued") "بالانتظار" else "⏳ جارٍ") to Color(0xFFD97706)
        c == "success" -> "نجح" to Color(0xFF16A34A)
        c == "cancelled" -> "أُلغي" to Color.Gray
        c == "skipped" -> "تخطي" to Color.Gray
        else -> "فشل" to Color(0xFFDC2626)
    }
    Surface(color = col, shape = RoundedCornerShape(50)) { Text(t, color = Color.White, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 10.dp, vertical = 2.dp)) }
}

@Composable fun App(vm: VM = viewModel()) {
    val snack = remember { SnackbarHostState() }
    LaunchedEffect(vm.error) { vm.error?.let { snack.showSnackbar(it); vm.error = null } }
    LaunchedEffect(vm.token, vm.repo) { if (vm.token != null && vm.repo != null) vm.checkSigning() }
    LaunchedEffect(vm.toast) { vm.toast?.let { snack.showSnackbar(it); vm.toast = null } }
    vm.keyInfo?.let { k -> AlertDialog(onDismissRequest = {}, title = { Text("🔑 احفظ مفتاح التوقيع") },
        text = { Text("$k\n\nالمفتاح محفوظ في GitHub Secrets ولا يمكن قراءته منها لاحقاً. إن فقدته لن تُحدَّث تطبيقاتك المثبتة، فاحتفظ بالنسخة الاحتياطية.") },
        confirmButton = { TextButton(onClick = { vm.keyInfo = null }) { Text("فهمت") } }) }
    Scaffold(snackbarHost = { SnackbarHost(snack) }, bottomBar = {
        if (vm.token != null && vm.repo != null) NavigationBar {
            listOf("📦" to "المشروع", "⚙️" to "البناء", "🗂" to "الأرشيف", "🔗" to "المستودع").forEachIndexed { i, (e, l) ->
                NavigationBarItem(selected = vm.tab == i, onClick = { vm.tab = i }, icon = { Text(e) }, label = { Text(l, fontSize = 11.sp) })
            }
        }
    }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            if (vm.busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            when {
                vm.token == null -> Login(vm)
                vm.repo == null || vm.tab == 3 -> RepoScreen(vm)
                vm.tab == 0 -> ProjectScreen(vm)
                vm.tab == 1 -> BuildScreen(vm)
                else -> ArchiveScreen(vm)
            }
        }
    }
}

@Composable fun Login(vm: VM) {
    val clip = LocalClipboardManager.current; val ctx = LocalContext.current
    Column(Modifier.fillMaxSize().padding(24.dp).verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text("☁️ CloudForge", fontSize = 32.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("ارفع مشروعك كملف ZIP، انتظر قليلاً، واستلم APK جاهزاً.\nالبناء يتم على GitHub Actions في مستودعك.", textAlign = TextAlign.Center)
        Spacer(Modifier.height(24.dp))
        val c = vm.code
        if (c == null) {
            if (BuildConfig.CLIENT_ID.isBlank()) OutlinedTextField(vm.cid, { vm.cid = it }, label = { Text("GitHub OAuth Client ID") },
                singleLine = true, modifier = Modifier.fillMaxWidth())
            Button(onClick = { vm.login() }, modifier = Modifier.fillMaxWidth()) { Text("تسجيل الدخول عبر GitHub") }
            Text("بدون توكنات سرية: تدخل رمزاً قصيراً في GitHub وتوافق على الصلاحيات.", fontSize = 12.sp, textAlign = TextAlign.Center)
        } else {
            Text("أدخل هذا الرمز في GitHub:")
            Text(c.first, fontSize = 36.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
            Button(onClick = { clip.setText(AnnotatedString(c.first)); ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(c.second))) }) { Text("نسخ الرمز وفتح GitHub") }
            CircularProgressIndicator(Modifier.padding(12.dp))
            Text("بانتظار موافقتك…", fontSize = 12.sp)
            TextButton(onClick = { vm.cancelLogin() }) { Text("إلغاء") }
        }
    }
}

@Composable fun RepoScreen(vm: VM) {
    var q by remember { mutableStateOf("") }; var nn by remember { mutableStateOf("") }; var priv by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) { vm.loadRepos() }
    LazyColumn {
        item { Card2 {
            Text("مستودع البناء", fontWeight = FontWeight.Bold)
            Text(if (vm.repo != null) "الحالي: ${vm.repo} — يمكنك تغييره في أي وقت." else "اختر مستودعاً أو أنشئ جديداً. سيُرفع سكربت البناء تلقائياً.", fontSize = 13.sp)
            Text(if (vm.signed) "🔑 مفتاح التوقيع الثابت: مثبت في Secrets" else "🔑 مفتاح التوقيع: قيد الفحص…", fontSize = 12.sp)
            OutlinedTextField(q, { q = it }, placeholder = { Text("بحث في مستودعاتك…") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        } }
        items(vm.repos.filter { it.getString("full_name").contains(q, true) }.take(40)) { r ->
            val f = r.getString("full_name")
            Card2 { Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                Text((if (r.optBoolean("private")) "🔒 " else "🌐 ") + f, modifier = Modifier.weight(1f), fontSize = 14.sp)
                Button(onClick = { vm.pick(f) }, enabled = f != vm.repo && !vm.busy) { Text(if (f == vm.repo) "الحالي" else "اختيار") }
            } }
        }
        item { Card2 {
            Text("إنشاء مستودع جديد", fontWeight = FontWeight.Bold)
            OutlinedTextField(nn, { nn = it }, placeholder = { Text("cloudforge-builds") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(priv, { priv = it }); Text("خاص (موصى به)") }
            Button(onClick = { vm.create(nn, priv) }, enabled = nn.isNotBlank() && !vm.busy, modifier = Modifier.fillMaxWidth()) { Text("إنشاء واعتماد") }
        } }
        item { TextButton(onClick = { vm.logout() }, modifier = Modifier.padding(8.dp)) { Text("تسجيل الخروج (${vm.user}) · v${BuildConfig.VERSION_NAME}") } }
    }
}

@Composable fun ProjectScreen(vm: VM) {
    val ctx = LocalContext.current
    var uri by remember { mutableStateOf<Uri?>(null) }; var name by remember { mutableStateOf("") }; var size by remember { mutableStateOf(0L) }
    var folder by remember { mutableStateOf("") }; var isNew by remember { mutableStateOf(false) }; var warn by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { vm.loadProjects() }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) {
            ctx.contentResolver.query(u, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) { name = c.getString(c.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)); size = c.getLong(c.getColumnIndexOrThrow(OpenableColumns.SIZE)) }
            }
            if (size > 50_000_000) vm.error = "الحد الأقصى 50MB" else { uri = u; warn = !rootOk(ctx, u) }
        }
    }
    val folders = vm.projects?.folders.orEmpty(); val creating = isNew || folders.isEmpty()
    val base = clean(name.removeSuffix(".zip")); val fol = clean(folder)
    LazyColumn {
        item { Card2 {
            Text("رفع مشروع", fontWeight = FontWeight.Bold)
            Text("التطبيق (مجلد داخل projects/)", fontSize = 12.sp)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                folders.forEach { f -> FilterChip(selected = !creating && folder == f, onClick = { isNew = false; folder = f }, label = { Text(f) }) }
                FilterChip(selected = creating, onClick = { isNew = true; folder = "" }, label = { Text("＋ تطبيق جديد") })
            }
            if (creating) OutlinedTextField(folder, { folder = it }, label = { Text("اسم مجلد التطبيق الجديد") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            Box(Modifier.fillMaxWidth().border(2.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(14.dp))
                .clickable { picker.launch(arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream")) }.padding(28.dp),
                contentAlignment = Alignment.Center) {
                Text("📁 اضغط لاختيار ملف ZIP\nملفات المشروع في جذر الـZIP مباشرة", textAlign = TextAlign.Center, fontSize = 13.sp)
            }
            if (uri != null) {
                Spacer(Modifier.height(8.dp))
                Text("📄 $name · ${sz(size)}", fontWeight = FontWeight.Bold)
                Text("المسار: projects/${fol.takeIf { folder.isNotBlank() } ?: "?"}/$base.zip", fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                Text("التاريخ: ${fmt(Instant.now().toString())}", fontSize = 12.sp)
                if (warn) Text("⚠️ لم أجد ملفات المشروع في جذر الـZIP. تأكد أنها ليست داخل مجلد فرعي.", color = Color(0xFFD97706), fontSize = 12.sp)
            }
            Button(onClick = { vm.upload(uri!!, base, fol); uri = null }, enabled = uri != null && folder.isNotBlank() && !vm.busy,
                modifier = Modifier.fillMaxWidth()) { Text("رفع وبدء البناء") }
        } }
        item { Card2 { Text("سجل الرفع", fontWeight = FontWeight.Bold)
            val h = vm.projects?.history.orEmpty()
            if (h.isEmpty()) Text("لا توجد رفعات بعد", fontSize = 13.sp)
            h.forEach { (p, d) -> Text(p, fontFamily = FontFamily.Monospace, fontSize = 12.sp); Text(fmt(d), fontSize = 11.sp); Spacer(Modifier.height(6.dp)) }
        } }
        item { Card2 { Text("الملفات الحالية", fontWeight = FontWeight.Bold)
            vm.projects?.items.orEmpty().forEach { (p, s) -> Text("$p · ${sz(s)}", fontFamily = FontFamily.Monospace, fontSize = 12.sp) }
        } }
    }
}

@Composable fun BuildScreen(vm: VM) {
    LaunchedEffect(Unit) { while (true) { vm.refreshRuns(); delay(6000) } }
    LazyColumn {
        if (vm.runs.isEmpty()) item { Card2 { Text("لا توجد عمليات بناء بعد. ارفع مشروعاً أولاً.") } }
        items(vm.runs, key = { it.getLong("id") }) { r ->
            val id = r.getLong("id"); val done = r.s("status") == "completed"
            Card2 {
                Row(Modifier.fillMaxWidth().clickable { vm.toggle(id) }, Arrangement.SpaceBetween, Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("#${r.getInt("run_number")}", fontWeight = FontWeight.Bold)
                        Text(r.optJSONObject("head_commit")?.s("message")?.removePrefix("CloudForge: upload ")?.lines()?.first() ?: "", fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                    }
                    StatusChip(r.s("status"), r.s("conclusion"))
                }
                Text("بدأ: ${fmt(r.s("run_started_at"))} · المدة: ${dur(r.s("run_started_at"), if (done) r.s("updated_at") else null)}", fontSize = 12.sp)
                if (vm.open == id) vm.jobs[id].orEmpty().filter { it.s("name") != "Detect new zips" }.forEach { j ->
                    val jid = j.getLong("id")
                    HorizontalDivider(Modifier.padding(vertical = 6.dp))
                    Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                        Text(j.s("name"), fontSize = 12.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                        StatusChip(j.s("status"), j.s("conclusion"))
                    }
                    Text("المدة: ${dur(j.s("started_at"), j.s("completed_at"))}", fontSize = 11.sp)
                    j.getJSONArray("steps").list().forEach { st ->
                        Text("• ${st.s("name")} — ${dur(st.s("started_at"), st.s("completed_at"))} ${if (st.s("conclusion") == "failure") "❌" else if (st.s("conclusion") == "success") "✅" else ""}", fontSize = 11.sp)
                    }
                    if (j.s("conclusion") == "failure") {
                        TextButton(onClick = { vm.showLog(jid) }) { Text("عرض الأخطاء") }
                        vm.logs[jid]?.let { Text(it, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.heightIn(max = 240.dp).verticalScroll(rememberScrollState())) }
                    }
                }
                if (!done) TextButton(onClick = { vm.cancelRun(id) }) { Text("إلغاء البناء", color = Color(0xFFDC2626)) }
            }
        }
    }
}

@Composable fun ArchiveScreen(vm: VM) {
    var del by remember { mutableStateOf<JSONObject?>(null) }
    LaunchedEffect(Unit) { vm.loadArchive() }
    LazyColumn {
        if (vm.archive.isEmpty()) item { Card2 { Text("الأرشيف فارغ") } }
        vm.archive.forEach { (run, rels) ->
            if (rels.isEmpty()) item { Card2 {
                Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) { Text("v${run.getInt("run_number")} · بدون APK", fontWeight = FontWeight.Bold); StatusChip(run.s("status"), run.s("conclusion")) }
                Text(fmt(run.s("run_started_at")), fontSize = 12.sp)
            } }
            rels.forEach { rel -> item { Card2 {
                val size = rel.getJSONArray("assets").optJSONObject(0)?.getLong("size")
                Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                    Column(Modifier.weight(1f)) { Text("v${run.getInt("run_number")} · ${rel.s("name")}", fontWeight = FontWeight.Bold)
                        Text("${fmt(run.s("run_started_at"))} · ${size?.let { sz(it) } ?: "—"}", fontSize = 12.sp) }
                    StatusChip(run.s("status"), run.s("conclusion"))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { vm.download(rel) }, enabled = size != null && !vm.busy) { Text("⬇ تحميل وتثبيت") }
                    OutlinedButton(onClick = { del = rel }) { Text("🗑 حذف") }
                }
            } } }
        }
    }
    del?.let { d -> AlertDialog(onDismissRequest = { del = null }, title = { Text("حذف الإصدار؟") },
        text = { Text("سيُحذف ملف APK نهائياً لتوفير المساحة.") },
        confirmButton = { TextButton(onClick = { vm.delete(d); del = null }) { Text("حذف") } },
        dismissButton = { TextButton(onClick = { del = null }) { Text("إلغاء") } }) }
}
