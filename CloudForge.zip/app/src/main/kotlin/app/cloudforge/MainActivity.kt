package app.cloudforge

import android.app.Application
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.util.Base64
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.browser.customtabs.CustomTabsIntent
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.*
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.coroutines.*
import org.json.JSONObject
import java.time.Duration
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import java.util.zip.ZipInputStream

/* ───────────── helpers ───────────── */
fun clean(s: String) = s.replace(Regex("[^A-Za-z0-9._-]+"), "-").trim('-', '.').ifBlank { "app" }.take(60)
fun sz(b: Long) = if (b > 1048576) "%.1f MB".format(b / 1048576.0) else "${maxOf(1, b / 1024)} KB"
fun fmt(a: String?) = if (a.isNullOrEmpty()) "—" else
    DateTimeFormatter.ofLocalizedDateTime(FormatStyle.MEDIUM).withZone(ZoneId.systemDefault()).format(Instant.parse(a))
fun dur(a: String?, b: String?): String {
    if (a.isNullOrEmpty()) return "—"
    val s = Duration.between(Instant.parse(a), if (b.isNullOrEmpty()) Instant.now() else Instant.parse(b)).seconds.coerceAtLeast(0)
    return if (s >= 60) "${s / 60}د ${s % 60}ث" else "${s}ث"
}
fun rootOk(c: Context, u: Uri): Boolean = try {
    val ok = Regex("^(pubspec\\.yaml|package\\.json|build\\.gradle(\\.kts)?|settings\\.gradle(\\.kts)?|gradlew)$")
    ZipInputStream(c.contentResolver.openInputStream(u)).use { z ->
        var e = z.nextEntry; var f = false; var n = 0
        while (e != null && n < 5000) { if (ok.matches(e.name)) f = true; z.closeEntry(); e = z.nextEntry; n++ }
        f
    }
} catch (e: Exception) { false }

/* ───────────── state ───────────── */
class VM(private val app: Application) : AndroidViewModel(app) {
    private val prefs = EncryptedSharedPreferences.create(app, "cf",
        MasterKey.Builder(app).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)
    var token by mutableStateOf(prefs.getString("t", null))
    var connecting by mutableStateOf(false)
    var user by mutableStateOf(prefs.getString("u", "") ?: "")
    var repo by mutableStateOf(prefs.getString("r", null))
    private var branch = prefs.getString("b", "main") ?: "main"
    var screen by mutableStateOf("home")          // home | repos | upload | builds | archive
    var uploadTarget by mutableStateOf<String?>(null) // project folder preselected for "update"
    var releases by mutableStateOf(listOf<JSONObject>())
    var busy by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)
    var toast by mutableStateOf<String?>(null)
    var code by mutableStateOf<Pair<String, String>?>(null)
    var repos by mutableStateOf(listOf<JSONObject>())
    var projects by mutableStateOf<Gh.Projects?>(null)
    var runs by mutableStateOf(listOf<JSONObject>())
    var jobs by mutableStateOf(mapOf<Long, List<JSONObject>>())
    var logs by mutableStateOf(mapOf<Long, String>())
    var open by mutableStateOf<Long?>(null)
    var archive by mutableStateOf(listOf<Pair<JSONObject, List<JSONObject>>>())
    var signed by mutableStateOf(false)
    var keyInfo by mutableStateOf<String?>(null)
    private var loginJob: Job? = null
    private val gh get() = Gh(token!!)

    private fun go(b: suspend () -> Unit) = viewModelScope.launch {
        busy = true
        try { b() } catch (e: CancellationException) { throw e } catch (e: Exception) { error = e.message ?: e.toString() } finally { busy = false }
    }

    /** One tap: ask GitHub for a device code, show GitHub's own authorize page inside the app, poll until approved. */
    fun login() {
        val id = BuildConfig.CLIENT_ID
        if (id.isBlank()) { error = "التطبيق غير مهيأ: لم يُضمَّن GitHub Client ID وقت البناء (CF_CLIENT_ID)"; return }
        if (connecting || code != null) return
        loginJob = viewModelScope.launch {
            connecting = true
            try {
                val d = Auth.start(id)
                code = d.getString("user_code") to d.getString("verification_uri")
                connecting = false
                val t = Auth.poll(id, d.getString("device_code"), d.optInt("interval", 5))
                val u = Gh(t).user().getString("login")
                prefs.edit().putString("t", t).putString("u", u).apply()
                user = u; token = t; code = null; screen = if (repo == null) "repos" else "home"
                try { app.startActivity(Intent(app, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP)) } catch (e: Exception) { }
            } catch (e: CancellationException) { throw e } catch (e: Exception) { error = e.message; code = null }
            finally { connecting = false }
        }
    }
    fun cancelLogin() { loginJob?.cancel(); code = null; connecting = false }
    fun logout() { prefs.edit().remove("t").apply(); token = null; runs = emptyList(); releases = emptyList(); archive = emptyList(); projects = null; screen = "home" }

    fun loadRepos() = go { repos = gh.repos() }
    private suspend fun doPick(full: String) {
        val i = gh.repoInfo(full)
        if (i.optJSONObject("permissions")?.optBoolean("push") != true) throw ApiError("لا تملك صلاحية الكتابة على هذا المستودع")
        val b = i.getString("default_branch")
        gh.ensureWorkflow(full, b, app.assets.open("build.yml").readBytes())
        repo = full; branch = b; signed = false; projects = null; runs = emptyList(); releases = emptyList(); open = null; uploadTarget = null; screen = "upload"
        prefs.edit().putString("r", full).putString("b", b).apply()
        toast = "تم اعتماد $full وتثبيت سكربت البناء"
    }
    fun pick(full: String) = go { doPick(full) }
    fun create(name: String, priv: Boolean) = go {
        val r = gh.createRepo(clean(name), priv); delay(1500); doPick(r.getString("full_name"))
    }

    fun checkSigning() = go { ensureSigning(repo!!) }
    /** Persistent signing key lives in repo Secrets: created once, reused for every build. Never overwritten if already set. */
    private suspend fun ensureSigning(full: String) {
        val names = listOf("ANDROID_KEYSTORE_BASE64", "ANDROID_KEYSTORE_PASSWORD", "ANDROID_KEY_ALIAS")
        if (names.all { gh.hasSecret(full, it) }) { signed = true; return }
        var b64 = prefs.getString("ks", null); var pw = prefs.getString("kp", null)
        if (b64 == null || pw == null) {   // first time on this device: generate once, reuse for all repos
            pw = Signing.password()
            val bytes = withContext(Dispatchers.Default) { Signing.generate(pw) }
            b64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
            prefs.edit().putString("ks", b64).putString("kp", pw).apply()
            saveBackup(bytes)
            keyInfo = "كلمة المرور: $pw\nالاسم المستعار: ${Signing.ALIAS}\nنسخة احتياطية في التنزيلات: CloudForge-signing-key.p12"
        }
        gh.setSecret(full, names[0], b64!!); gh.setSecret(full, names[1], pw!!); gh.setSecret(full, names[2], Signing.ALIAS)
        signed = true; toast = "تم حفظ مفتاح التوقيع الثابت في GitHub Secrets"
    }
    private fun saveBackup(bytes: ByteArray) {
        try {
            val cv = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, "CloudForge-signing-key.p12")
                put(MediaStore.Downloads.MIME_TYPE, "application/x-pkcs12")
            }
            val u = app.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)
            if (u != null) app.contentResolver.openOutputStream(u)?.use { it.write(bytes) }
        } catch (e: Exception) { }
    }

    fun rebuild(zip: String) = go {
        ensureSigning(repo!!)
        gh.ensureWorkflow(repo!!, branch, app.assets.open("build.yml").readBytes()); delay(2500)
        gh.dispatch(repo!!, branch, zip)
        toast = "بدأت إعادة البناء"; delay(1500); screen = "builds"
    }
    fun loadProjects() = go { projects = gh.projects(repo!!, branch) }
    private suspend fun refreshHome() { projects = gh.projects(repo!!, branch); runs = gh.runs(repo!!, 20); releases = gh.releases(repo!!) }
    fun loadHome() = go { refreshHome() }
    /** Silent refresh used while a build is running. */
    suspend fun pollHome() { try { runs = gh.runs(repo!!, 20); releases = gh.releases(repo!!) } catch (e: CancellationException) { throw e } catch (e: Exception) { } }
    /** Uploads projects/<folder>/<name>.zip (new project, or replaces the existing zip of that project). */
    fun upload(uri: Uri, name: String, folder: String) = go {
        ensureSigning(repo!!)
        gh.ensureWorkflow(repo!!, branch, app.assets.open("build.yml").readBytes())
        val bytes = withContext(Dispatchers.IO) { app.contentResolver.openInputStream(uri)!!.use { it.readBytes() } }
        val p = gh.upload(repo!!, branch, folder, name, bytes)
        toast = "تم الرفع: $p"
        projects = gh.projects(repo!!, branch); uploadTarget = null; screen = "builds"
    }

    suspend fun refreshRuns() {
        try {
            runs = gh.runs(repo!!, 20)
            val o = open ?: runs.firstOrNull()?.getLong("id")
            if (o != null) { open = o; jobs = jobs + (o to gh.jobs(repo!!, o)) }
        } catch (e: CancellationException) { throw e } catch (e: Exception) { }
    }
    fun toggle(id: Long) {
        open = if (open == id) null else id
        if (open != null) viewModelScope.launch {
            try { jobs = jobs + (id to gh.jobs(repo!!, id)) } catch (e: CancellationException) { throw e } catch (e: Exception) { }
        }
    }
    fun showLog(job: Long) = go { logs = logs + (job to gh.log(repo!!, job)) }
    fun cancelRun(id: Long) = go { gh.cancel(repo!!, id); refreshRuns() }

    private suspend fun fetchArchive() {
        val rs = gh.runs(repo!!, 30); val rel = gh.releases(repo!!)
        archive = rs.map { r -> r to rel.filter { it.getString("tag_name").startsWith("cf-${r.getLong("id")}-") } }
            .filter { it.second.isNotEmpty() || it.first.s("conclusion") == "failure" }
    }
    fun loadArchive() = go { fetchArchive() }
    fun delete(rel: JSONObject) = go { gh.deleteRelease(repo!!, rel.getLong("id"), rel.getString("tag_name")); fetchArchive() }
    fun download(rel: JSONObject) = go {
        val a = rel.getJSONArray("assets").getJSONObject(0); val name = rel.getString("name") + ".apk"
        val cv = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, name)
            put(MediaStore.Downloads.MIME_TYPE, "application/vnd.android.package-archive")
        }
        val uri = app.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)!!
        app.contentResolver.openOutputStream(uri)!!.use { gh.download(repo!!, a.getLong("id"), it) }
        toast = "تم الحفظ في التنزيلات: $name"
        app.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION))
    }
}

/* ───────────── theme ───────────── */
object Cl {
    val bg = Color(0xFF0B0E14); val surface = Color(0xFF131720); val raised = Color(0xFF1A2030)
    val line = Color(0xFF262D3F); val text = Color(0xFFE8EBF4); val muted = Color(0xFF8E96AB)
    val accent = Color(0xFF8B92FF); val ok = Color(0xFF3DD68C); val warn = Color(0xFFF5B544); val bad = Color(0xFFF26D6D)
}
private val Scheme = darkColorScheme(
    primary = Cl.accent, onPrimary = Cl.bg, primaryContainer = Color(0xFF232A52), onPrimaryContainer = Cl.text,
    secondaryContainer = Color(0xFF232A52), onSecondaryContainer = Cl.text,
    background = Cl.bg, onBackground = Cl.text, surface = Cl.surface, onSurface = Cl.text,
    surfaceVariant = Cl.raised, onSurfaceVariant = Cl.muted, outline = Cl.line, outlineVariant = Cl.line,
    error = Cl.bad, surfaceContainer = Cl.surface, surfaceContainerHigh = Cl.raised, surfaceContainerHighest = Cl.raised,
)

/* ───────────── UI ───────────── */
class MainActivity : ComponentActivity() {
    override fun onCreate(s: Bundle?) {
        installSplashScreen()
        super.onCreate(s)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT))
        setContent {
            MaterialTheme(colorScheme = Scheme) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) { App() }
            }
        }
    }
}

@Composable fun Ico(v: ImageVector, tint: Color = LocalContentColor.current, size: Dp = 20.dp) =
    Icon(v, null, Modifier.size(size), tint)

@Composable fun Card2(content: @Composable ColumnScope.() -> Unit) =
    Card(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp), shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Cl.surface), border = BorderStroke(1.dp, Cl.line)) {
        Column(Modifier.padding(16.dp), content = content)
    }

@Composable fun Head(icon: ImageVector, text: String) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 10.dp)) {
        Box(Modifier.size(32.dp).clip(RoundedCornerShape(10.dp)).background(Cl.accent.copy(alpha = .14f)), contentAlignment = Alignment.Center) { Ico(icon, Cl.accent, 18.dp) }
        Spacer(Modifier.width(10.dp))
        Text(text, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
    }
}

@Composable fun Muted(t: String, size: Int = 12, mono: Boolean = false, color: Color = Cl.muted) =
    Text(t, color = color, fontSize = size.sp, fontFamily = if (mono) FontFamily.Monospace else FontFamily.Default)

@Composable fun Empty(icon: ImageVector, text: String) =
    Column(Modifier.fillMaxWidth().padding(vertical = 28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Ico(icon, Cl.muted, 34.dp); Spacer(Modifier.height(10.dp)); Muted(text, 13)
    }

@Composable fun StatusChip(st: String, c: String) {
    val (t, col, ic) = when {
        st != "completed" -> Triple(if (st == "queued") "بالانتظار" else "جارٍ", Cl.warn, Ic.Clock)
        c == "success" -> Triple("نجح", Cl.ok, Ic.CheckCircle)
        c == "cancelled" -> Triple("أُلغي", Cl.muted, Ic.Ban)
        c == "skipped" -> Triple("تخطي", Cl.muted, Ic.Ban)
        else -> Triple("فشل", Cl.bad, Ic.XCircle)
    }
    Row(Modifier.clip(RoundedCornerShape(50)).background(col.copy(alpha = .14f)).padding(horizontal = 10.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Ico(ic, col, 14.dp); Spacer(Modifier.width(5.dp)); Text(t, color = col, fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable fun BtnLabel(icon: ImageVector, text: String, tint: Color = LocalContentColor.current) {
    Ico(icon, tint, 18.dp); Spacer(Modifier.width(8.dp)); Text(text, color = tint)
}

@Composable fun TopBar(vm: VM, onMenu: () -> Unit) {
    Column(Modifier.fillMaxWidth().background(Cl.bg).statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().height(56.dp).padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onMenu) { Ico(Ic.Menu, Cl.text, 24.dp) }
            Spacer(Modifier.width(2.dp))
            Text("CloudForge", fontWeight = FontWeight.Bold, fontSize = 19.sp)
            Spacer(Modifier.weight(1f))
            vm.repo?.let { Muted(it.substringAfter('/'), 12, true) }
            Spacer(Modifier.width(12.dp))
        }
        HorizontalDivider(color = Cl.line)
    }
}

@Composable fun App(vm: VM = viewModel()) {
    val snack = remember { SnackbarHostState() }
    val drawer = rememberDrawerState(DrawerValue.Closed); val scope = rememberCoroutineScope()
    LaunchedEffect(vm.error) { vm.error?.let { snack.showSnackbar(it); vm.error = null } }
    LaunchedEffect(vm.token, vm.repo) { if (vm.token != null && vm.repo != null) vm.checkSigning() }
    LaunchedEffect(vm.toast) { vm.toast?.let { snack.showSnackbar(it); vm.toast = null } }
    vm.keyInfo?.let { k -> AlertDialog(onDismissRequest = {}, icon = { Ico(Ic.Key, Cl.accent, 28.dp) }, title = { Text("احفظ مفتاح التوقيع") },
        text = { Text("$k\n\nالمفتاح محفوظ في GitHub Secrets ولا يمكن قراءته منها لاحقاً. إن فقدته لن تُحدَّث تطبيقاتك المثبتة، فاحتفظ بالنسخة الاحتياطية.") },
        confirmButton = { TextButton(onClick = { vm.keyInfo = null }) { Text("فهمت") } }) }
    if (vm.token == null) { if (vm.code != null) AuthScreen(vm) else Scaffold(containerColor = Cl.bg, snackbarHost = { SnackbarHost(snack) }) { Box(Modifier.padding(it)) { Login(vm) } }; return }
    val scr = if (vm.repo == null) "repos" else vm.screen
    fun nav(x: String) { vm.screen = x; scope.launch { drawer.close() } }
    BackHandler(enabled = scr != "home" && vm.repo != null) { vm.screen = "home" }
    ModalNavigationDrawer(drawerState = drawer, drawerContent = {
        ModalDrawerSheet(drawerContainerColor = Cl.surface) {
            Column(Modifier.padding(20.dp)) {
                Box(Modifier.size(52.dp).clip(RoundedCornerShape(16.dp)).background(Brush.linearGradient(listOf(Color(0xFF6D74FF), Color(0xFF9B6BFF)))), contentAlignment = Alignment.Center) { Ico(Ic.Cloud, Color.White, 28.dp) }
                Spacer(Modifier.height(12.dp))
                Text("CloudForge", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                Muted(if (vm.user.isNotEmpty()) "@${vm.user}" else "", 13)
                vm.repo?.let { Muted(it, 11, true) }
            }
            HorizontalDivider(color = Cl.line, modifier = Modifier.padding(bottom = 8.dp))
            val dc = NavigationDrawerItemDefaults.colors(selectedContainerColor = Cl.accent.copy(alpha = .16f), unselectedContainerColor = Color.Transparent,
                selectedIconColor = Cl.accent, selectedTextColor = Cl.accent, unselectedIconColor = Cl.muted, unselectedTextColor = Cl.text)
            @Composable fun item(id: String, icon: ImageVector, label: String, sel: Boolean = scr == id, go: () -> Unit = { nav(id) }) =
                NavigationDrawerItem(label = { Text(label) }, selected = sel, onClick = go, icon = { Ico(icon, size = 22.dp) }, colors = dc, modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp))
            item("home", Ic.Folder, "المشاريع")
            item("repos", Ic.Plus, "إنشاء مشروع جديد")
            if (vm.repo != null) item("upload", Ic.CloudUpload, "رفع / تحديث مشروع")
            item("builds", Ic.Wrench, "عمليات البناء")
            item("archive", Ic.Archive, "الأرشيف")
            Spacer(Modifier.weight(1f))
            HorizontalDivider(color = Cl.line)
            item("", Ic.LogOut, "تسجيل الخروج", false) { scope.launch { drawer.close() }; vm.logout() }
            Muted("v${BuildConfig.VERSION_NAME}", 11); Spacer(Modifier.height(12.dp))
        }
    }) {
        Scaffold(containerColor = Cl.bg, snackbarHost = { SnackbarHost(snack) }, topBar = { TopBar(vm) { scope.launch { drawer.open() } } }) { pad ->
            Column(Modifier.padding(pad).fillMaxSize()) {
                if (vm.busy) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Cl.accent, trackColor = Cl.line)
                when (scr) {
                    "repos" -> RepoScreen(vm)
                    "upload" -> UploadScreen(vm)
                    "builds" -> BuildScreen(vm)
                    "archive" -> ArchiveScreen(vm)
                    else -> HomeScreen(vm)
                }
            }
        }
    }
}

@Composable fun Login(vm: VM) {
    Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF171C3A), Cl.bg))).padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Box(Modifier.size(88.dp).clip(RoundedCornerShape(28.dp))
            .background(Brush.linearGradient(listOf(Color(0xFF6D74FF), Color(0xFF9B6BFF)))), contentAlignment = Alignment.Center) {
            Ico(Ic.Cloud, Color.White, 46.dp)
        }
        Spacer(Modifier.height(22.dp))
        Text("CloudForge", fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("ارفع مشروعك كملف ZIP، انتظر قليلاً، واستلم APK جاهزاً.\nيتم البناء على GitHub Actions في مستودعك.",
            textAlign = TextAlign.Center, color = Cl.muted, fontSize = 14.sp, lineHeight = 22.sp)
        Spacer(Modifier.height(36.dp))
        Button(onClick = { vm.login() }, enabled = !vm.connecting, shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth().height(54.dp)) {
            if (vm.connecting) CircularProgressIndicator(Modifier.size(20.dp), color = Cl.bg, strokeWidth = 2.dp)
            else BtnLabel(Ic.Github, "الربط مع GitHub")
        }
        Spacer(Modifier.height(14.dp))
        Muted("ستفتح صفحة GitHub في متصفحك فوق التطبيق بحسابك المحفوظ، وافق وارجع.", 12)
    }
}

/** Opens GitHub in a Chrome Custom Tab (the user's real browser, with their saved GitHub session) above the app. */
@Composable fun AuthScreen(vm: VM) {
    val c = vm.code ?: return
    val code = c.first; val url = "${c.second}?user_code=$code"
    val ctx = LocalContext.current; val clip = LocalClipboardManager.current
    fun openTab() {
        try {
            CustomTabsIntent.Builder().setColorScheme(CustomTabsIntent.COLOR_SCHEME_DARK).setShowTitle(true).build().launchUrl(ctx, Uri.parse(url))
        } catch (e: Exception) { vm.error = "تعذر فتح المتصفح" }
    }
    BackHandler { vm.cancelLogin() }
    LaunchedEffect(code) { clip.setText(AnnotatedString(code)); openTab() }
    Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF171C3A), Cl.bg))).statusBarsPadding().padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        CircularProgressIndicator(color = Cl.accent, trackColor = Cl.line)
        Spacer(Modifier.height(24.dp))
        Text("بانتظار موافقتك في GitHub", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("وافق على الطلب في صفحة GitHub ثم ارجع، وسيُكمل التطبيق الربط تلقائياً.", color = Cl.muted, fontSize = 14.sp, textAlign = TextAlign.Center, lineHeight = 22.sp)
        Spacer(Modifier.height(22.dp))
        Row(Modifier.clip(RoundedCornerShape(14.dp)).background(Cl.raised).clickable { clip.setText(AnnotatedString(code)) }.padding(horizontal = 18.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Text(code, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 26.sp, letterSpacing = 4.sp)
            Spacer(Modifier.width(12.dp)); Ico(Ic.Copy, Cl.muted, 18.dp)
        }
        Spacer(Modifier.height(6.dp)); Muted("نُسخ الرمز تلقائياً، يلزمك فقط إن طلبته GitHub", 11)
        Spacer(Modifier.height(24.dp))
        Button(onClick = { openTab() }, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth().height(52.dp)) { BtnLabel(Ic.Github, "فتح GitHub") }
        TextButton(onClick = { vm.cancelLogin() }) { Text("إلغاء", color = Cl.muted) }
    }
}

@Composable fun RepoScreen(vm: VM) {
    var q by remember { mutableStateOf("") }; var nn by remember { mutableStateOf("") }; var priv by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { vm.loadRepos() }
    LazyColumn(contentPadding = PaddingValues(bottom = 16.dp)) {
        item { Card2 {
            Head(Ic.Plus, "إنشاء مستودع جديد")
            OutlinedTextField(nn, { nn = it }, placeholder = { Text("cloudforge-builds") }, singleLine = true, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth())
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clickable { priv = !priv }) {
                Checkbox(priv, { priv = it }); Text("مستودع خاص", fontSize = 14.sp); Spacer(Modifier.width(6.dp)); Muted("(موصى به، لكن له حدود في دقائق البناء)", 11)
            }
            Spacer(Modifier.height(6.dp))
            Button(onClick = { vm.create(nn, priv) }, enabled = nn.isNotBlank() && !vm.busy, shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth().height(48.dp)) { BtnLabel(Ic.Plus, "إنشاء واعتماد") }
        } }
        item { Row(Modifier.padding(horizontal = 18.dp, vertical = 10.dp)) { Muted("أو اختر أحد مستودعاتك", 13) } }
        item { OutlinedTextField(q, { q = it }, placeholder = { Text("بحث في مستودعاتك…") }, leadingIcon = { Ico(Ic.Search, Cl.muted) },
            singleLine = true, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 4.dp)) }
        items(vm.repos.filter { it.getString("full_name").contains(q, true) }.take(40)) { r ->
            val f = r.getString("full_name")
            Card2 { Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                Ico(if (r.optBoolean("private")) Ic.Lock else Ic.Globe, Cl.muted, 18.dp); Spacer(Modifier.width(10.dp))
                Text(f, modifier = Modifier.weight(1f), fontSize = 14.sp)
                if (f == vm.repo) { Muted("الحالي", 12, color = Cl.ok); Spacer(Modifier.width(8.dp)) }
                FilledTonalButton(onClick = { if (f == vm.repo) { vm.uploadTarget = null; vm.screen = "upload" } else vm.pick(f) }, enabled = !vm.busy, shape = RoundedCornerShape(12.dp)) {
                    Text(if (f == vm.repo) "متابعة" else "اختيار") }
            } }
        }
    }
}

/** Main screen: only the projects that exist in the chosen repository. */
@Composable fun HomeScreen(vm: VM) {
    LaunchedEffect(vm.repo) { vm.loadHome() }
    LaunchedEffect(vm.repo) { while (true) { delay(8000); if (vm.runs.any { it.s("status") != "completed" }) vm.pollHome() } }
    val folders = vm.projects?.folders.orEmpty()
    LazyColumn(contentPadding = PaddingValues(top = 6.dp, bottom = 16.dp)) {
        if (vm.projects != null && folders.isEmpty()) item { Card2 {
            Empty(Ic.Folder, "لا توجد مشاريع في هذا المستودع بعد")
            Button(onClick = { vm.uploadTarget = null; vm.screen = "upload" }, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth().height(48.dp)) { BtnLabel(Ic.Plus, "رفع أول مشروع") }
        } }
        items(folders) { f ->
            val zips = vm.projects?.items.orEmpty().filter { it.first.startsWith("projects/$f/") && it.first.endsWith(".zip") }
            val run = vm.runs.firstOrNull { it.optJSONObject("head_commit")?.s("message")?.contains("projects/$f/") == true }
            val rel = vm.releases.firstOrNull { it.s("body").contains("projects/$f/") && it.optJSONArray("assets")?.length() ?: 0 > 0 }
            val last = vm.projects?.history.orEmpty().firstOrNull { it.first.contains("projects/$f/") }?.second
            val asset = rel?.getJSONArray("assets")?.optJSONObject(0)
            Card2 {
                Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        Box(Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(Cl.accent.copy(alpha = .14f)), contentAlignment = Alignment.Center) { Ico(Ic.Folder, Cl.accent, 22.dp) }
                        Spacer(Modifier.width(12.dp))
                        Column { Text(f, fontWeight = FontWeight.Bold, fontSize = 16.sp); Muted(zips.firstOrNull()?.let { sz(it.second) } ?: "", 12) }
                    }
                    if (run != null) StatusChip(run.s("status"), run.s("conclusion"))
                }
                Spacer(Modifier.height(8.dp))
                Muted("آخر رفع: ${fmt(last)}")
                if (asset != null) Muted("آخر APK: ${asset.s("name")} · ${sz(asset.getLong("size"))}", 12, true)
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { vm.download(rel!!) }, enabled = rel != null && !vm.busy, shape = RoundedCornerShape(12.dp)) { BtnLabel(Ic.Download, "تحميل وتثبيت") }
                    OutlinedButton(onClick = { vm.uploadTarget = f; vm.screen = "upload" }, shape = RoundedCornerShape(12.dp)) { BtnLabel(Ic.CloudUpload, "تحديث", Cl.accent) }
                }
                if (zips.isNotEmpty()) TextButton(onClick = { vm.rebuild(zips.first().first) }, enabled = !vm.busy) { BtnLabel(Ic.Refresh, "إعادة بناء النسخة الحالية", Cl.muted) }
            }
        }
    }
}

/** Upload card (new project / update existing) and, below it, what is inside projects/ in the repository. */
@Composable fun UploadScreen(vm: VM) {
    val ctx = LocalContext.current
    val folders = vm.projects?.folders.orEmpty()
    var update by remember { mutableStateOf(vm.uploadTarget != null) }
    var sel by remember { mutableStateOf(vm.uploadTarget ?: "") }
    var pname by remember { mutableStateOf("") }
    var uri by remember { mutableStateOf<Uri?>(null) }; var fname by remember { mutableStateOf("") }; var size by remember { mutableStateOf(0L) }
    var warn by remember { mutableStateOf(false) }
    LaunchedEffect(vm.repo) { vm.loadProjects() }
    LaunchedEffect(Unit) { vm.uploadTarget = null }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) {
            ctx.contentResolver.query(u, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) { fname = c.getString(c.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)); size = c.getLong(c.getColumnIndexOrThrow(OpenableColumns.SIZE)) }
            }
            if (size > 50_000_000) vm.error = "الحد الأقصى 50MB" else {
                uri = u; warn = !rootOk(ctx, u)
                if (!update && pname.isBlank()) pname = clean(fname.removeSuffix(".zip"))
            }
        }
    }
    // the project's name = its folder = its zip = its APK
    val newName = clean(pname)
    val exists = folders.any { it.equals(newName, true) }
    val updZip = vm.projects?.items.orEmpty().firstOrNull { it.first.startsWith("projects/$sel/") && it.first.endsWith(".zip") }?.first?.substringAfterLast('/')?.removeSuffix(".zip") ?: sel
    val folder = if (update) sel else newName
    val base = if (update) updZip else newName
    val ready = uri != null && !vm.busy && (if (update) sel.isNotBlank() else pname.isNotBlank() && !exists)
    LazyColumn(contentPadding = PaddingValues(top = 6.dp, bottom = 16.dp)) {
        item { Card2 {
            Head(Ic.CloudUpload, "رفع إلى ${vm.repo?.substringAfter('/') ?: ""}")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = !update, onClick = { update = false }, label = { Text("مشروع جديد") }, leadingIcon = { Ico(Ic.Plus, size = 16.dp) }, shape = RoundedCornerShape(12.dp))
                FilterChip(selected = update, onClick = { update = true }, enabled = folders.isNotEmpty(), label = { Text("تحديث مشروع موجود") }, leadingIcon = { Ico(Ic.Refresh, size = 16.dp) }, shape = RoundedCornerShape(12.dp))
            }
            Spacer(Modifier.height(10.dp))
            if (update) {
                Muted("اختر المشروع")
                Spacer(Modifier.height(6.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    folders.forEach { f -> FilterChip(selected = sel == f, onClick = { sel = f }, label = { Text(f) }, leadingIcon = { Ico(Ic.Folder, size = 16.dp) }, shape = RoundedCornerShape(12.dp)) }
                }
            } else {
                OutlinedTextField(pname, { pname = it }, label = { Text("اسم المشروع (هو اسم ملف الـAPK)") }, singleLine = true, isError = exists,
                    supportingText = { if (exists) Text("يوجد مشروع بهذا الاسم، اختر «تحديث مشروع موجود»") }, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth())
            }
            Spacer(Modifier.height(12.dp))
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Cl.accent.copy(alpha = .07f))
                .border(1.5.dp, Cl.accent.copy(alpha = .45f), RoundedCornerShape(16.dp))
                .clickable { picker.launch(arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream")) }.padding(26.dp),
                horizontalAlignment = Alignment.CenterHorizontally) {
                Ico(Ic.CloudUpload, Cl.accent, 36.dp); Spacer(Modifier.height(8.dp))
                Text("اضغط لاختيار ملف ZIP", fontWeight = FontWeight.Medium)
                Muted("ملفات المشروع في جذر الـZIP مباشرة", 12)
            }
            if (uri != null) {
                Spacer(Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) { Ico(Ic.File, Cl.accent, 18.dp); Spacer(Modifier.width(8.dp)); Text("$fname · ${sz(size)}", fontWeight = FontWeight.SemiBold) }
                Spacer(Modifier.height(4.dp))
                Muted("المسار: projects/${folder.ifBlank { "?" }}/$base.zip", 12, true)
                Muted("الناتج: projects/${folder.ifBlank { "?" }}/$base.apk", 12, true)
                if (update) Muted("سيُستبدل الملف القديم وتُبنى هذه النسخة فقط.", 12)
                if (warn) { Spacer(Modifier.height(6.dp)); Row(verticalAlignment = Alignment.CenterVertically) {
                    Ico(Ic.Alert, Cl.warn, 16.dp); Spacer(Modifier.width(6.dp)); Muted("لم أجد ملفات المشروع في جذر الـZIP. تأكد أنها ليست داخل مجلد فرعي.", 12, color = Cl.warn) } }
            }
            Spacer(Modifier.height(12.dp))
            Button(onClick = { vm.upload(uri!!, base, folder); uri = null }, enabled = ready,
                shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth().height(50.dp)) { BtnLabel(Ic.Wrench, if (update) "رفع التحديث وبدء البناء" else "رفع وبدء البناء") }
        } }
        item { Card2 {
            Head(Ic.Folder, "محتويات projects/")
            val all = vm.projects?.items.orEmpty()
            if (all.isEmpty()) Muted("لا توجد ملفات بعد", 13)
            folders.forEach { f ->
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 8.dp)) { Ico(Ic.Folder, Cl.accent, 16.dp); Spacer(Modifier.width(8.dp)); Text(f, fontWeight = FontWeight.SemiBold, fontSize = 14.sp) }
                all.filter { it.first.startsWith("projects/$f/") }.sortedBy { it.first }.forEach { (p, s) ->
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(start = 24.dp, top = 3.dp)) {
                        Ico(Ic.File, if (p.endsWith(".apk")) Cl.ok else Cl.muted, 14.dp); Spacer(Modifier.width(8.dp))
                        Text(p.substringAfterLast('/'), fontFamily = FontFamily.Monospace, fontSize = 12.sp, modifier = Modifier.weight(1f)); Muted(sz(s), 11)
                    }
                }
            }
        } }
        item { Card2 { Head(Ic.Clock, "سجل الرفع")
            val h = vm.projects?.history.orEmpty()
            if (h.isEmpty()) Muted("لا توجد رفعات بعد", 13)
            h.take(15).forEach { (p, d) -> Text(p, fontFamily = FontFamily.Monospace, fontSize = 12.sp); Muted(fmt(d), 11); Spacer(Modifier.height(8.dp)) }
        } }
    }
}

@Composable fun StepRow(st: JSONObject) {
    val (ic, col) = when (st.s("conclusion")) {
        "success" -> Ic.CheckCircle to Cl.ok
        "failure" -> Ic.XCircle to Cl.bad
        "skipped", "cancelled" -> Ic.Ban to Cl.muted
        else -> Ic.Spinner to Cl.warn
    }
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 3.dp)) {
        Ico(ic, col, 15.dp); Spacer(Modifier.width(8.dp))
        Text(st.s("name"), fontSize = 12.sp, modifier = Modifier.weight(1f))
        Muted(dur(st.s("started_at"), st.s("completed_at")), 11)
    }
}

/** Build log: left-to-right, selectable, with a one-tap copy button. */
@Composable fun LogBox(text: String, onCopied: () -> Unit) {
    val clip = LocalClipboardManager.current
    TextButton(onClick = { clip.setText(AnnotatedString(text)); onCopied() }) { BtnLabel(Ic.Copy, "نسخ السجل", Cl.accent) }
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        SelectionContainer {
            Text(text, fontSize = 11.sp, lineHeight = 16.sp, fontFamily = FontFamily.Monospace, color = Cl.muted, textAlign = TextAlign.Left,
                modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Cl.bg).padding(10.dp)
                    .heightIn(max = 320.dp).verticalScroll(rememberScrollState()))
        }
    }
}

@Composable fun BuildScreen(vm: VM) {
    LaunchedEffect(Unit) { while (true) { vm.refreshRuns(); delay(6000) } }
    LazyColumn(contentPadding = PaddingValues(bottom = 16.dp)) {
        if (vm.runs.isEmpty()) item { Card2 { Empty(Ic.Wrench, "لا توجد عمليات بناء بعد. ارفع مشروعاً أولاً.") } }
        items(vm.runs, key = { it.getLong("id") }) { r ->
            val id = r.getLong("id"); val done = r.s("status") == "completed"
            Card2 {
                Row(Modifier.fillMaxWidth().clickable { vm.toggle(id) }, Arrangement.SpaceBetween, Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("#${r.getInt("run_number")}", fontWeight = FontWeight.Bold)
                        Muted(r.optJSONObject("head_commit")?.s("message")?.removePrefix("CloudForge: upload ")?.lines()?.first() ?: "", 12, true)
                    }
                    StatusChip(r.s("status"), r.s("conclusion"))
                }
                Spacer(Modifier.height(4.dp))
                Muted("بدأ: ${fmt(r.s("run_started_at"))} · المدة: ${dur(r.s("run_started_at"), if (done) r.s("updated_at") else null)}")
                if (vm.open == id) vm.jobs[id].orEmpty().filter { it.s("name") != "Detect new zips" }.forEach { j ->
                    val jid = j.getLong("id")
                    HorizontalDivider(Modifier.padding(vertical = 8.dp), color = Cl.line)
                    Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                        Text(j.s("name"), fontSize = 13.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                        StatusChip(j.s("status"), j.s("conclusion"))
                    }
                    Muted("المدة: ${dur(j.s("started_at"), j.s("completed_at"))}", 11)
                    Spacer(Modifier.height(4.dp))
                    j.getJSONArray("steps").list().forEach { StepRow(it) }
                    if (j.s("conclusion") == "failure") {
                        TextButton(onClick = { vm.showLog(jid) }) { BtnLabel(Ic.Alert, "عرض الأخطاء", Cl.bad) }
                        vm.logs[jid]?.let { LogBox(it) { vm.toast = "تم نسخ السجل" } }
                    }
                }
                if (!done) TextButton(onClick = { vm.cancelRun(id) }) { BtnLabel(Ic.Close, "إلغاء البناء", Cl.bad) }
            }
        }
    }
}

@Composable fun ArchiveScreen(vm: VM) {
    var del by remember { mutableStateOf<JSONObject?>(null) }
    LaunchedEffect(Unit) { vm.loadArchive() }
    LazyColumn(contentPadding = PaddingValues(bottom = 16.dp)) {
        if (vm.archive.isEmpty()) item { Card2 { Empty(Ic.Archive, "الأرشيف فارغ") } }
        vm.archive.forEach { (run, rels) ->
            if (rels.isEmpty()) item { Card2 {
                Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) { Text("v${run.getInt("run_number")} · بدون APK", fontWeight = FontWeight.Bold); StatusChip(run.s("status"), run.s("conclusion")) }
                Muted(fmt(run.s("run_started_at")))
            } }
            rels.forEach { rel -> item { Card2 {
                val size = rel.getJSONArray("assets").optJSONObject(0)?.getLong("size")
                Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text("v${run.getInt("run_number")} · ${rel.s("name")}", fontWeight = FontWeight.Bold)
                        Muted("${fmt(run.s("run_started_at"))} · ${size?.let { sz(it) } ?: "—"}") }
                    StatusChip(run.s("status"), run.s("conclusion"))
                }
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { vm.download(rel) }, enabled = size != null && !vm.busy, shape = RoundedCornerShape(12.dp)) { BtnLabel(Ic.Download, "تحميل وتثبيت") }
                    OutlinedButton(onClick = { del = rel }, shape = RoundedCornerShape(12.dp), border = BorderStroke(1.dp, Cl.bad.copy(alpha = .5f))) { BtnLabel(Ic.Trash, "حذف", Cl.bad) }
                }
            } } }
        }
    }
    del?.let { d -> AlertDialog(onDismissRequest = { del = null }, icon = { Ico(Ic.Trash, Cl.bad, 28.dp) }, title = { Text("حذف الإصدار؟") },
        text = { Text("سيُحذف ملف APK نهائياً لتوفير المساحة.") },
        confirmButton = { TextButton(onClick = { vm.delete(d); del = null }) { Text("حذف", color = Cl.bad) } },
        dismissButton = { TextButton(onClick = { del = null }) { Text("إلغاء") } }) }
}
